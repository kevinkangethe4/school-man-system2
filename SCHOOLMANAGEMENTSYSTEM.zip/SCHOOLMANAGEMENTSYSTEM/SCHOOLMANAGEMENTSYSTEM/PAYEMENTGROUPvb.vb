﻿Imports System.Drawing.Printing
Public Class PAYEMENTGROUPvb
    Private mRow As Integer = 0
    Private newpage As Boolean = True
    Private Sub PAYMENTBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PAYMENTBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.PAYMENTBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub PAYEMENTGROUPvb_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.PAYMENT' table. You can move, or remove it, as needed.
        Me.PAYMENTTableAdapter.Fill(Me.Database1DataSet.PAYMENT)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim PrintDlg As PrintDialog = New PrintDialog()
        Dim PrintDlgRslt As DialogResult = New DialogResult()
        Dim MyDoc As PrintDocument = New PrintDocument()

        PrintDlg.Document = MyDoc

        PrintDlgRslt = PrintDlg.ShowDialog()
        If PrintDlgRslt = Windows.Forms.DialogResult.OK Then
            AddHandler MyDoc.PrintPage, AddressOf PrintDocument1_PrintPage
            MyDoc.Print()
        End If

    End Sub

    Private Sub PrintDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.BeginPrint
        mRow = 0
        newpage = True
        PrintPreviewDialog1.PrintPreviewControl.StartPage = 0
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.0
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.PAYMENTDataGridView.Width, Me.PAYMENTDataGridView.Height)
        PAYMENTDataGridView.DrawToBitmap(bm, New Rectangle(0, 0, Me.PAYMENTDataGridView.Width, Me.PAYMENTDataGridView.Height))
        e.Graphics.DrawImage(bm, 0, 0)
    End Sub

    Private Sub PAYMENTDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub TextBox13_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox13.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.PAYMENT
        dv.RowFilter = "[STUDENTNUMBER] like'" & TextBox13.Text & "%'"

        PAYMENTDataGridView.DataSource = dv
    End Sub

    Private Sub TextBox13_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox13.TextChanged
        
    End Sub

    Private Sub TextBox16_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        
    End Sub

    Private Sub TextBox16_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox19_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        
    End Sub

    Private Sub TextBox19_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PAYMENTDataGridView_CellContentClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PAYMENTDataGridView.CellContentClick

    End Sub

    Private Sub PAYMENTDataGridView_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles PAYMENTDataGridView.RowPostPaint
        Dim dg As DataGridView = DirectCast(sender, DataGridView)
        Dim rownumber As String = (e.RowIndex + 1).ToString()
        While rownumber.Length < dg.RowCount.ToString().Length
            rownumber = "0" & rownumber

        End While
        Dim size As SizeF = e.Graphics.MeasureString(rownumber, Me.Font)
        If dg.RowHeadersWidth < CInt(size.Width + 20) Then
            dg.RowHeadersWidth = CInt(size.Width + 20)

        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(rownumber, dg.Font, b, e.RowBounds.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))
    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        If PAYMENTDataGridView.RowCount > 1 Then
            Dim TOT As Integer = 0
            For IND As Integer = 0 To PAYMENTDataGridView.RowCount - 1
                TOT += Convert.ToInt32(PAYMENTDataGridView.Rows(IND).Cells(14).Value)
            Next
            Label3.Text = TOT
        End If
    End Sub

    Private Sub Label4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label4.Click
        If PAYMENTDataGridView.RowCount > 1 Then
            Dim TOT As Integer = 0
            For IND As Integer = 0 To PAYMENTDataGridView.RowCount - 1
                TOT += Convert.ToInt32(PAYMENTDataGridView.Rows(IND).Cells(13).Value)
            Next
            Label4.Text = TOT
        End If
    End Sub

    Private Sub PrintPreviewDialog1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreviewDialog1.Load

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Dim doc As New PrintDocument()
        AddHandler doc.PrintPage, AddressOf Me.PrintDocument2_PrintPage
        Dim dlgs As New PrintDialog()
        dlgs.Document = doc
        If dlgs.ShowDialog() = DialogResult.OK Then
            doc.Print()
        End If
    End Sub

    Private Sub PrintDocument2_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument2.PrintPage
        Dim x As Single = e.MarginBounds.Left
        Dim y As Single = e.MarginBounds.Top
        Dim bmp As New Bitmap(Me.GroupBox1.Width, Me.GroupBox1.Height)
        Me.GroupBox1.DrawToBitmap(bmp, New Rectangle(0, 0, Me.GroupBox1.Width, Me.GroupBox1.Height))
        e.Graphics.DrawImage(DirectCast(bmp, Image), x, y)
    End Sub
End Class