﻿

Imports System.Drawing.Printing

Public Class performance

    Private mRow As Integer = 0
    Private newpage As Boolean = True

    Private Sub PERFORMANCEBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PERFORMANCEBindingNavigatorSaveItem.Click


        Me.Validate()
        Me.PERFORMANCEBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub performance_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.REGISTATION' table. You can move, or remove it, as needed.
        Me.REGISTATIONTableAdapter.Fill(Me.Database1DataSet.REGISTATION)
        'TODO: This line of code loads data into the 'Database1DataSet.PERFORMANCE' table. You can move, or remove it, as needed.
        Me.PERFORMANCETableAdapter.Fill(Me.Database1DataSet.PERFORMANCE)

    End Sub

    Private Sub TextBox1_Enter(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.Enter

    End Sub

    Private Sub TextBox1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.GotFocus
        TextBox1.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(5).FormattedValue.ToString() <> String.Empty
                         Select Convert.ToInt32(ROW.Cells(5).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox13_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox13.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.PERFORMANCE
        dv.RowFilter = "[STUDENTNUMBER] like'" & TextBox13.Text & "%'"

        PERFORMANCEDataGridView.DataSource = dv
    End Sub

    Private Sub TextBox13_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox13.TextChanged

    End Sub

    Private Sub TextBox14_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
       
    End Sub

    Private Sub TextBox14_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox2_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox2.GotFocus
        TextBox2.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(7).FormattedValue.ToString() <> String.Empty
                              Select Convert.ToInt32(ROW.Cells(7).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox3_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox3.GotFocus
        TextBox3.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(9).FormattedValue.ToString() <> String.Empty
                                            Select Convert.ToInt32(ROW.Cells(9).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox4_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox4.GotFocus
        TextBox4.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(11).FormattedValue.ToString() <> String.Empty
                                            Select Convert.ToInt32(ROW.Cells(11).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox5_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox5.GotFocus
        TextBox5.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(13).FormattedValue.ToString() <> String.Empty
                                                    Select Convert.ToInt32(ROW.Cells(13).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox6_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.GotFocus
        TextBox6.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(15).FormattedValue.ToString() <> String.Empty
                                    Select Convert.ToInt32(ROW.Cells(15).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub TextBox7_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox7.GotFocus
        TextBox7.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(17).FormattedValue.ToString() <> String.Empty
                                                    Select Convert.ToInt32(ROW.Cells(17).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox15_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox15.GotFocus
        TextBox15.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(21).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(21).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox15_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox15.TextChanged

    End Sub

    Private Sub TextBox9_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox9.GotFocus
        TextBox9.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(23).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(23).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox9_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox9.TextChanged

    End Sub

    Private Sub TextBox10_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox10.GotFocus
        TextBox10.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(25).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(25).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox10_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox10.TextChanged

    End Sub

    Private Sub TextBox11_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox11.GotFocus
        TextBox11.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(27).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(27).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox11_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox11.TextChanged

    End Sub

    Private Sub TextBox8_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox8.GotFocus
        TextBox8.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(19).FormattedValue.ToString() <> String.Empty
                                                           Select Convert.ToInt32(ROW.Cells(19).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub TextBox12_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox12.GotFocus
        TextBox12.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(31).FormattedValue.ToString() <> String.Empty
                                                         Select Convert.ToInt32(ROW.Cells(31).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox12_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox12.TextChanged

    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox2.Enter

    End Sub

    Private Sub BindingNavigatorPositionItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorPositionItem.Click

    End Sub

    Private Sub TextBox16_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)
       
    End Sub

    Private Sub TextBox16_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox17_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox17_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox18_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox18_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PERFORMANCEDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)



    End Sub

    Private Sub TextBox19_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub TextBox19_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim fg As PrintDialog = New PrintDialog
        Dim er As DialogResult = New DialogResult
        Dim mydoc As PrintDocument = New PrintDocument
        fg.Document = mydoc
        er = fg.ShowDialog
        If er = Windows.Forms.DialogResult.OK Then
            AddHandler mydoc.PrintPage, AddressOf PrintDocument1_PrintPage_1
            mydoc.Print()

        End If
    End Sub
    

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        PrintDocument1.Print()
    End Sub

    Private Sub PrintDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.BeginPrint

        mRow = 0
        newpage = True
        PrintPreviewDialog1.PrintPreviewControl.StartPage = 0
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.0

    End Sub

    Private Sub PrintDocument1_PrintPage_1(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.PERFORMANCEDataGridView.Width, Me.PERFORMANCEDataGridView.Height)
        PERFORMANCEDataGridView.DrawToBitmap(bm, New Rectangle(0, 0, Me.PERFORMANCEDataGridView.Width, Me.PERFORMANCEDataGridView.Height))
        e.Graphics.DrawImage(bm, 0, 0)

    End Sub

    Private Sub PERFORMANCEDataGridView_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs)
        Dim dg As DataGridView = DirectCast(sender, DataGridView)
        Dim rownumber As String = (e.RowIndex + 1).ToString()
        While rownumber.Length < dg.RowCount.ToString().Length
            rownumber = "0" & rownumber

        End While
        Dim size As SizeF = e.Graphics.MeasureString(rownumber, Me.Font)
        If dg.RowHeadersWidth < CInt(size.Width + 20) Then
            dg.RowHeadersWidth = CInt(size.Width + 20)

        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(rownumber, dg.Font, b, e.RowBounds.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))
    End Sub

    Private Sub PrintDocument2_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument2.PrintPage
        Dim fmt As StringFormat = New StringFormat(StringFormatFlags.LineLimit)
        fmt.LineAlignment = StringAlignment.Center
        fmt.Trimming = StringTrimming.EllipsisCharacter
        Dim y As Int32 = e.MarginBounds.Top
        Dim rc As Rectangle
        Dim x As Int32
        Dim h As Int32 = 0
        Dim row As DataGridViewRow

        ' print the header text for a new page
        '   use a grey bg just like the control
        If newpage Then
            row = PERFORMANCEDataGridView.Rows(mRow)
            x = e.MarginBounds.Left
            For Each cell As DataGridViewCell In row.Cells
                ' since we are printing the control's view,
                ' skip invidible columns
                If cell.Visible Then
                    rc = New Rectangle(x, y, cell.Size.Width, cell.Size.Height)

                    e.Graphics.FillRectangle(Brushes.LightGray, rc)
                    e.Graphics.DrawRectangle(Pens.Black, rc)

                    ' reused in the data pront - should be a function
                    Select Case PERFORMANCEDataGridView.Columns(cell.ColumnIndex).DefaultCellStyle.Alignment
                        Case DataGridViewContentAlignment.BottomRight,
                             DataGridViewContentAlignment.MiddleRight
                            fmt.Alignment = StringAlignment.Far
                            rc.Offset(-1, 0)
                        Case DataGridViewContentAlignment.BottomCenter,
                            DataGridViewContentAlignment.MiddleCenter
                            fmt.Alignment = StringAlignment.Center
                        Case Else
                            fmt.Alignment = StringAlignment.Near
                            rc.Offset(2, 0)
                    End Select

                    e.Graphics.DrawString(PERFORMANCEDataGridView.Columns(cell.ColumnIndex).HeaderText,
                                                PERFORMANCEDataGridView.Font, Brushes.Black, rc, fmt)
                    x += rc.Width
                    h = Math.Max(h, rc.Height)
                End If
            Next
            y += h

        End If
        newpage = False

        ' now print the data for each row
        Dim thisNDX As Int32
        For thisNDX = mRow To PERFORMANCEDataGridView.RowCount - 1
            ' no need to try to print the new row
            If PERFORMANCEDataGridView.Rows(thisNDX).IsNewRow Then Exit For

            row = PERFORMANCEDataGridView.Rows(thisNDX)
            x = e.MarginBounds.Left
            h = 0

            ' reset X for data
            x = e.MarginBounds.Left

            ' print the data
            For Each cell As DataGridViewCell In row.Cells
                If cell.Visible Then
                    rc = New Rectangle(x, y, cell.Size.Width, cell.Size.Height)

                    ' SAMPLE CODE: How To 
                    ' up a RowPrePaint rule
                    'If Convert.ToDecimal(row.Cells(5).Value) < 9.99 Then
                    '    Using br As New SolidBrush(Color.MistyRose)
                    '        e.Graphics.FillRectangle(br, rc)
                    '    End Using
                    'End If

                    e.Graphics.DrawRectangle(Pens.Black, rc)

                    Select Case PERFORMANCEDataGridView.Columns(cell.ColumnIndex).DefaultCellStyle.Alignment
                        Case DataGridViewContentAlignment.BottomRight,
                             DataGridViewContentAlignment.MiddleRight
                            fmt.Alignment = StringAlignment.Far
                            rc.Offset(-1, 0)
                        Case DataGridViewContentAlignment.BottomCenter,
                            DataGridViewContentAlignment.MiddleCenter
                            fmt.Alignment = StringAlignment.Center
                        Case Else
                            fmt.Alignment = StringAlignment.Near
                            rc.Offset(2, 0)
                    End Select

                    e.Graphics.DrawString(cell.FormattedValue.ToString(),
                                          PERFORMANCEDataGridView.Font, Brushes.Black, rc, fmt)

                    x += rc.Width
                    h = Math.Max(h, rc.Height)
                End If

            Next
            y += h
            ' next row to print
            mRow = thisNDX + 1

            If y + h > e.MarginBounds.Bottom Then
                e.HasMorePages = True
                ' mRow -= 1   causes last row to rePrint on next page
                newpage = True
                Return
            End If
        Next



    End Sub

    Private Sub TextBox20_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox20.GotFocus
        TextBox20.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(29).FormattedValue.ToString() <> String.Empty
                                                          Select Convert.ToInt32(ROW.Cells(29).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox20_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox20.TextChanged

    End Sub

    Private Sub PrintDocument3_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument3.PrintPage
        Dim x As Single = e.MarginBounds.Left
        Dim y As Single = e.MarginBounds.Top
        Dim bmp As New Bitmap(Me.GroupBox1.Width, Me.GroupBox1.Height)
        Me.GroupBox1.DrawToBitmap(bmp, New Rectangle(0, 0, Me.GroupBox1.Width, Me.GroupBox1.Height))
        e.Graphics.DrawImage(DirectCast(bmp, Image), x, y)
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim doc As New PrintDocument()
        AddHandler doc.PrintPage, AddressOf Me.PrintDocument3_PrintPage
        Dim dlgs As New PrintDialog()
        dlgs.Document = doc
        If dlgs.ShowDialog() = DialogResult.OK Then
            doc.Print()
        End If
    End Sub

    Private Sub SaveFileDialog1_FileOk(ByVal sender As System.Object, ByVal e As System.ComponentModel.CancelEventArgs) Handles SaveFileDialog1.FileOk

    End Sub

    Private Sub PERFORMANCEDataGridView_CellContentClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub PERFORMANCEDataGridView_RowPostPaint1(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs)
        
    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub Search1ToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Search1ToolStripButton.Click


        Try
            Me.REGISTATIONTableAdapter.Search1(Me.Database1DataSet.REGISTATION, _LIKEToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try


    End Sub

    Private Sub TextBox17_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox17.GotFocus
        TextBox17.Text = KCPERESULTTextBox.Text / 500 * 100
    End Sub

    Private Sub TextBox17_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox17.TextChanged

    End Sub

    Private Sub TextBox18_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox18.GotFocus
        TextBox18.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(32).FormattedValue.ToString() <> String.Empty
                                                          Select Convert.ToDecimal(ROW.Cells(32).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox18_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox18.TextChanged

    End Sub

    Private Sub TextBox21_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox21.GotFocus
        If TextBox17.Text > TextBox18.Text Then
            TextBox21.Text = "Decrease "
        ElseIf TextBox18.Text > TextBox17.Text Then
            TextBox21.Text = "improved"
        ElseIf TextBox17.Text = TextBox18.Text Then
            TextBox21.Text = "maintained"
        End If
    End Sub

    Private Sub TextBox21_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox21.TextChanged
        
    End Sub

    Private Sub PERFORMANCEDataGridView_CellContentClick_2(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub PERFORMANCEDataGridView_RowPostPaint2(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs)
        Dim dg As DataGridView = DirectCast(sender, DataGridView)
        Dim rownumber As String = (e.RowIndex + 1).ToString()
        While rownumber.Length < dg.RowCount.ToString().Length
            rownumber = "0" & rownumber

        End While
        Dim size As SizeF = e.Graphics.MeasureString(rownumber, Me.Font)
        If dg.RowHeadersWidth < CInt(size.Width + 20) Then
            dg.RowHeadersWidth = CInt(size.Width + 20)

        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(rownumber, dg.Font, b, e.RowBounds.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))
    End Sub

    Private Sub TextBox22_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox22.GotFocus
        TextBox22.Text = TextBox18.Text - TextBox17.Text
    End Sub

    Private Sub TextBox22_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox22.TextChanged

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Dim doc As New PrintDocument()
        AddHandler doc.PrintPage, AddressOf Me.PrintDocument4_PrintPage
        Dim dlgs As New PrintDialog()
        dlgs.Document = doc
        If dlgs.ShowDialog() = DialogResult.OK Then
            doc.Print()
        End If
    End Sub

    Private Sub PrintDocument4_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument4.PrintPage
        Dim x As Single = e.MarginBounds.Left
        Dim y As Single = e.MarginBounds.Top
        Dim bmp As New Bitmap(Me.GroupBox3.Width, Me.GroupBox3.Height)
        Me.GroupBox3.DrawToBitmap(bmp, New Rectangle(0, 0, Me.GroupBox3.Width, Me.GroupBox3.Height))
        e.Graphics.DrawImage(DirectCast(bmp, Image), x, y)
    End Sub

    Private Sub Search1ToolStrip_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles Search1ToolStrip.ItemClicked

    End Sub

    Private Sub PERFORMANCEDataGridView_CellContentClick_3(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub PERFORMANCEDataGridView_CellContentClick_4(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PERFORMANCEDataGridView.CellContentClick

    End Sub

    Private Sub PERFORMANCEDataGridView_RowPostPaint3(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles PERFORMANCEDataGridView.RowPostPaint
        Dim dg As DataGridView = DirectCast(sender, DataGridView)
        Dim rownumber As String = (e.RowIndex + 1).ToString()
        While rownumber.Length < dg.RowCount.ToString().Length
            rownumber = "0" & rownumber

        End While
        Dim size As SizeF = e.Graphics.MeasureString(rownumber, Me.Font)
        If dg.RowHeadersWidth < CInt(size.Width + 20) Then
            dg.RowHeadersWidth = CInt(size.Width + 20)

        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(rownumber, dg.Font, b, e.RowBounds.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))
    End Sub
End Class