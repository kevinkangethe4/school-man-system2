﻿Public Class progresschart

    Private Sub progresschart_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.PERFORMANCE' table. You can move, or remove it, as needed.
        Me.PERFORMANCETableAdapter.Fill(Me.Database1DataSet.PERFORMANCE)

    End Sub

    Private Sub TextBox1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.PERFORMANCE
        dv.RowFilter = "[STUDENTNUMBER] like'" & TextBox1.Text & "%'"

        Chart1.DataSource = dv
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
       
    End Sub
End Class