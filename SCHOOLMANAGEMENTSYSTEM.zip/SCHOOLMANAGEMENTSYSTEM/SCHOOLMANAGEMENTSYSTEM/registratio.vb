﻿Public Class registratio

    Private Sub REGISTATIONBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REGISTATIONBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.REGISTATIONBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub registratio_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.REGISTATION' table. You can move, or remove it, as needed.
        Me.REGISTATIONTableAdapter.Fill(Me.Database1DataSet.REGISTATION)
        REGISTATIONDataGridView.Visible = False

    End Sub

    Private Sub GENDERComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GENDERComboBox.SelectedIndexChanged

    End Sub

    Private Sub CLASSComboBox_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub REGISTRATIONDATEDateTimePicker_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REGISTRATIONDATEDateTimePicker.ValueChanged

    End Sub

    Private Sub NEXTOFKINRELATIONTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NEXTOFKINRELATIONTextBox.TextChanged

    End Sub

    Private Sub NEXTOFKINTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NEXTOFKINTextBox.TextChanged

    End Sub

    Private Sub EMAILTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EMAILTextBox.TextChanged

    End Sub

    Private Sub PHONENUMBERTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PHONENUMBERTextBox.TextChanged

    End Sub

    Private Sub ADDRESSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ADDRESSTextBox.TextChanged

    End Sub

    Private Sub DATEOFBIRTHDateTimePicker_ValueChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DATEOFBIRTHDateTimePicker.ValueChanged

    End Sub

    Private Sub LASTNAMETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LASTNAMETextBox.TextChanged

    End Sub

    Private Sub MIDDLENAMETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MIDDLENAMETextBox.TextChanged

    End Sub

    Private Sub FIRSTNAMETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles FIRSTNAMETextBox.TextChanged

    End Sub

    Private Sub STUDENTNUMBERTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles STUDENTNUMBERTextBox.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Me.REGISTATIONBindingSource.AddNew()
            MsgBox("ADD RECORD")
        Catch ex As Exception

        End Try

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Me.Validate()
            Me.REGISTATIONBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)
            MsgBox("SAVED")
        Catch ex As Exception

        End Try
        
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Me.OpenFileDialog1.ShowDialog()
        StudentpicPictureBox.Image = Image.FromFile(OpenFileDialog1.FileName)
        TextBox3.Text = OpenFileDialog1.SafeFileName
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        Me.OpenFileDialog1.ShowDialog()
        ParentpicPictureBox.Image = Image.FromFile(OpenFileDialog1.FileName)
        TextBox4.Text = OpenFileDialog1.SafeFileName
    End Sub


    Private Sub STUDENTNUMBER2ToolStrip_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs)

    End Sub

    Private Sub Search_STUDENTNUMBERToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Search_STUDENTNUMBERToolStripButton.Click
        Try
            Me.REGISTATIONTableAdapter.Search_STUDENTNUMBER(Me.Database1DataSet.REGISTATION, _LIKEToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub KCPERESULTTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KCPERESULTTextBox.TextChanged
        If KCPERESULTTextBox.Text > 500 Then
            MsgBox("Not Applicable Please")
        End If
    End Sub
End Class