﻿Public Class RTPPERFORMANCE

    Private Sub RTPPERFORMANCE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.PERFORMANCE' table. You can move, or remove it, as needed.
        Me.PERFORMANCETableAdapter.Fill(Me.Database1DataSet.PERFORMANCE)

        Me.ReportViewer1.RefreshReport()
    End Sub
End Class