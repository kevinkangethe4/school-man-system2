﻿Imports System.Data.SqlClient
Module Module1
    Public sda As SqlDataAdapter
    Public sqlCon As SqlConnection

    Public sqlDT As New DataTable
    Public sqlDTx As New DataTable
    Public CnString As String
    Public LOGID As Integer
    Public sqlSTR As String
    Public username As String
    Public EMP_ID As Double
    Public EMP_NAME As String
    Public xUserPassword As String
    Public xUser_ID As Integer
    Public AUTO_BARCODE As Double
    Public cmd As SqlCommand
    Public Function checkServer() As Boolean
        CnString = "Data Source=|DataDirectory|\Database1.sdf;Persist Security Info=True"
        Try
            Dim sqlCon As New SqlConnection(CnString)
            sqlCon.ConnectionString = CnString
            sqlCon.Open()
            checkServer = True
            sqlCon.Close()
        Catch ex As Exception
            checkServer = False
            MsgBox("oops : " & ex.Message)
            End
        End Try
        'End Using
    End Function

    Public Function ExecuteSQLQuery(ByVal SQLQuery As String) As DataTable
        Try
            Dim sqlCon As New SqlConnection(CnString)
            Dim sqlDA As New SqlDataAdapter(SQLQuery, sqlCon)
            Dim sqlCB As New SqlCommandBuilder(sqlDA)
            sqlDT.Reset() ' refresh 
            sqlDA.Fill(sqlDT)
        Catch ex As Exception
            MsgBox("Error : " & ex.Message)
        End Try
        Return sqlDT
    End Function
    Public Sub InsertDefaultUserPermission()
        ExecuteSQLQuery("SELECT *  FROM    login")
    End Sub
End Module
