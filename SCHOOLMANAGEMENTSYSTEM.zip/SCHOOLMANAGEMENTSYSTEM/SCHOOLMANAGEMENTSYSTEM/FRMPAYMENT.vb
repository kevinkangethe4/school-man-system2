﻿Imports System.Drawing.Printing
Public Class FRMPAYMENT

    Private Sub PAYMENTBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PAYMENTBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.PAYMENTBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub FRMPAYMENT_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.PAYMENT' table. You can move, or remove it, as needed.
        Me.PAYMENTTableAdapter.Fill(Me.Database1DataSet.PAYMENT)

    End Sub

    Private Sub TUTIONFEELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BOARDINGFEELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CATERINGFEELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ACTIVITIESFEELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub INUSURANCEFEELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TOTALFEELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AMOUNTPAIDLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BALANCELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BALANCETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles BALANCETextBox.GotFocus
        BALANCETextBox.Text = TOTALFEETextBox.Text - AMOUNTPAIDTextBox.Text
    End Sub

    Private Sub BALANCETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BALANCETextBox.TextChanged

    End Sub

    Private Sub AMOUNTPAIDTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AMOUNTPAIDTextBox.TextChanged

    End Sub

    Private Sub TOTALFEETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TOTALFEETextBox.GotFocus
        TOTALFEETextBox.Text = Val(BOARDINGFEETextBox.Text) + Val(CATERINGFEETextBox.Text) + Val(INUSURANCEFEETextBox.Text) + Val(ACTIVITIESFEETextBox.Text) + Val(TUTIONFEETextBox.Text)
    End Sub

    Private Sub TOTALFEETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TOTALFEETextBox.TextChanged

    End Sub

    Private Sub INUSURANCEFEETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles INUSURANCEFEETextBox.TextChanged

    End Sub

    Private Sub ACTIVITIESFEETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ACTIVITIESFEETextBox.TextChanged

    End Sub

    Private Sub CATERINGFEETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CATERINGFEETextBox.TextChanged

    End Sub

    Private Sub BOARDINGFEETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BOARDINGFEETextBox.TextChanged

    End Sub

    Private Sub TUTIONFEETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TUTIONFEETextBox.TextChanged

    End Sub

    Private Sub REFNOTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REFNOTextBox.TextChanged

    End Sub

    Private Sub REFNOLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub STUDENTNUMBERLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub STUDENTNAMELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub MODEOFPAYENTLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PERIODLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub DATELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PAYMENTREFLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.PAYMENTBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Me.Validate()
            Me.PAYMENTBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)
            MsgBox("SAVED")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim doc As New PrintDocument()
        AddHandler doc.PrintPage, AddressOf Me.PrintDocument1_PrintPage
        Dim dlgs As New PrintDialog()
        dlgs.Document = doc
        If dlgs.ShowDialog() = DialogResult.OK Then
            doc.Print()
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim x As Single = e.MarginBounds.Left
        Dim y As Single = e.MarginBounds.Top
        Dim bmp As New Bitmap(Me.GroupBox1.Width, Me.GroupBox1.Height)
        Me.GroupBox1.DrawToBitmap(bmp, New Rectangle(0, 0, Me.GroupBox1.Width, Me.GroupBox1.Height))
        e.Graphics.DrawImage(DirectCast(bmp, Image), x, y)
    End Sub
End Class