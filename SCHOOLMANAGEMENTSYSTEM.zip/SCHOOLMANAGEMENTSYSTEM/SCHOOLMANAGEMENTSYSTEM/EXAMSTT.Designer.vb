﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class EXAMSTT
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DATELabel As System.Windows.Forms.Label
        Dim DAYLabel As System.Windows.Forms.Label
        Dim MORNINGLabel As System.Windows.Forms.Label
        Dim M_TIMELabel As System.Windows.Forms.Label
        Dim MIDMORNINGLabel As System.Windows.Forms.Label
        Dim MM_TIMELabel As System.Windows.Forms.Label
        Dim AFTERNOONLabel As System.Windows.Forms.Label
        Dim A_TIMELabel As System.Windows.Forms.Label
        Dim SUPERVISORLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(EXAMSTT))
        Dim CLASSLabel As System.Windows.Forms.Label
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.EXAMSTIMETABLEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database1DataSet = New SCHOOLMANAGEMENTSYSTEM.Database1DataSet()
        Me.DATETextBox = New System.Windows.Forms.TextBox()
        Me.DAYTextBox = New System.Windows.Forms.TextBox()
        Me.MORNINGTextBox = New System.Windows.Forms.TextBox()
        Me.M_TIMETextBox = New System.Windows.Forms.TextBox()
        Me.MIDMORNINGTextBox = New System.Windows.Forms.TextBox()
        Me.MM_TIMETextBox = New System.Windows.Forms.TextBox()
        Me.AFTERNOONTextBox = New System.Windows.Forms.TextBox()
        Me.A_TIMETextBox = New System.Windows.Forms.TextBox()
        Me.SUPERVISORTextBox = New System.Windows.Forms.TextBox()
        Me.EXAMSTIMETABLETableAdapter = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.EXAMSTIMETABLETableAdapter()
        Me.TableAdapterManager = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager()
        Me.EXAMSTIMETABLEBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.EXAMSTIMETABLEBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.CLASSTextBox = New System.Windows.Forms.TextBox()
        DATELabel = New System.Windows.Forms.Label()
        DAYLabel = New System.Windows.Forms.Label()
        MORNINGLabel = New System.Windows.Forms.Label()
        M_TIMELabel = New System.Windows.Forms.Label()
        MIDMORNINGLabel = New System.Windows.Forms.Label()
        MM_TIMELabel = New System.Windows.Forms.Label()
        AFTERNOONLabel = New System.Windows.Forms.Label()
        A_TIMELabel = New System.Windows.Forms.Label()
        SUPERVISORLabel = New System.Windows.Forms.Label()
        CLASSLabel = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.EXAMSTIMETABLEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.EXAMSTIMETABLEBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.EXAMSTIMETABLEBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'DATELabel
        '
        DATELabel.AutoSize = True
        DATELabel.Location = New System.Drawing.Point(23, 90)
        DATELabel.Name = "DATELabel"
        DATELabel.Size = New System.Drawing.Size(44, 13)
        DATELabel.TabIndex = 2
        DATELabel.Text = "DATE:"
        '
        'DAYLabel
        '
        DAYLabel.AutoSize = True
        DAYLabel.Location = New System.Drawing.Point(23, 116)
        DAYLabel.Name = "DAYLabel"
        DAYLabel.Size = New System.Drawing.Size(36, 13)
        DAYLabel.TabIndex = 4
        DAYLabel.Text = "DAY:"
        '
        'MORNINGLabel
        '
        MORNINGLabel.AutoSize = True
        MORNINGLabel.Location = New System.Drawing.Point(23, 142)
        MORNINGLabel.Name = "MORNINGLabel"
        MORNINGLabel.Size = New System.Drawing.Size(70, 13)
        MORNINGLabel.TabIndex = 6
        MORNINGLabel.Text = "MORNING:"
        '
        'M_TIMELabel
        '
        M_TIMELabel.AutoSize = True
        M_TIMELabel.Location = New System.Drawing.Point(23, 168)
        M_TIMELabel.Name = "M_TIMELabel"
        M_TIMELabel.Size = New System.Drawing.Size(55, 13)
        M_TIMELabel.TabIndex = 8
        M_TIMELabel.Text = "M-TIME:"
        '
        'MIDMORNINGLabel
        '
        MIDMORNINGLabel.AutoSize = True
        MIDMORNINGLabel.Location = New System.Drawing.Point(23, 194)
        MIDMORNINGLabel.Name = "MIDMORNINGLabel"
        MIDMORNINGLabel.Size = New System.Drawing.Size(93, 13)
        MIDMORNINGLabel.TabIndex = 10
        MIDMORNINGLabel.Text = "MIDMORNING:"
        '
        'MM_TIMELabel
        '
        MM_TIMELabel.AutoSize = True
        MM_TIMELabel.Location = New System.Drawing.Point(23, 220)
        MM_TIMELabel.Name = "MM_TIMELabel"
        MM_TIMELabel.Size = New System.Drawing.Size(65, 13)
        MM_TIMELabel.TabIndex = 12
        MM_TIMELabel.Text = "MM-TIME:"
        '
        'AFTERNOONLabel
        '
        AFTERNOONLabel.AutoSize = True
        AFTERNOONLabel.Location = New System.Drawing.Point(23, 246)
        AFTERNOONLabel.Name = "AFTERNOONLabel"
        AFTERNOONLabel.Size = New System.Drawing.Size(87, 13)
        AFTERNOONLabel.TabIndex = 14
        AFTERNOONLabel.Text = "AFTERNOON:"
        '
        'A_TIMELabel
        '
        A_TIMELabel.AutoSize = True
        A_TIMELabel.Location = New System.Drawing.Point(23, 272)
        A_TIMELabel.Name = "A_TIMELabel"
        A_TIMELabel.Size = New System.Drawing.Size(53, 13)
        A_TIMELabel.TabIndex = 16
        A_TIMELabel.Text = "A-TIME:"
        '
        'SUPERVISORLabel
        '
        SUPERVISORLabel.AutoSize = True
        SUPERVISORLabel.Location = New System.Drawing.Point(23, 298)
        SUPERVISORLabel.Name = "SUPERVISORLabel"
        SUPERVISORLabel.Size = New System.Drawing.Size(91, 13)
        SUPERVISORLabel.TabIndex = 18
        SUPERVISORLabel.Text = "SUPERVISOR:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(CLASSLabel)
        Me.GroupBox1.Controls.Add(Me.CLASSTextBox)
        Me.GroupBox1.Controls.Add(DATELabel)
        Me.GroupBox1.Controls.Add(Me.DATETextBox)
        Me.GroupBox1.Controls.Add(DAYLabel)
        Me.GroupBox1.Controls.Add(Me.DAYTextBox)
        Me.GroupBox1.Controls.Add(MORNINGLabel)
        Me.GroupBox1.Controls.Add(Me.MORNINGTextBox)
        Me.GroupBox1.Controls.Add(M_TIMELabel)
        Me.GroupBox1.Controls.Add(Me.M_TIMETextBox)
        Me.GroupBox1.Controls.Add(MIDMORNINGLabel)
        Me.GroupBox1.Controls.Add(Me.MIDMORNINGTextBox)
        Me.GroupBox1.Controls.Add(MM_TIMELabel)
        Me.GroupBox1.Controls.Add(Me.MM_TIMETextBox)
        Me.GroupBox1.Controls.Add(AFTERNOONLabel)
        Me.GroupBox1.Controls.Add(Me.AFTERNOONTextBox)
        Me.GroupBox1.Controls.Add(A_TIMELabel)
        Me.GroupBox1.Controls.Add(Me.A_TIMETextBox)
        Me.GroupBox1.Controls.Add(SUPERVISORLabel)
        Me.GroupBox1.Controls.Add(Me.SUPERVISORTextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(14, 51)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(754, 348)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "EXAMS TIMETABLE"
        '
        'EXAMSTIMETABLEBindingSource
        '
        Me.EXAMSTIMETABLEBindingSource.DataMember = "EXAMSTIMETABLE"
        Me.EXAMSTIMETABLEBindingSource.DataSource = Me.Database1DataSet
        '
        'Database1DataSet
        '
        Me.Database1DataSet.DataSetName = "Database1DataSet"
        Me.Database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DATETextBox
        '
        Me.DATETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "DATE", True))
        Me.DATETextBox.Location = New System.Drawing.Point(126, 87)
        Me.DATETextBox.Name = "DATETextBox"
        Me.DATETextBox.Size = New System.Drawing.Size(601, 20)
        Me.DATETextBox.TabIndex = 3
        '
        'DAYTextBox
        '
        Me.DAYTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "DAY", True))
        Me.DAYTextBox.Location = New System.Drawing.Point(126, 113)
        Me.DAYTextBox.Name = "DAYTextBox"
        Me.DAYTextBox.Size = New System.Drawing.Size(601, 20)
        Me.DAYTextBox.TabIndex = 5
        '
        'MORNINGTextBox
        '
        Me.MORNINGTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "MORNING", True))
        Me.MORNINGTextBox.Location = New System.Drawing.Point(126, 139)
        Me.MORNINGTextBox.Name = "MORNINGTextBox"
        Me.MORNINGTextBox.Size = New System.Drawing.Size(601, 20)
        Me.MORNINGTextBox.TabIndex = 7
        '
        'M_TIMETextBox
        '
        Me.M_TIMETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "M-TIME", True))
        Me.M_TIMETextBox.Location = New System.Drawing.Point(126, 165)
        Me.M_TIMETextBox.Name = "M_TIMETextBox"
        Me.M_TIMETextBox.Size = New System.Drawing.Size(601, 20)
        Me.M_TIMETextBox.TabIndex = 9
        '
        'MIDMORNINGTextBox
        '
        Me.MIDMORNINGTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "MIDMORNING", True))
        Me.MIDMORNINGTextBox.Location = New System.Drawing.Point(126, 191)
        Me.MIDMORNINGTextBox.Name = "MIDMORNINGTextBox"
        Me.MIDMORNINGTextBox.Size = New System.Drawing.Size(601, 20)
        Me.MIDMORNINGTextBox.TabIndex = 11
        '
        'MM_TIMETextBox
        '
        Me.MM_TIMETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "MM-TIME", True))
        Me.MM_TIMETextBox.Location = New System.Drawing.Point(126, 217)
        Me.MM_TIMETextBox.Name = "MM_TIMETextBox"
        Me.MM_TIMETextBox.Size = New System.Drawing.Size(601, 20)
        Me.MM_TIMETextBox.TabIndex = 13
        '
        'AFTERNOONTextBox
        '
        Me.AFTERNOONTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "AFTERNOON", True))
        Me.AFTERNOONTextBox.Location = New System.Drawing.Point(126, 243)
        Me.AFTERNOONTextBox.Name = "AFTERNOONTextBox"
        Me.AFTERNOONTextBox.Size = New System.Drawing.Size(601, 20)
        Me.AFTERNOONTextBox.TabIndex = 15
        '
        'A_TIMETextBox
        '
        Me.A_TIMETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "A-TIME", True))
        Me.A_TIMETextBox.Location = New System.Drawing.Point(126, 269)
        Me.A_TIMETextBox.Name = "A_TIMETextBox"
        Me.A_TIMETextBox.Size = New System.Drawing.Size(601, 20)
        Me.A_TIMETextBox.TabIndex = 17
        '
        'SUPERVISORTextBox
        '
        Me.SUPERVISORTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "SUPERVISOR", True))
        Me.SUPERVISORTextBox.Location = New System.Drawing.Point(126, 295)
        Me.SUPERVISORTextBox.Name = "SUPERVISORTextBox"
        Me.SUPERVISORTextBox.Size = New System.Drawing.Size(601, 20)
        Me.SUPERVISORTextBox.TabIndex = 19
        '
        'EXAMSTIMETABLETableAdapter
        '
        Me.EXAMSTIMETABLETableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.ATTEDANCETableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.EXAMSTIMETABLETableAdapter = Me.EXAMSTIMETABLETableAdapter
        Me.TableAdapterManager.loginTableAdapter = Nothing
        Me.TableAdapterManager.PAYMENTTableAdapter = Nothing
        Me.TableAdapterManager.PERFORMANCETableAdapter = Nothing
        Me.TableAdapterManager.REGISTATIONTableAdapter = Nothing
        Me.TableAdapterManager.timetableTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'EXAMSTIMETABLEBindingNavigator
        '
        Me.EXAMSTIMETABLEBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.EXAMSTIMETABLEBindingNavigator.BindingSource = Me.EXAMSTIMETABLEBindingSource
        Me.EXAMSTIMETABLEBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.EXAMSTIMETABLEBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.EXAMSTIMETABLEBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.EXAMSTIMETABLEBindingNavigatorSaveItem})
        Me.EXAMSTIMETABLEBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.EXAMSTIMETABLEBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.EXAMSTIMETABLEBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.EXAMSTIMETABLEBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.EXAMSTIMETABLEBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.EXAMSTIMETABLEBindingNavigator.Name = "EXAMSTIMETABLEBindingNavigator"
        Me.EXAMSTIMETABLEBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.EXAMSTIMETABLEBindingNavigator.Size = New System.Drawing.Size(1028, 25)
        Me.EXAMSTIMETABLEBindingNavigator.TabIndex = 1
        Me.EXAMSTIMETABLEBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'EXAMSTIMETABLEBindingNavigatorSaveItem
        '
        Me.EXAMSTIMETABLEBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.EXAMSTIMETABLEBindingNavigatorSaveItem.Image = CType(resources.GetObject("EXAMSTIMETABLEBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.EXAMSTIMETABLEBindingNavigatorSaveItem.Name = "EXAMSTIMETABLEBindingNavigatorSaveItem"
        Me.EXAMSTIMETABLEBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.EXAMSTIMETABLEBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(793, 131)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "ADD NEW"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(793, 183)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 3
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'CLASSLabel
        '
        CLASSLabel.AutoSize = True
        CLASSLabel.Location = New System.Drawing.Point(23, 57)
        CLASSLabel.Name = "CLASSLabel"
        CLASSLabel.Size = New System.Drawing.Size(50, 13)
        CLASSLabel.TabIndex = 22
        CLASSLabel.Text = "CLASS:"
        '
        'CLASSTextBox
        '
        Me.CLASSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.EXAMSTIMETABLEBindingSource, "CLASS", True))
        Me.CLASSTextBox.Location = New System.Drawing.Point(126, 54)
        Me.CLASSTextBox.Name = "CLASSTextBox"
        Me.CLASSTextBox.Size = New System.Drawing.Size(601, 20)
        Me.CLASSTextBox.TabIndex = 23
        '
        'EXAMSTT
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1028, 563)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.EXAMSTIMETABLEBindingNavigator)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Name = "EXAMSTT"
        Me.Text = "EXAMSTT"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.EXAMSTIMETABLEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.EXAMSTIMETABLEBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.EXAMSTIMETABLEBindingNavigator.ResumeLayout(False)
        Me.EXAMSTIMETABLEBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Database1DataSet As SCHOOLMANAGEMENTSYSTEM.Database1DataSet
    Friend WithEvents EXAMSTIMETABLEBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents EXAMSTIMETABLETableAdapter As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.EXAMSTIMETABLETableAdapter
    Friend WithEvents TableAdapterManager As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents EXAMSTIMETABLEBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents EXAMSTIMETABLEBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents DATETextBox As System.Windows.Forms.TextBox
    Friend WithEvents DAYTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MORNINGTextBox As System.Windows.Forms.TextBox
    Friend WithEvents M_TIMETextBox As System.Windows.Forms.TextBox
    Friend WithEvents MIDMORNINGTextBox As System.Windows.Forms.TextBox
    Friend WithEvents MM_TIMETextBox As System.Windows.Forms.TextBox
    Friend WithEvents AFTERNOONTextBox As System.Windows.Forms.TextBox
    Friend WithEvents A_TIMETextBox As System.Windows.Forms.TextBox
    Friend WithEvents SUPERVISORTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents CLASSTextBox As System.Windows.Forms.TextBox
End Class
