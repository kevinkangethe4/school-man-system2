﻿Public Class FRMTIMETABLE

    Private Sub TimetableBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Validate()
        Me.TimetableBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub


    Private Sub TimetableBindingNavigatorSaveItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimetableBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TimetableBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub FRMTIMETABLE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.timetable' table. You can move, or remove it, as needed.
        Me.TimetableTableAdapter.Fill(Me.Database1DataSet.timetable)

    End Sub

    Private Sub DayTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DayTextBox.TextChanged

    End Sub

    Private Sub DayLabel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ClassTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ClassTextBox.TextChanged

    End Sub

    Private Sub ClassLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _2_00_2_40TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _2_00_2_40TextBox.TextChanged

    End Sub

    Private Sub _8_00_8_40Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _8_00_8_40TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _8_00_8_40TextBox.TextChanged

    End Sub

    Private Sub TeacheLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TeacheTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TeacheTextBox.TextChanged

    End Sub

    Private Sub _9_20_9_20Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _9_20_9_20TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _9_20_9_20TextBox.TextChanged

    End Sub

    Private Sub EachLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub EachTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EachTextBox.TextChanged

    End Sub

    Private Sub BREAKLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BREAKTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BREAKTextBox.TextChanged

    End Sub

    Private Sub _9_40_10_20Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _9_40_10_20TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _9_40_10_20TextBox.TextChanged

    End Sub

    Private Sub TecLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TecTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TecTextBox.TextChanged

    End Sub

    Private Sub _10_20_11_00Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _10_20_11_00TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _10_20_11_00TextBox.TextChanged

    End Sub

    Private Sub TeacherLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TeacherTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TeacherTextBox.TextChanged

    End Sub

    Private Sub BREARKLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BREARKTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BREARKTextBox.TextChanged

    End Sub

    Private Sub _11_20_12_00Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _11_20_12_00TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _11_20_12_00TextBox.TextChanged

    End Sub

    Private Sub TeachLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TeachTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TeachTextBox.TextChanged

    End Sub

    Private Sub _12_00_12_40Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _12_00_12_40TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _12_00_12_40TextBox.TextChanged

    End Sub

    Private Sub TeacLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TeacTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TeacTextBox.TextChanged

    End Sub

    Private Sub LUNCHLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub LUNCHTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LUNCHTextBox.TextChanged

    End Sub

    Private Sub _2_00_2_40Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TeaLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TeaTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TeaTextBox.TextChanged

    End Sub

    Private Sub _2_40_3_20Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _2_40_3_20TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _2_40_3_20TextBox.TextChanged

    End Sub

    Private Sub TeTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TeTextBox.TextChanged

    End Sub

    Private Sub _3_20_4_00Label_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub _3_20_4_00TextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _3_20_4_00TextBox.TextChanged

    End Sub

    Private Sub TLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TTextBox.TextChanged

    End Sub

    Private Sub DayLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BindingNavigatorDeleteItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorDeleteItem.Click

    End Sub

    Private Sub BindingNavigatorAddNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorAddNewItem.Click

    End Sub

    Private Sub BindingNavigatorSeparator2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorSeparator2.Click

    End Sub

    Private Sub BindingNavigatorMoveLastItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorMoveLastItem.Click

    End Sub

    Private Sub BindingNavigatorMoveNextItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorMoveNextItem.Click

    End Sub

    Private Sub BindingNavigatorSeparator1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorSeparator1.Click

    End Sub

    Private Sub BindingNavigatorCountItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorCountItem.Click

    End Sub

    Private Sub BindingNavigatorPositionItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorPositionItem.Click

    End Sub

    Private Sub BindingNavigatorSeparator_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorSeparator.Click

    End Sub

    Private Sub BindingNavigatorMovePreviousItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorMovePreviousItem.Click

    End Sub

    Private Sub BindingNavigatorMoveFirstItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BindingNavigatorMoveFirstItem.Click

    End Sub

    Private Sub TimetableBindingNavigator_RefreshItems(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimetableBindingNavigator.RefreshItems

    End Sub

    Private Sub TeLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TimetableBindingSource_CurrentChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimetableBindingSource.CurrentChanged

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub _ClassToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _ClassToolStripButton.Click
        Try
            Me.TimetableTableAdapter._Class(Me.Database1DataSet.timetable, _LIKEToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MsgBox("ADD OR EDIT RECORDS")
        Me.TimetableBindingSource.AddNew()

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        
    End Sub
End Class