﻿Public Class ATTEDANCE

    Private Sub ATTEDANCEBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ATTEDANCEBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ATTEDANCEBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub ATTEDANCE_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.ATTEDANCE' table. You can move, or remove it, as needed.
        Me.ATTEDANCETableAdapter.Fill(Me.Database1DataSet.ATTEDANCE)

    End Sub

    Private Sub Attendence_percentageTextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles Attendence_percentageTextBox.GotFocus
        Attendence_percentageTextBox.Text = DaypresentTextBox.Text / OutoffTextBox.Text * 100
    End Sub

    Private Sub Attendence_percentageTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Attendence_percentageTextBox.TextChanged

    End Sub

    Private Sub DayabsentTextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles DayabsentTextBox.GotFocus
        DayabsentTextBox.Text = Val(OutoffTextBox.Text) - Val(DaypresentTextBox.Text)
    End Sub

    Private Sub DayabsentTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DayabsentTextBox.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Me.ATTEDANCEBindingSource.AddNew()
            MsgBox("DO YOU WANT TO ADD RECORD")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Me.Validate()
            Me.ATTEDANCEBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)
            MsgBox("SAVED")
        Catch ex As Exception

        End Try
    End Sub
End Class