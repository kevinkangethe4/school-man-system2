﻿Public Class teachersdutyroll

    Private Sub TDUTIESBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TDUTIESBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TDUTIESBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub teachersdutyroll_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.TDUTIES' table. You can move, or remove it, as needed.
        Me.TDUTIESTableAdapter.Fill(Me.Database1DataSet.TDUTIES)

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Validate()
        Me.TDUTIESBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Me.TDUTIESBindingSource.AddNew()
    End Sub
End Class