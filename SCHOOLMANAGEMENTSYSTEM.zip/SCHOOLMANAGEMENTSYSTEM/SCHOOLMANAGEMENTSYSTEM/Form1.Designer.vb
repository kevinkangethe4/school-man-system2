﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Form1))
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.REGISTRATIONToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.REGISTRATIONFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPSREGISTRATIONFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXITToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PERFOMANCEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PERFORMANCEFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPPERFORMANCEFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PROGRESSGRAPHToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PAYMENTSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PAYMENTFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PAYMENTGROUPFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACCOUNTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ACCOUNTSETTINSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ATTENDANCEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ATTANDANCEFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ATTANDANCEGROUPFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HELPToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HELPFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPTIMETABLEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITEXAMSTIMETABLEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPEXAMSTIMETABLEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.EDITDUTYROLLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPDUTYROLLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HELPToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.HELPToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ContextMenuStrip1 = New System.Windows.Forms.ContextMenuStrip(Me.components)
        Me.REGISTRATIONToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.REGISTRATIONFORMToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEARCHSTUDENTDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PERFORMANCEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PERFORMANCEFORMToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEARCHSTUDENTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEARCHEXAMSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PAYMENTSToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.PAYEMENTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ATTENDANCEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.ATTAENDANCEFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SEARCHDETAILSToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIMETABLESCHEDULEToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TIMETABLEFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPTIMETABLEToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXAMTTFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPEXAMSTTToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.DUTYROLLFORMToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.GROUPROLLToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.HELPToolStripMenuItem3 = New System.Windows.Forms.ToolStripMenuItem()
        Me.EXITToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip1.SuspendLayout()
        Me.ContextMenuStrip1.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.AutoSize = False
        Me.MenuStrip1.BackColor = System.Drawing.Color.Navy
        Me.MenuStrip1.Font = New System.Drawing.Font("Tahoma", 15.75!, CType((System.Drawing.FontStyle.Bold Or System.Drawing.FontStyle.Italic), System.Drawing.FontStyle), System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRATIONToolStripMenuItem, Me.PERFOMANCEToolStripMenuItem, Me.PAYMENTSToolStripMenuItem, Me.ACCOUNTToolStripMenuItem, Me.ATTENDANCEToolStripMenuItem, Me.HELPToolStripMenuItem, Me.HELPToolStripMenuItem1})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(859, 82)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'REGISTRATIONToolStripMenuItem
        '
        Me.REGISTRATIONToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.REGISTRATIONToolStripMenuItem.BackgroundImage = CType(resources.GetObject("REGISTRATIONToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.REGISTRATIONToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.REGISTRATIONToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRATIONFORMToolStripMenuItem, Me.GROUPSREGISTRATIONFORMToolStripMenuItem, Me.EXITToolStripMenuItem1})
        Me.REGISTRATIONToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.REGISTRATIONToolStripMenuItem.Name = "REGISTRATIONToolStripMenuItem"
        Me.REGISTRATIONToolStripMenuItem.Size = New System.Drawing.Size(188, 78)
        Me.REGISTRATIONToolStripMenuItem.Text = "REGISTRATION"
        '
        'REGISTRATIONFORMToolStripMenuItem
        '
        Me.REGISTRATIONFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.REGISTRATIONFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("REGISTRATIONFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.REGISTRATIONFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.REGISTRATIONFORMToolStripMenuItem.ImageAlign = System.Drawing.ContentAlignment.BottomLeft
        Me.REGISTRATIONFORMToolStripMenuItem.Name = "REGISTRATIONFORMToolStripMenuItem"
        Me.REGISTRATIONFORMToolStripMenuItem.Size = New System.Drawing.Size(436, 30)
        Me.REGISTRATIONFORMToolStripMenuItem.Text = "REGISTRATION FORM"
        '
        'GROUPSREGISTRATIONFORMToolStripMenuItem
        '
        Me.GROUPSREGISTRATIONFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPSREGISTRATIONFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("GROUPSREGISTRATIONFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.GROUPSREGISTRATIONFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GROUPSREGISTRATIONFORMToolStripMenuItem.Name = "GROUPSREGISTRATIONFORMToolStripMenuItem"
        Me.GROUPSREGISTRATIONFORMToolStripMenuItem.Size = New System.Drawing.Size(436, 30)
        Me.GROUPSREGISTRATIONFORMToolStripMenuItem.Text = "SEARCH REGISTRATION DETAILS"
        '
        'EXITToolStripMenuItem1
        '
        Me.EXITToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.EXITToolStripMenuItem1.BackgroundImage = CType(resources.GetObject("EXITToolStripMenuItem1.BackgroundImage"), System.Drawing.Image)
        Me.EXITToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.EXITToolStripMenuItem1.Name = "EXITToolStripMenuItem1"
        Me.EXITToolStripMenuItem1.Size = New System.Drawing.Size(436, 30)
        Me.EXITToolStripMenuItem1.Text = "EXIT"
        '
        'PERFOMANCEToolStripMenuItem
        '
        Me.PERFOMANCEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PERFOMANCEToolStripMenuItem.BackgroundImage = CType(resources.GetObject("PERFOMANCEToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.PERFOMANCEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PERFOMANCEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PERFORMANCEFORMToolStripMenuItem, Me.GROUPPERFORMANCEFORMToolStripMenuItem, Me.PROGRESSGRAPHToolStripMenuItem})
        Me.PERFOMANCEToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.PERFOMANCEToolStripMenuItem.Name = "PERFOMANCEToolStripMenuItem"
        Me.PERFOMANCEToolStripMenuItem.Size = New System.Drawing.Size(170, 78)
        Me.PERFOMANCEToolStripMenuItem.Text = "PERFOMANCE"
        '
        'PERFORMANCEFORMToolStripMenuItem
        '
        Me.PERFORMANCEFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PERFORMANCEFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("PERFORMANCEFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.PERFORMANCEFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PERFORMANCEFORMToolStripMenuItem.Name = "PERFORMANCEFORMToolStripMenuItem"
        Me.PERFORMANCEFORMToolStripMenuItem.Size = New System.Drawing.Size(556, 30)
        Me.PERFORMANCEFORMToolStripMenuItem.Text = "PERFORMANCE FORM/REPORT FORM"
        '
        'GROUPPERFORMANCEFORMToolStripMenuItem
        '
        Me.GROUPPERFORMANCEFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPPERFORMANCEFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("GROUPPERFORMANCEFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.GROUPPERFORMANCEFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GROUPPERFORMANCEFORMToolStripMenuItem.Name = "GROUPPERFORMANCEFORMToolStripMenuItem"
        Me.GROUPPERFORMANCEFORMToolStripMenuItem.Size = New System.Drawing.Size(556, 30)
        Me.GROUPPERFORMANCEFORMToolStripMenuItem.Text = "SEARCH STUDENT PERFOMANCE HISTORY"
        '
        'PROGRESSGRAPHToolStripMenuItem
        '
        Me.PROGRESSGRAPHToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PROGRESSGRAPHToolStripMenuItem.BackgroundImage = CType(resources.GetObject("PROGRESSGRAPHToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.PROGRESSGRAPHToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PROGRESSGRAPHToolStripMenuItem.Checked = True
        Me.PROGRESSGRAPHToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked
        Me.PROGRESSGRAPHToolStripMenuItem.Name = "PROGRESSGRAPHToolStripMenuItem"
        Me.PROGRESSGRAPHToolStripMenuItem.Size = New System.Drawing.Size(556, 30)
        Me.PROGRESSGRAPHToolStripMenuItem.Text = "SEARCH AN EXAM'S PERFOMANCE/RANKING"
        '
        'PAYMENTSToolStripMenuItem
        '
        Me.PAYMENTSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PAYMENTSToolStripMenuItem.BackgroundImage = CType(resources.GetObject("PAYMENTSToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.PAYMENTSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.PAYMENTSToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PAYMENTFORMToolStripMenuItem, Me.PAYMENTGROUPFORMToolStripMenuItem, Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem})
        Me.PAYMENTSToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.PAYMENTSToolStripMenuItem.Name = "PAYMENTSToolStripMenuItem"
        Me.PAYMENTSToolStripMenuItem.Size = New System.Drawing.Size(140, 78)
        Me.PAYMENTSToolStripMenuItem.Text = "PAYMENTS"
        '
        'PAYMENTFORMToolStripMenuItem
        '
        Me.PAYMENTFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PAYMENTFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("PAYMENTFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.PAYMENTFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PAYMENTFORMToolStripMenuItem.Name = "PAYMENTFORMToolStripMenuItem"
        Me.PAYMENTFORMToolStripMenuItem.Size = New System.Drawing.Size(604, 30)
        Me.PAYMENTFORMToolStripMenuItem.Text = "PAYMENT FORM"
        '
        'PAYMENTGROUPFORMToolStripMenuItem
        '
        Me.PAYMENTGROUPFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PAYMENTGROUPFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("PAYMENTGROUPFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.PAYMENTGROUPFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.PAYMENTGROUPFORMToolStripMenuItem.Name = "PAYMENTGROUPFORMToolStripMenuItem"
        Me.PAYMENTGROUPFORMToolStripMenuItem.Size = New System.Drawing.Size(604, 30)
        Me.PAYMENTGROUPFORMToolStripMenuItem.Text = "SEARCH STUDENT PAYMENTS HISTORY "
        '
        'SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem
        '
        Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.BackgroundImage = CType(resources.GetObject("SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.Name = "SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem"
        Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.Size = New System.Drawing.Size(604, 30)
        Me.SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.Text = "SEARCH FOR GROUP/ CLASS PAYMENTS DETAILS"
        '
        'ACCOUNTToolStripMenuItem
        '
        Me.ACCOUNTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ACCOUNTToolStripMenuItem.BackgroundImage = CType(resources.GetObject("ACCOUNTToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.ACCOUNTToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ACCOUNTToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ACCOUNTSETTINSToolStripMenuItem})
        Me.ACCOUNTToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.ACCOUNTToolStripMenuItem.Name = "ACCOUNTToolStripMenuItem"
        Me.ACCOUNTToolStripMenuItem.Size = New System.Drawing.Size(127, 78)
        Me.ACCOUNTToolStripMenuItem.Text = "ACCOUNT"
        '
        'ACCOUNTSETTINSToolStripMenuItem
        '
        Me.ACCOUNTSETTINSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ACCOUNTSETTINSToolStripMenuItem.BackgroundImage = CType(resources.GetObject("ACCOUNTSETTINSToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.ACCOUNTSETTINSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ACCOUNTSETTINSToolStripMenuItem.Name = "ACCOUNTSETTINSToolStripMenuItem"
        Me.ACCOUNTSETTINSToolStripMenuItem.Size = New System.Drawing.Size(284, 30)
        Me.ACCOUNTSETTINSToolStripMenuItem.Text = "ACCOUNT SETTINS"
        '
        'ATTENDANCEToolStripMenuItem
        '
        Me.ATTENDANCEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ATTENDANCEToolStripMenuItem.BackgroundImage = CType(resources.GetObject("ATTENDANCEToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.ATTENDANCEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ATTENDANCEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ATTANDANCEFORMToolStripMenuItem, Me.ATTANDANCEGROUPFORMToolStripMenuItem})
        Me.ATTENDANCEToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.ATTENDANCEToolStripMenuItem.Name = "ATTENDANCEToolStripMenuItem"
        Me.ATTENDANCEToolStripMenuItem.Size = New System.Drawing.Size(166, 78)
        Me.ATTENDANCEToolStripMenuItem.Text = "ATTENDANCE"
        '
        'ATTANDANCEFORMToolStripMenuItem
        '
        Me.ATTANDANCEFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ATTANDANCEFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("ATTANDANCEFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.ATTANDANCEFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ATTANDANCEFORMToolStripMenuItem.Name = "ATTANDANCEFORMToolStripMenuItem"
        Me.ATTANDANCEFORMToolStripMenuItem.Size = New System.Drawing.Size(378, 30)
        Me.ATTANDANCEFORMToolStripMenuItem.Text = "ATTANDANCE FORM"
        '
        'ATTANDANCEGROUPFORMToolStripMenuItem
        '
        Me.ATTANDANCEGROUPFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ATTANDANCEGROUPFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("ATTANDANCEGROUPFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.ATTANDANCEGROUPFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.ATTANDANCEGROUPFORMToolStripMenuItem.Name = "ATTANDANCEGROUPFORMToolStripMenuItem"
        Me.ATTANDANCEGROUPFORMToolStripMenuItem.Size = New System.Drawing.Size(378, 30)
        Me.ATTANDANCEGROUPFORMToolStripMenuItem.Text = "ATTANDANCE GROUP FORM"
        '
        'HELPToolStripMenuItem
        '
        Me.HELPToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.HELPToolStripMenuItem.BackgroundImage = CType(resources.GetObject("HELPToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.HELPToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.HELPToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HELPFORMToolStripMenuItem, Me.GROUPTIMETABLEToolStripMenuItem, Me.EDITEXAMSTIMETABLEToolStripMenuItem, Me.GROUPEXAMSTIMETABLEToolStripMenuItem, Me.EDITDUTYROLLToolStripMenuItem, Me.GROUPDUTYROLLToolStripMenuItem})
        Me.HELPToolStripMenuItem.ForeColor = System.Drawing.Color.Navy
        Me.HELPToolStripMenuItem.Name = "HELPToolStripMenuItem"
        Me.HELPToolStripMenuItem.Size = New System.Drawing.Size(145, 78)
        Me.HELPToolStripMenuItem.Text = "TIMETABLE"
        '
        'HELPFORMToolStripMenuItem
        '
        Me.HELPFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.HELPFORMToolStripMenuItem.BackgroundImage = CType(resources.GetObject("HELPFORMToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.HELPFORMToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.HELPFORMToolStripMenuItem.Name = "HELPFORMToolStripMenuItem"
        Me.HELPFORMToolStripMenuItem.Size = New System.Drawing.Size(367, 30)
        Me.HELPFORMToolStripMenuItem.Text = "EDIT FORM"
        '
        'GROUPTIMETABLEToolStripMenuItem
        '
        Me.GROUPTIMETABLEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPTIMETABLEToolStripMenuItem.BackgroundImage = CType(resources.GetObject("GROUPTIMETABLEToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.GROUPTIMETABLEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GROUPTIMETABLEToolStripMenuItem.Name = "GROUPTIMETABLEToolStripMenuItem"
        Me.GROUPTIMETABLEToolStripMenuItem.Size = New System.Drawing.Size(367, 30)
        Me.GROUPTIMETABLEToolStripMenuItem.Text = "GROUP TIMETABLE"
        '
        'EDITEXAMSTIMETABLEToolStripMenuItem
        '
        Me.EDITEXAMSTIMETABLEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.EDITEXAMSTIMETABLEToolStripMenuItem.BackgroundImage = CType(resources.GetObject("EDITEXAMSTIMETABLEToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.EDITEXAMSTIMETABLEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.EDITEXAMSTIMETABLEToolStripMenuItem.Name = "EDITEXAMSTIMETABLEToolStripMenuItem"
        Me.EDITEXAMSTIMETABLEToolStripMenuItem.Size = New System.Drawing.Size(367, 30)
        Me.EDITEXAMSTIMETABLEToolStripMenuItem.Text = "EDIT EXAMS TIMETABLE"
        '
        'GROUPEXAMSTIMETABLEToolStripMenuItem
        '
        Me.GROUPEXAMSTIMETABLEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPEXAMSTIMETABLEToolStripMenuItem.BackgroundImage = CType(resources.GetObject("GROUPEXAMSTIMETABLEToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.GROUPEXAMSTIMETABLEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GROUPEXAMSTIMETABLEToolStripMenuItem.Name = "GROUPEXAMSTIMETABLEToolStripMenuItem"
        Me.GROUPEXAMSTIMETABLEToolStripMenuItem.Size = New System.Drawing.Size(367, 30)
        Me.GROUPEXAMSTIMETABLEToolStripMenuItem.Text = "GROUP EXAMS TIMETABLE"
        '
        'EDITDUTYROLLToolStripMenuItem
        '
        Me.EDITDUTYROLLToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.EDITDUTYROLLToolStripMenuItem.BackgroundImage = CType(resources.GetObject("EDITDUTYROLLToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.EDITDUTYROLLToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.EDITDUTYROLLToolStripMenuItem.Name = "EDITDUTYROLLToolStripMenuItem"
        Me.EDITDUTYROLLToolStripMenuItem.Size = New System.Drawing.Size(367, 30)
        Me.EDITDUTYROLLToolStripMenuItem.Text = "EDIT DUTY ROLL"
        '
        'GROUPDUTYROLLToolStripMenuItem
        '
        Me.GROUPDUTYROLLToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPDUTYROLLToolStripMenuItem.BackgroundImage = CType(resources.GetObject("GROUPDUTYROLLToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.GROUPDUTYROLLToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.GROUPDUTYROLLToolStripMenuItem.Name = "GROUPDUTYROLLToolStripMenuItem"
        Me.GROUPDUTYROLLToolStripMenuItem.Size = New System.Drawing.Size(367, 30)
        Me.GROUPDUTYROLLToolStripMenuItem.Text = "GROUP DUTY ROLL"
        '
        'HELPToolStripMenuItem1
        '
        Me.HELPToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.HELPToolStripMenuItem1.BackgroundImage = CType(resources.GetObject("HELPToolStripMenuItem1.BackgroundImage"), System.Drawing.Image)
        Me.HELPToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.HELPToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HELPToolStripMenuItem2})
        Me.HELPToolStripMenuItem1.ForeColor = System.Drawing.Color.Navy
        Me.HELPToolStripMenuItem1.Name = "HELPToolStripMenuItem1"
        Me.HELPToolStripMenuItem1.Size = New System.Drawing.Size(79, 78)
        Me.HELPToolStripMenuItem1.Text = "HELP"
        '
        'HELPToolStripMenuItem2
        '
        Me.HELPToolStripMenuItem2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.HELPToolStripMenuItem2.BackgroundImage = CType(resources.GetObject("HELPToolStripMenuItem2.BackgroundImage"), System.Drawing.Image)
        Me.HELPToolStripMenuItem2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.HELPToolStripMenuItem2.Name = "HELPToolStripMenuItem2"
        Me.HELPToolStripMenuItem2.Size = New System.Drawing.Size(139, 30)
        Me.HELPToolStripMenuItem2.Text = "HELP"
        '
        'ContextMenuStrip1
        '
        Me.ContextMenuStrip1.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ContextMenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRATIONToolStripMenuItem1, Me.PERFORMANCEToolStripMenuItem, Me.PAYMENTSToolStripMenuItem1, Me.ATTENDANCEToolStripMenuItem1, Me.TIMETABLESCHEDULEToolStripMenuItem, Me.HELPToolStripMenuItem3, Me.EXITToolStripMenuItem})
        Me.ContextMenuStrip1.Name = "ContextMenuStrip1"
        Me.ContextMenuStrip1.Size = New System.Drawing.Size(213, 158)
        '
        'REGISTRATIONToolStripMenuItem1
        '
        Me.REGISTRATIONToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.REGISTRATIONToolStripMenuItem1.BackgroundImage = CType(resources.GetObject("REGISTRATIONToolStripMenuItem1.BackgroundImage"), System.Drawing.Image)
        Me.REGISTRATIONToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom
        Me.REGISTRATIONToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.REGISTRATIONFORMToolStripMenuItem1, Me.SEARCHSTUDENTDETAILSToolStripMenuItem})
        Me.REGISTRATIONToolStripMenuItem1.Name = "REGISTRATIONToolStripMenuItem1"
        Me.REGISTRATIONToolStripMenuItem1.Size = New System.Drawing.Size(197, 22)
        Me.REGISTRATIONToolStripMenuItem1.Text = "REGISTRATION"
        '
        'REGISTRATIONFORMToolStripMenuItem1
        '
        Me.REGISTRATIONFORMToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.REGISTRATIONFORMToolStripMenuItem1.BackgroundImage = CType(resources.GetObject("REGISTRATIONFORMToolStripMenuItem1.BackgroundImage"), System.Drawing.Image)
        Me.REGISTRATIONFORMToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.REGISTRATIONFORMToolStripMenuItem1.Name = "REGISTRATIONFORMToolStripMenuItem1"
        Me.REGISTRATIONFORMToolStripMenuItem1.Size = New System.Drawing.Size(219, 22)
        Me.REGISTRATIONFORMToolStripMenuItem1.Text = "REGISTRATION FORM"
        '
        'SEARCHSTUDENTDETAILSToolStripMenuItem
        '
        Me.SEARCHSTUDENTDETAILSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SEARCHSTUDENTDETAILSToolStripMenuItem.BackgroundImage = CType(resources.GetObject("SEARCHSTUDENTDETAILSToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.SEARCHSTUDENTDETAILSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SEARCHSTUDENTDETAILSToolStripMenuItem.Name = "SEARCHSTUDENTDETAILSToolStripMenuItem"
        Me.SEARCHSTUDENTDETAILSToolStripMenuItem.Size = New System.Drawing.Size(219, 22)
        Me.SEARCHSTUDENTDETAILSToolStripMenuItem.Text = "SEARCH STUDENT DETAILS"
        '
        'PERFORMANCEToolStripMenuItem
        '
        Me.PERFORMANCEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PERFORMANCEToolStripMenuItem.BackgroundImage = CType(resources.GetObject("PERFORMANCEToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.PERFORMANCEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PERFORMANCEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PERFORMANCEFORMToolStripMenuItem1, Me.SEARCHSTUDENTToolStripMenuItem, Me.SEARCHEXAMSToolStripMenuItem})
        Me.PERFORMANCEToolStripMenuItem.Name = "PERFORMANCEToolStripMenuItem"
        Me.PERFORMANCEToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.PERFORMANCEToolStripMenuItem.Text = "PERFORMANCE"
        '
        'PERFORMANCEFORMToolStripMenuItem1
        '
        Me.PERFORMANCEFORMToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PERFORMANCEFORMToolStripMenuItem1.Name = "PERFORMANCEFORMToolStripMenuItem1"
        Me.PERFORMANCEFORMToolStripMenuItem1.Size = New System.Drawing.Size(194, 22)
        Me.PERFORMANCEFORMToolStripMenuItem1.Text = "PERFORMANCE FORM"
        '
        'SEARCHSTUDENTToolStripMenuItem
        '
        Me.SEARCHSTUDENTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SEARCHSTUDENTToolStripMenuItem.BackgroundImage = CType(resources.GetObject("SEARCHSTUDENTToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.SEARCHSTUDENTToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SEARCHSTUDENTToolStripMenuItem.Name = "SEARCHSTUDENTToolStripMenuItem"
        Me.SEARCHSTUDENTToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.SEARCHSTUDENTToolStripMenuItem.Text = "SEARCH STUDENT"
        '
        'SEARCHEXAMSToolStripMenuItem
        '
        Me.SEARCHEXAMSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SEARCHEXAMSToolStripMenuItem.BackgroundImage = CType(resources.GetObject("SEARCHEXAMSToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.SEARCHEXAMSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SEARCHEXAMSToolStripMenuItem.Name = "SEARCHEXAMSToolStripMenuItem"
        Me.SEARCHEXAMSToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.SEARCHEXAMSToolStripMenuItem.Text = "SEARCH EXAMS"
        '
        'PAYMENTSToolStripMenuItem1
        '
        Me.PAYMENTSToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PAYMENTSToolStripMenuItem1.BackgroundImage = CType(resources.GetObject("PAYMENTSToolStripMenuItem1.BackgroundImage"), System.Drawing.Image)
        Me.PAYMENTSToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.PAYMENTSToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.PAYEMENTToolStripMenuItem, Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem})
        Me.PAYMENTSToolStripMenuItem1.Name = "PAYMENTSToolStripMenuItem1"
        Me.PAYMENTSToolStripMenuItem1.Size = New System.Drawing.Size(197, 22)
        Me.PAYMENTSToolStripMenuItem1.Text = "PAYMENTS"
        '
        'PAYEMENTToolStripMenuItem
        '
        Me.PAYEMENTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.PAYEMENTToolStripMenuItem.Name = "PAYEMENTToolStripMenuItem"
        Me.PAYEMENTToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.PAYEMENTToolStripMenuItem.Text = "PAYEMENT"
        '
        'SEARCHPAYEMENTSDETAILSToolStripMenuItem
        '
        Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem.BackgroundImage = CType(resources.GetObject("SEARCHPAYEMENTSDETAILSToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem.Name = "SEARCHPAYEMENTSDETAILSToolStripMenuItem"
        Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem.Size = New System.Drawing.Size(235, 22)
        Me.SEARCHPAYEMENTSDETAILSToolStripMenuItem.Text = "SEARCH PAYEMENTS DETAILS"
        '
        'ATTENDANCEToolStripMenuItem1
        '
        Me.ATTENDANCEToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ATTENDANCEToolStripMenuItem1.BackgroundImage = CType(resources.GetObject("ATTENDANCEToolStripMenuItem1.BackgroundImage"), System.Drawing.Image)
        Me.ATTENDANCEToolStripMenuItem1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.ATTENDANCEToolStripMenuItem1.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ATTAENDANCEFORMToolStripMenuItem, Me.SEARCHDETAILSToolStripMenuItem})
        Me.ATTENDANCEToolStripMenuItem1.Name = "ATTENDANCEToolStripMenuItem1"
        Me.ATTENDANCEToolStripMenuItem1.Size = New System.Drawing.Size(197, 22)
        Me.ATTENDANCEToolStripMenuItem1.Text = "ATTENDANCE"
        '
        'ATTAENDANCEFORMToolStripMenuItem
        '
        Me.ATTAENDANCEFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.ATTAENDANCEFORMToolStripMenuItem.Name = "ATTAENDANCEFORMToolStripMenuItem"
        Me.ATTAENDANCEFORMToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.ATTAENDANCEFORMToolStripMenuItem.Text = "ATTAENDANCE FORM"
        '
        'SEARCHDETAILSToolStripMenuItem
        '
        Me.SEARCHDETAILSToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.SEARCHDETAILSToolStripMenuItem.BackgroundImage = CType(resources.GetObject("SEARCHDETAILSToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.SEARCHDETAILSToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None
        Me.SEARCHDETAILSToolStripMenuItem.Name = "SEARCHDETAILSToolStripMenuItem"
        Me.SEARCHDETAILSToolStripMenuItem.Size = New System.Drawing.Size(194, 22)
        Me.SEARCHDETAILSToolStripMenuItem.Text = "SEARCH DETAILS"
        '
        'TIMETABLESCHEDULEToolStripMenuItem
        '
        Me.TIMETABLESCHEDULEToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TIMETABLESCHEDULEToolStripMenuItem.BackgroundImage = CType(resources.GetObject("TIMETABLESCHEDULEToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.TIMETABLESCHEDULEToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.TIMETABLESCHEDULEToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.TIMETABLEFORMToolStripMenuItem, Me.GROUPTIMETABLEToolStripMenuItem1, Me.EXAMTTFORMToolStripMenuItem, Me.GROUPEXAMSTTToolStripMenuItem, Me.DUTYROLLFORMToolStripMenuItem, Me.GROUPROLLToolStripMenuItem})
        Me.TIMETABLESCHEDULEToolStripMenuItem.Name = "TIMETABLESCHEDULEToolStripMenuItem"
        Me.TIMETABLESCHEDULEToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.TIMETABLESCHEDULEToolStripMenuItem.Text = "TIMETABLE/SCHEDULE"
        '
        'TIMETABLEFORMToolStripMenuItem
        '
        Me.TIMETABLEFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.TIMETABLEFORMToolStripMenuItem.Name = "TIMETABLEFORMToolStripMenuItem"
        Me.TIMETABLEFORMToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.TIMETABLEFORMToolStripMenuItem.Text = "TIME TABLE FORM"
        '
        'GROUPTIMETABLEToolStripMenuItem1
        '
        Me.GROUPTIMETABLEToolStripMenuItem1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPTIMETABLEToolStripMenuItem1.Name = "GROUPTIMETABLEToolStripMenuItem1"
        Me.GROUPTIMETABLEToolStripMenuItem1.Size = New System.Drawing.Size(180, 22)
        Me.GROUPTIMETABLEToolStripMenuItem1.Text = "GROUP TIME TABLE"
        '
        'EXAMTTFORMToolStripMenuItem
        '
        Me.EXAMTTFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.EXAMTTFORMToolStripMenuItem.Name = "EXAMTTFORMToolStripMenuItem"
        Me.EXAMTTFORMToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.EXAMTTFORMToolStripMenuItem.Text = "EXAM TT FORM"
        '
        'GROUPEXAMSTTToolStripMenuItem
        '
        Me.GROUPEXAMSTTToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPEXAMSTTToolStripMenuItem.Name = "GROUPEXAMSTTToolStripMenuItem"
        Me.GROUPEXAMSTTToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.GROUPEXAMSTTToolStripMenuItem.Text = "GROUP EXAMS TT"
        '
        'DUTYROLLFORMToolStripMenuItem
        '
        Me.DUTYROLLFORMToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.DUTYROLLFORMToolStripMenuItem.Name = "DUTYROLLFORMToolStripMenuItem"
        Me.DUTYROLLFORMToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.DUTYROLLFORMToolStripMenuItem.Text = "DUTY ROLL FORM"
        '
        'GROUPROLLToolStripMenuItem
        '
        Me.GROUPROLLToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.GROUPROLLToolStripMenuItem.Name = "GROUPROLLToolStripMenuItem"
        Me.GROUPROLLToolStripMenuItem.Size = New System.Drawing.Size(180, 22)
        Me.GROUPROLLToolStripMenuItem.Text = "GROUP ROLL "
        '
        'HELPToolStripMenuItem3
        '
        Me.HELPToolStripMenuItem3.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.HELPToolStripMenuItem3.BackgroundImage = CType(resources.GetObject("HELPToolStripMenuItem3.BackgroundImage"), System.Drawing.Image)
        Me.HELPToolStripMenuItem3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.HELPToolStripMenuItem3.Name = "HELPToolStripMenuItem3"
        Me.HELPToolStripMenuItem3.Size = New System.Drawing.Size(197, 22)
        Me.HELPToolStripMenuItem3.Text = "HELP"
        '
        'EXITToolStripMenuItem
        '
        Me.EXITToolStripMenuItem.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.EXITToolStripMenuItem.BackgroundImage = CType(resources.GetObject("EXITToolStripMenuItem.BackgroundImage"), System.Drawing.Image)
        Me.EXITToolStripMenuItem.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center
        Me.EXITToolStripMenuItem.Name = "EXITToolStripMenuItem"
        Me.EXITToolStripMenuItem.Size = New System.Drawing.Size(197, 22)
        Me.EXITToolStripMenuItem.Text = "EXIT"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = CType(resources.GetObject("$this.BackgroundImage"), System.Drawing.Image)
        Me.ClientSize = New System.Drawing.Size(859, 360)
        Me.ContextMenuStrip = Me.ContextMenuStrip1
        Me.Controls.Add(Me.MenuStrip1)
        Me.IsMdiContainer = True
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "Form1"
        Me.Text = "MAIN FORM"
        Me.WindowState = System.Windows.Forms.FormWindowState.Maximized
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.ContextMenuStrip1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents PERFOMANCEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PERFORMANCEFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPPERFORMANCEFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REGISTRATIONToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REGISTRATIONFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPSREGISTRATIONFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PAYMENTSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PAYMENTFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PAYMENTGROUPFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PROGRESSGRAPHToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACCOUNTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ACCOUNTSETTINSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ATTENDANCEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ATTANDANCEFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ATTANDANCEGROUPFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPTIMETABLEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EDITEXAMSTIMETABLEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPEXAMSTIMETABLEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EDITDUTYROLLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPDUTYROLLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ContextMenuStrip1 As System.Windows.Forms.ContextMenuStrip
    Friend WithEvents REGISTRATIONToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents REGISTRATIONFORMToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SEARCHSTUDENTDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PERFORMANCEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PERFORMANCEFORMToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SEARCHSTUDENTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SEARCHEXAMSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PAYMENTSToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PAYEMENTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SEARCHPAYEMENTSDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ATTENDANCEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ATTAENDANCEFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SEARCHDETAILSToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIMETABLESCHEDULEToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TIMETABLEFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPTIMETABLEToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXAMTTFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPEXAMSTTToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents DUTYROLLFORMToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents GROUPROLLToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents HELPToolStripMenuItem3 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents EXITToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem

End Class
