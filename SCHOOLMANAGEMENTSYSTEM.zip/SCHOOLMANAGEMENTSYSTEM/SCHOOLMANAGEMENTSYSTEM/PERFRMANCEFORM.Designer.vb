﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PERFRMANCEFORM
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim KCPERESULTLabel As System.Windows.Forms.Label
        Dim POINTSLabel As System.Windows.Forms.Label
        Dim StudentpicLabel As System.Windows.Forms.Label
        Dim TOTALGRADELabel As System.Windows.Forms.Label
        Dim HOMESCIENCLabel As System.Windows.Forms.Label
        Dim DATELabel As System.Windows.Forms.Label
        Dim SEGRADELabel1 As System.Windows.Forms.Label
        Dim TERMLabel As System.Windows.Forms.Label
        Dim STUDENTNUMBERLabel As System.Windows.Forms.Label
        Dim EXAMREFNOLabel As System.Windows.Forms.Label
        Dim SEGRADELabel As System.Windows.Forms.Label
        Dim Label2 As System.Windows.Forms.Label
        Dim Label1 As System.Windows.Forms.Label
        Dim GEOGRAPHYLabel As System.Windows.Forms.Label
        Dim CRELabel As System.Windows.Forms.Label
        Dim HISTORYLabel As System.Windows.Forms.Label
        Dim AGRICULTURELabel As System.Windows.Forms.Label
        Dim COMPSTUDIESLabel As System.Windows.Forms.Label
        Dim BUSINESSSTUDIESLabel As System.Windows.Forms.Label
        Dim PHYSICSLabel As System.Windows.Forms.Label
        Dim CHEMISTRYLabel As System.Windows.Forms.Label
        Dim BIOLOGYLabel As System.Windows.Forms.Label
        Dim KISWAHILILabel As System.Windows.Forms.Label
        Dim MATHSLabel As System.Windows.Forms.Label
        Dim ENGLISHLabel As System.Windows.Forms.Label
        Dim EXAMSPERIODLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(PERFRMANCEFORM))
        Me.PERFORMANCEBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.PERFORMANCEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database1DataSet = New SCHOOLMANAGEMENTSYSTEM.Database1DataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.PERFORMANCEBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.PrintDocument1 = New System.Drawing.Printing.PrintDocument()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.REGISTATIONBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.REGISTATIONDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewImageColumn1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn2 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SearchToolStrip = New System.Windows.Forms.ToolStrip()
        Me._LIKEToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me._LIKEToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.SearchToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.PERFORMANCEDataGridView1 = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn58 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn59 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn60 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn61 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn62 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn63 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn64 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn65 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn66 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn67 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn68 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn69 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn70 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn71 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn72 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn73 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn74 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn75 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn76 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn77 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn78 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn79 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn80 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn81 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn82 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn83 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn84 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn85 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn86 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn87 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn88 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn89 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn90 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn91 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn92 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn93 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn94 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn95 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn96 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SearchToolStrip1 = New System.Windows.Forms.ToolStrip()
        Me._LIKEToolStripLabel1 = New System.Windows.Forms.ToolStripLabel()
        Me._LIKEToolStripTextBox1 = New System.Windows.Forms.ToolStripTextBox()
        Me.SearchToolStripButton1 = New System.Windows.Forms.ToolStripButton()
        Me.PERFORMANCETableAdapter = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.PERFORMANCETableAdapter()
        Me.TableAdapterManager = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager()
        Me.REGISTATIONTableAdapter = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.REGISTATIONTableAdapter()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.TextBox5 = New System.Windows.Forms.TextBox()
        Me.TextBox2 = New System.Windows.Forms.TextBox()
        Me.TextBox9 = New System.Windows.Forms.TextBox()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.TextBox8 = New System.Windows.Forms.TextBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.EXAMSPERIODComboBox = New System.Windows.Forms.ComboBox()
        Me.PERFORMANCEDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn24 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn25 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn26 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn27 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn28 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn29 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn30 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn31 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn32 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn33 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn34 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn35 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn36 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn37 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn38 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn39 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn40 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn41 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn42 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn43 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn44 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn45 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn46 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn47 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn48 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn49 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn50 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn51 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn52 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn53 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn54 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn55 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn56 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn57 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ComboBox1 = New System.Windows.Forms.ComboBox()
        Me.TextBox7 = New System.Windows.Forms.TextBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.TextBox6 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.KCPERESULTTextBox = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.POINTSTextBox = New System.Windows.Forms.TextBox()
        Me.StudentpicPictureBox = New System.Windows.Forms.PictureBox()
        Me.TOTALGRADETextBox = New System.Windows.Forms.TextBox()
        Me.H_SGRADETextBox = New System.Windows.Forms.TextBox()
        Me.HOMESCIENCTextBox = New System.Windows.Forms.TextBox()
        Me.DATEDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.SEGRADETextBox = New System.Windows.Forms.TextBox()
        Me.TERMTextBox = New System.Windows.Forms.TextBox()
        Me.STUDENTNUMBERTextBox = New System.Windows.Forms.TextBox()
        Me.EXAMREFNOTextBox = New System.Windows.Forms.TextBox()
        Me.SOCIALETHICSTextBox = New System.Windows.Forms.TextBox()
        Me.GEOGRADETextBox = New System.Windows.Forms.TextBox()
        Me.GEOGRAPHYTextBox = New System.Windows.Forms.TextBox()
        Me.CREGRADETextBox = New System.Windows.Forms.TextBox()
        Me.CRETextBox = New System.Windows.Forms.TextBox()
        Me.GRADEHISTextBox = New System.Windows.Forms.TextBox()
        Me.HISTORYTextBox = New System.Windows.Forms.TextBox()
        Me.AGRIGRADETextBox = New System.Windows.Forms.TextBox()
        Me.AGRICULTURETextBox = New System.Windows.Forms.TextBox()
        Me.CGRADETextBox = New System.Windows.Forms.TextBox()
        Me.COMPSTUDIESTextBox = New System.Windows.Forms.TextBox()
        Me.BGRADETextBox = New System.Windows.Forms.TextBox()
        Me.BUSINESSSTUDIESTextBox = New System.Windows.Forms.TextBox()
        Me.PHYSICSGRADETextBox = New System.Windows.Forms.TextBox()
        Me.PHYSICSTextBox = New System.Windows.Forms.TextBox()
        Me.CHEMGRADETextBox = New System.Windows.Forms.TextBox()
        Me.CHEMISTRYTextBox = New System.Windows.Forms.TextBox()
        Me.BIOGRADETextBox = New System.Windows.Forms.TextBox()
        Me.BIOLOGYTextBox = New System.Windows.Forms.TextBox()
        Me.KISWAGRADETextBox = New System.Windows.Forms.TextBox()
        Me.KISWAHILITextBox = New System.Windows.Forms.TextBox()
        Me.MATHSGRADETextBox = New System.Windows.Forms.TextBox()
        Me.MATHSTextBox = New System.Windows.Forms.TextBox()
        Me.ENGGRADETextBox = New System.Windows.Forms.TextBox()
        Me.ENGLISHTextBox = New System.Windows.Forms.TextBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        KCPERESULTLabel = New System.Windows.Forms.Label()
        POINTSLabel = New System.Windows.Forms.Label()
        StudentpicLabel = New System.Windows.Forms.Label()
        TOTALGRADELabel = New System.Windows.Forms.Label()
        HOMESCIENCLabel = New System.Windows.Forms.Label()
        DATELabel = New System.Windows.Forms.Label()
        SEGRADELabel1 = New System.Windows.Forms.Label()
        TERMLabel = New System.Windows.Forms.Label()
        STUDENTNUMBERLabel = New System.Windows.Forms.Label()
        EXAMREFNOLabel = New System.Windows.Forms.Label()
        SEGRADELabel = New System.Windows.Forms.Label()
        Label2 = New System.Windows.Forms.Label()
        Label1 = New System.Windows.Forms.Label()
        GEOGRAPHYLabel = New System.Windows.Forms.Label()
        CRELabel = New System.Windows.Forms.Label()
        HISTORYLabel = New System.Windows.Forms.Label()
        AGRICULTURELabel = New System.Windows.Forms.Label()
        COMPSTUDIESLabel = New System.Windows.Forms.Label()
        BUSINESSSTUDIESLabel = New System.Windows.Forms.Label()
        PHYSICSLabel = New System.Windows.Forms.Label()
        CHEMISTRYLabel = New System.Windows.Forms.Label()
        BIOLOGYLabel = New System.Windows.Forms.Label()
        KISWAHILILabel = New System.Windows.Forms.Label()
        MATHSLabel = New System.Windows.Forms.Label()
        ENGLISHLabel = New System.Windows.Forms.Label()
        EXAMSPERIODLabel = New System.Windows.Forms.Label()
        CType(Me.PERFORMANCEBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.PERFORMANCEBindingNavigator.SuspendLayout()
        CType(Me.PERFORMANCEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REGISTATIONBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REGISTATIONDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SearchToolStrip.SuspendLayout()
        CType(Me.PERFORMANCEDataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SearchToolStrip1.SuspendLayout()
        Me.GroupBox2.SuspendLayout()
        CType(Me.PERFORMANCEDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.StudentpicPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'KCPERESULTLabel
        '
        KCPERESULTLabel.AutoSize = True
        KCPERESULTLabel.Location = New System.Drawing.Point(603, 26)
        KCPERESULTLabel.Name = "KCPERESULTLabel"
        KCPERESULTLabel.Size = New System.Drawing.Size(82, 13)
        KCPERESULTLabel.TabIndex = 79
        KCPERESULTLabel.Text = "KCPE RESULT:"
        '
        'POINTSLabel
        '
        POINTSLabel.AutoSize = True
        POINTSLabel.Location = New System.Drawing.Point(261, 559)
        POINTSLabel.Name = "POINTSLabel"
        POINTSLabel.Size = New System.Drawing.Size(51, 13)
        POINTSLabel.TabIndex = 62
        POINTSLabel.Text = "POINTS:"
        '
        'StudentpicLabel
        '
        StudentpicLabel.AutoSize = True
        StudentpicLabel.Location = New System.Drawing.Point(702, 26)
        StudentpicLabel.Name = "StudentpicLabel"
        StudentpicLabel.Size = New System.Drawing.Size(70, 13)
        StudentpicLabel.TabIndex = 61
        StudentpicLabel.Text = "studentpic:"
        '
        'TOTALGRADELabel
        '
        TOTALGRADELabel.AutoSize = True
        TOTALGRADELabel.Location = New System.Drawing.Point(438, 554)
        TOTALGRADELabel.Name = "TOTALGRADELabel"
        TOTALGRADELabel.Size = New System.Drawing.Size(84, 13)
        TOTALGRADELabel.TabIndex = 58
        TOTALGRADELabel.Text = "TOTALGRADE:"
        '
        'HOMESCIENCLabel
        '
        HOMESCIENCLabel.AutoSize = True
        HOMESCIENCLabel.Location = New System.Drawing.Point(7, 532)
        HOMESCIENCLabel.Name = "HOMESCIENCLabel"
        HOMESCIENCLabel.Size = New System.Drawing.Size(90, 13)
        HOMESCIENCLabel.TabIndex = 54
        HOMESCIENCLabel.Text = "HOME SCIENCE:"
        '
        'DATELabel
        '
        DATELabel.AutoSize = True
        DATELabel.Location = New System.Drawing.Point(15, 177)
        DATELabel.Name = "DATELabel"
        DATELabel.Size = New System.Drawing.Size(39, 13)
        DATELabel.TabIndex = 51
        DATELabel.Text = "DATE:"
        '
        'SEGRADELabel1
        '
        SEGRADELabel1.AutoSize = True
        SEGRADELabel1.Location = New System.Drawing.Point(6, 143)
        SEGRADELabel1.Name = "SEGRADELabel1"
        SEGRADELabel1.Size = New System.Drawing.Size(91, 13)
        SEGRADELabel1.TabIndex = 49
        SEGRADELabel1.Text = "STUDENT NAME"
        '
        'TERMLabel
        '
        TERMLabel.AutoSize = True
        TERMLabel.Location = New System.Drawing.Point(6, 117)
        TERMLabel.Name = "TERMLabel"
        TERMLabel.Size = New System.Drawing.Size(117, 13)
        TERMLabel.TabIndex = 47
        TERMLabel.Text = "YEAR/TERM/CLASS:"
        '
        'STUDENTNUMBERLabel
        '
        STUDENTNUMBERLabel.AutoSize = True
        STUDENTNUMBERLabel.Location = New System.Drawing.Point(6, 94)
        STUDENTNUMBERLabel.Name = "STUDENTNUMBERLabel"
        STUDENTNUMBERLabel.Size = New System.Drawing.Size(109, 13)
        STUDENTNUMBERLabel.TabIndex = 45
        STUDENTNUMBERLabel.Text = "STUDENT NUMBER:"
        '
        'EXAMREFNOLabel
        '
        EXAMREFNOLabel.AutoSize = True
        EXAMREFNOLabel.Location = New System.Drawing.Point(15, 75)
        EXAMREFNOLabel.Name = "EXAMREFNOLabel"
        EXAMREFNOLabel.Size = New System.Drawing.Size(82, 13)
        EXAMREFNOLabel.TabIndex = 43
        EXAMREFNOLabel.Text = "EXAM REF NO:"
        '
        'SEGRADELabel
        '
        SEGRADELabel.AutoSize = True
        SEGRADELabel.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        SEGRADELabel.Location = New System.Drawing.Point(15, 556)
        SEGRADELabel.Name = "SEGRADELabel"
        SEGRADELabel.Size = New System.Drawing.Size(113, 16)
        SEGRADELabel.TabIndex = 10
        SEGRADELabel.Text = "TOTAL MARKS"
        '
        'Label2
        '
        Label2.AutoSize = True
        Label2.Location = New System.Drawing.Point(456, 198)
        Label2.Name = "Label2"
        Label2.Size = New System.Drawing.Size(45, 13)
        Label2.TabIndex = 38
        Label2.Text = "GRADE"
        '
        'Label1
        '
        Label1.AutoSize = True
        Label1.Location = New System.Drawing.Point(261, 198)
        Label1.Name = "Label1"
        Label1.Size = New System.Drawing.Size(47, 13)
        Label1.TabIndex = 37
        Label1.Text = "MARKS"
        '
        'GEOGRAPHYLabel
        '
        GEOGRAPHYLabel.AutoSize = True
        GEOGRAPHYLabel.Location = New System.Drawing.Point(7, 507)
        GEOGRAPHYLabel.Name = "GEOGRAPHYLabel"
        GEOGRAPHYLabel.Size = New System.Drawing.Size(78, 13)
        GEOGRAPHYLabel.TabIndex = 33
        GEOGRAPHYLabel.Text = "GEOGRAPHY:"
        '
        'CRELabel
        '
        CRELabel.AutoSize = True
        CRELabel.Location = New System.Drawing.Point(12, 481)
        CRELabel.Name = "CRELabel"
        CRELabel.Size = New System.Drawing.Size(31, 13)
        CRELabel.TabIndex = 30
        CRELabel.Text = "CRE:"
        '
        'HISTORYLabel
        '
        HISTORYLabel.AutoSize = True
        HISTORYLabel.Location = New System.Drawing.Point(12, 458)
        HISTORYLabel.Name = "HISTORYLabel"
        HISTORYLabel.Size = New System.Drawing.Size(60, 13)
        HISTORYLabel.TabIndex = 27
        HISTORYLabel.Text = "HISTORY:"
        '
        'AGRICULTURELabel
        '
        AGRICULTURELabel.AutoSize = True
        AGRICULTURELabel.Location = New System.Drawing.Point(12, 432)
        AGRICULTURELabel.Name = "AGRICULTURELabel"
        AGRICULTURELabel.Size = New System.Drawing.Size(89, 13)
        AGRICULTURELabel.TabIndex = 24
        AGRICULTURELabel.Text = "AGRICULTURE:"
        '
        'COMPSTUDIESLabel
        '
        COMPSTUDIESLabel.AutoSize = True
        COMPSTUDIESLabel.Location = New System.Drawing.Point(5, 399)
        COMPSTUDIESLabel.Name = "COMPSTUDIESLabel"
        COMPSTUDIESLabel.Size = New System.Drawing.Size(122, 13)
        COMPSTUDIESLabel.TabIndex = 21
        COMPSTUDIESLabel.Text = "COMPUTER STUDIES:"
        '
        'BUSINESSSTUDIESLabel
        '
        BUSINESSSTUDIESLabel.AutoSize = True
        BUSINESSSTUDIESLabel.Location = New System.Drawing.Point(8, 374)
        BUSINESSSTUDIESLabel.Name = "BUSINESSSTUDIESLabel"
        BUSINESSSTUDIESLabel.Size = New System.Drawing.Size(115, 13)
        BUSINESSSTUDIESLabel.TabIndex = 18
        BUSINESSSTUDIESLabel.Text = "BUSINESS STUDIES:"
        '
        'PHYSICSLabel
        '
        PHYSICSLabel.AutoSize = True
        PHYSICSLabel.Location = New System.Drawing.Point(14, 348)
        PHYSICSLabel.Name = "PHYSICSLabel"
        PHYSICSLabel.Size = New System.Drawing.Size(58, 13)
        PHYSICSLabel.TabIndex = 15
        PHYSICSLabel.Text = "PHYSICS:"
        '
        'CHEMISTRYLabel
        '
        CHEMISTRYLabel.AutoSize = True
        CHEMISTRYLabel.Location = New System.Drawing.Point(10, 321)
        CHEMISTRYLabel.Name = "CHEMISTRYLabel"
        CHEMISTRYLabel.Size = New System.Drawing.Size(75, 13)
        CHEMISTRYLabel.TabIndex = 12
        CHEMISTRYLabel.Text = "CHEMISTRY:"
        '
        'BIOLOGYLabel
        '
        BIOLOGYLabel.AutoSize = True
        BIOLOGYLabel.Location = New System.Drawing.Point(15, 286)
        BIOLOGYLabel.Name = "BIOLOGYLabel"
        BIOLOGYLabel.Size = New System.Drawing.Size(59, 13)
        BIOLOGYLabel.TabIndex = 9
        BIOLOGYLabel.Text = "BIOLOGY:"
        '
        'KISWAHILILabel
        '
        KISWAHILILabel.AutoSize = True
        KISWAHILILabel.Location = New System.Drawing.Point(15, 260)
        KISWAHILILabel.Name = "KISWAHILILabel"
        KISWAHILILabel.Size = New System.Drawing.Size(72, 13)
        KISWAHILILabel.TabIndex = 6
        KISWAHILILabel.Text = "KISWAHILI:"
        '
        'MATHSLabel
        '
        MATHSLabel.AutoSize = True
        MATHSLabel.Location = New System.Drawing.Point(15, 242)
        MATHSLabel.Name = "MATHSLabel"
        MATHSLabel.Size = New System.Drawing.Size(50, 13)
        MATHSLabel.TabIndex = 3
        MATHSLabel.Text = "MATHS:"
        '
        'ENGLISHLabel
        '
        ENGLISHLabel.AutoSize = True
        ENGLISHLabel.Location = New System.Drawing.Point(15, 218)
        ENGLISHLabel.Name = "ENGLISHLabel"
        ENGLISHLabel.Size = New System.Drawing.Size(57, 13)
        ENGLISHLabel.TabIndex = 0
        ENGLISHLabel.Text = "ENGLISH:"
        '
        'EXAMSPERIODLabel
        '
        EXAMSPERIODLabel.AutoSize = True
        EXAMSPERIODLabel.Location = New System.Drawing.Point(573, 203)
        EXAMSPERIODLabel.Name = "EXAMSPERIODLabel"
        EXAMSPERIODLabel.Size = New System.Drawing.Size(90, 13)
        EXAMSPERIODLabel.TabIndex = 95
        EXAMSPERIODLabel.Text = "EXAMSPERIOD:"
        EXAMSPERIODLabel.Visible = False
        '
        'PERFORMANCEBindingNavigator
        '
        Me.PERFORMANCEBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.PERFORMANCEBindingNavigator.BindingSource = Me.PERFORMANCEBindingSource
        Me.PERFORMANCEBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.PERFORMANCEBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.PERFORMANCEBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.PERFORMANCEBindingNavigatorSaveItem})
        Me.PERFORMANCEBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.PERFORMANCEBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.PERFORMANCEBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.PERFORMANCEBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.PERFORMANCEBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.PERFORMANCEBindingNavigator.Name = "PERFORMANCEBindingNavigator"
        Me.PERFORMANCEBindingNavigator.Padding = New System.Windows.Forms.Padding(0)
        Me.PERFORMANCEBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.PERFORMANCEBindingNavigator.Size = New System.Drawing.Size(1129, 25)
        Me.PERFORMANCEBindingNavigator.TabIndex = 0
        Me.PERFORMANCEBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'PERFORMANCEBindingSource
        '
        Me.PERFORMANCEBindingSource.DataMember = "PERFORMANCE"
        Me.PERFORMANCEBindingSource.DataSource = Me.Database1DataSet
        '
        'Database1DataSet
        '
        Me.Database1DataSet.DataSetName = "Database1DataSet"
        Me.Database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(58, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'PERFORMANCEBindingNavigatorSaveItem
        '
        Me.PERFORMANCEBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.PERFORMANCEBindingNavigatorSaveItem.Image = CType(resources.GetObject("PERFORMANCEBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.PERFORMANCEBindingNavigatorSaveItem.Name = "PERFORMANCEBindingNavigatorSaveItem"
        Me.PERFORMANCEBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.PERFORMANCEBindingNavigatorSaveItem.Text = "Save Data"
        '
        'PrintDocument1
        '
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Document = Me.PrintDocument1
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(871, 255)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(108, 31)
        Me.Button3.TabIndex = 41
        Me.Button3.Text = "PRINT"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(871, 221)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(108, 23)
        Me.Button2.TabIndex = 40
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(871, 172)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(108, 23)
        Me.Button1.TabIndex = 39
        Me.Button1.Text = "ADD NEW"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'REGISTATIONBindingSource
        '
        Me.REGISTATIONBindingSource.DataMember = "REGISTATION"
        Me.REGISTATIONBindingSource.DataSource = Me.Database1DataSet
        '
        'REGISTATIONDataGridView
        '
        Me.REGISTATIONDataGridView.AutoGenerateColumns = False
        Me.REGISTATIONDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.REGISTATIONDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewImageColumn1, Me.DataGridViewImageColumn2, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19})
        Me.REGISTATIONDataGridView.DataSource = Me.REGISTATIONBindingSource
        Me.REGISTATIONDataGridView.Location = New System.Drawing.Point(880, 616)
        Me.REGISTATIONDataGridView.Name = "REGISTATIONDataGridView"
        Me.REGISTATIONDataGridView.Size = New System.Drawing.Size(143, 99)
        Me.REGISTATIONDataGridView.TabIndex = 41
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "FIRSTNAME"
        Me.DataGridViewTextBoxColumn1.HeaderText = "FIRSTNAME"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "MIDDLENAME"
        Me.DataGridViewTextBoxColumn2.HeaderText = "MIDDLENAME"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "LASTNAME"
        Me.DataGridViewTextBoxColumn3.HeaderText = "LASTNAME"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "DATEOFBIRTH"
        Me.DataGridViewTextBoxColumn4.HeaderText = "DATEOFBIRTH"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "ADDRESS"
        Me.DataGridViewTextBoxColumn5.HeaderText = "ADDRESS"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "PHONENUMBER"
        Me.DataGridViewTextBoxColumn6.HeaderText = "PHONENUMBER"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "EMAIL"
        Me.DataGridViewTextBoxColumn7.HeaderText = "EMAIL"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "NEXTOFKIN"
        Me.DataGridViewTextBoxColumn8.HeaderText = "NEXTOFKIN"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "NEXTOFKINRELATION"
        Me.DataGridViewTextBoxColumn9.HeaderText = "NEXTOFKINRELATION"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "REGISTRATIONDATE"
        Me.DataGridViewTextBoxColumn10.HeaderText = "REGISTRATIONDATE"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "CLASS"
        Me.DataGridViewTextBoxColumn11.HeaderText = "CLASS"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn12.HeaderText = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "GENDER"
        Me.DataGridViewTextBoxColumn13.HeaderText = "GENDER"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewImageColumn1
        '
        Me.DataGridViewImageColumn1.DataPropertyName = "studentpic"
        Me.DataGridViewImageColumn1.HeaderText = "studentpic"
        Me.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1"
        '
        'DataGridViewImageColumn2
        '
        Me.DataGridViewImageColumn2.DataPropertyName = "parentpic"
        Me.DataGridViewImageColumn2.HeaderText = "parentpic"
        Me.DataGridViewImageColumn2.Name = "DataGridViewImageColumn2"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "SECONDGUARDIAN"
        Me.DataGridViewTextBoxColumn14.HeaderText = "SECONDGUARDIAN"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "IDNUMBER"
        Me.DataGridViewTextBoxColumn15.HeaderText = "IDNUMBER"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "SECONDGUARDIANPHONENUMBER"
        Me.DataGridViewTextBoxColumn16.HeaderText = "SECONDGUARDIANPHONENUMBER"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "RESIDENT"
        Me.DataGridViewTextBoxColumn17.HeaderText = "RESIDENT"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.DataPropertyName = "GUARDIANOccupation "
        Me.DataGridViewTextBoxColumn18.HeaderText = "GUARDIANOccupation "
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.DataPropertyName = "KCPERESULT"
        Me.DataGridViewTextBoxColumn19.HeaderText = "KCPERESULT"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        '
        'SearchToolStrip
        '
        Me.SearchToolStrip.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._LIKEToolStripLabel, Me._LIKEToolStripTextBox, Me.SearchToolStripButton})
        Me.SearchToolStrip.Location = New System.Drawing.Point(0, 25)
        Me.SearchToolStrip.Name = "SearchToolStrip"
        Me.SearchToolStrip.Padding = New System.Windows.Forms.Padding(0)
        Me.SearchToolStrip.Size = New System.Drawing.Size(1129, 25)
        Me.SearchToolStrip.TabIndex = 42
        Me.SearchToolStrip.Text = "SearchToolStrip"
        '
        '_LIKEToolStripLabel
        '
        Me._LIKEToolStripLabel.Name = "_LIKEToolStripLabel"
        Me._LIKEToolStripLabel.Size = New System.Drawing.Size(146, 22)
        Me._LIKEToolStripLabel.Text = "Enter Student Number"
        '
        '_LIKEToolStripTextBox
        '
        Me._LIKEToolStripTextBox.Name = "_LIKEToolStripTextBox"
        Me._LIKEToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        'SearchToolStripButton
        '
        Me.SearchToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SearchToolStripButton.ForeColor = System.Drawing.Color.Red
        Me.SearchToolStripButton.Name = "SearchToolStripButton"
        Me.SearchToolStripButton.Size = New System.Drawing.Size(52, 22)
        Me.SearchToolStripButton.Text = "Search"
        '
        'PERFORMANCEDataGridView1
        '
        Me.PERFORMANCEDataGridView1.AutoGenerateColumns = False
        Me.PERFORMANCEDataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PERFORMANCEDataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn58, Me.DataGridViewTextBoxColumn59, Me.DataGridViewTextBoxColumn60, Me.DataGridViewTextBoxColumn61, Me.DataGridViewTextBoxColumn62, Me.DataGridViewTextBoxColumn63, Me.DataGridViewTextBoxColumn64, Me.DataGridViewTextBoxColumn65, Me.DataGridViewTextBoxColumn66, Me.DataGridViewTextBoxColumn67, Me.DataGridViewTextBoxColumn68, Me.DataGridViewTextBoxColumn69, Me.DataGridViewTextBoxColumn70, Me.DataGridViewTextBoxColumn71, Me.DataGridViewTextBoxColumn72, Me.DataGridViewTextBoxColumn73, Me.DataGridViewTextBoxColumn74, Me.DataGridViewTextBoxColumn75, Me.DataGridViewTextBoxColumn76, Me.DataGridViewTextBoxColumn77, Me.DataGridViewTextBoxColumn78, Me.DataGridViewTextBoxColumn79, Me.DataGridViewTextBoxColumn80, Me.DataGridViewTextBoxColumn81, Me.DataGridViewTextBoxColumn82, Me.DataGridViewTextBoxColumn83, Me.DataGridViewTextBoxColumn84, Me.DataGridViewTextBoxColumn85, Me.DataGridViewTextBoxColumn86, Me.DataGridViewTextBoxColumn87, Me.DataGridViewTextBoxColumn88, Me.DataGridViewTextBoxColumn89, Me.DataGridViewTextBoxColumn90, Me.DataGridViewTextBoxColumn91, Me.DataGridViewTextBoxColumn92, Me.DataGridViewTextBoxColumn93, Me.DataGridViewTextBoxColumn94, Me.DataGridViewTextBoxColumn95, Me.DataGridViewTextBoxColumn96})
        Me.PERFORMANCEDataGridView1.DataSource = Me.PERFORMANCEBindingSource
        Me.PERFORMANCEDataGridView1.Location = New System.Drawing.Point(871, 396)
        Me.PERFORMANCEDataGridView1.Name = "PERFORMANCEDataGridView1"
        Me.PERFORMANCEDataGridView1.Size = New System.Drawing.Size(258, 205)
        Me.PERFORMANCEDataGridView1.TabIndex = 95
        Me.PERFORMANCEDataGridView1.Visible = False
        '
        'DataGridViewTextBoxColumn58
        '
        Me.DataGridViewTextBoxColumn58.DataPropertyName = "EXAMREFNO"
        Me.DataGridViewTextBoxColumn58.HeaderText = "EXAMREFNO"
        Me.DataGridViewTextBoxColumn58.Name = "DataGridViewTextBoxColumn58"
        '
        'DataGridViewTextBoxColumn59
        '
        Me.DataGridViewTextBoxColumn59.DataPropertyName = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn59.HeaderText = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn59.Name = "DataGridViewTextBoxColumn59"
        '
        'DataGridViewTextBoxColumn60
        '
        Me.DataGridViewTextBoxColumn60.DataPropertyName = "TERM"
        Me.DataGridViewTextBoxColumn60.HeaderText = "TERM"
        Me.DataGridViewTextBoxColumn60.Name = "DataGridViewTextBoxColumn60"
        '
        'DataGridViewTextBoxColumn61
        '
        Me.DataGridViewTextBoxColumn61.DataPropertyName = "DATE"
        Me.DataGridViewTextBoxColumn61.HeaderText = "DATE"
        Me.DataGridViewTextBoxColumn61.Name = "DataGridViewTextBoxColumn61"
        '
        'DataGridViewTextBoxColumn62
        '
        Me.DataGridViewTextBoxColumn62.DataPropertyName = "ENGLISH"
        Me.DataGridViewTextBoxColumn62.HeaderText = "ENGLISH"
        Me.DataGridViewTextBoxColumn62.Name = "DataGridViewTextBoxColumn62"
        '
        'DataGridViewTextBoxColumn63
        '
        Me.DataGridViewTextBoxColumn63.DataPropertyName = "ENGGRADE"
        Me.DataGridViewTextBoxColumn63.HeaderText = "ENGGRADE"
        Me.DataGridViewTextBoxColumn63.Name = "DataGridViewTextBoxColumn63"
        '
        'DataGridViewTextBoxColumn64
        '
        Me.DataGridViewTextBoxColumn64.DataPropertyName = "MATHS"
        Me.DataGridViewTextBoxColumn64.HeaderText = "MATHS"
        Me.DataGridViewTextBoxColumn64.Name = "DataGridViewTextBoxColumn64"
        '
        'DataGridViewTextBoxColumn65
        '
        Me.DataGridViewTextBoxColumn65.DataPropertyName = "MATHSGRADE"
        Me.DataGridViewTextBoxColumn65.HeaderText = "MATHSGRADE"
        Me.DataGridViewTextBoxColumn65.Name = "DataGridViewTextBoxColumn65"
        '
        'DataGridViewTextBoxColumn66
        '
        Me.DataGridViewTextBoxColumn66.DataPropertyName = "KISWAHILI"
        Me.DataGridViewTextBoxColumn66.HeaderText = "KISWAHILI"
        Me.DataGridViewTextBoxColumn66.Name = "DataGridViewTextBoxColumn66"
        '
        'DataGridViewTextBoxColumn67
        '
        Me.DataGridViewTextBoxColumn67.DataPropertyName = "KISWAGRADE"
        Me.DataGridViewTextBoxColumn67.HeaderText = "KISWAGRADE"
        Me.DataGridViewTextBoxColumn67.Name = "DataGridViewTextBoxColumn67"
        '
        'DataGridViewTextBoxColumn68
        '
        Me.DataGridViewTextBoxColumn68.DataPropertyName = "BIOLOGY"
        Me.DataGridViewTextBoxColumn68.HeaderText = "BIOLOGY"
        Me.DataGridViewTextBoxColumn68.Name = "DataGridViewTextBoxColumn68"
        '
        'DataGridViewTextBoxColumn69
        '
        Me.DataGridViewTextBoxColumn69.DataPropertyName = "BIOGRADE"
        Me.DataGridViewTextBoxColumn69.HeaderText = "BIOGRADE"
        Me.DataGridViewTextBoxColumn69.Name = "DataGridViewTextBoxColumn69"
        '
        'DataGridViewTextBoxColumn70
        '
        Me.DataGridViewTextBoxColumn70.DataPropertyName = "CHEMISTRY"
        Me.DataGridViewTextBoxColumn70.HeaderText = "CHEMISTRY"
        Me.DataGridViewTextBoxColumn70.Name = "DataGridViewTextBoxColumn70"
        '
        'DataGridViewTextBoxColumn71
        '
        Me.DataGridViewTextBoxColumn71.DataPropertyName = "CHEMGRADE"
        Me.DataGridViewTextBoxColumn71.HeaderText = "CHEMGRADE"
        Me.DataGridViewTextBoxColumn71.Name = "DataGridViewTextBoxColumn71"
        '
        'DataGridViewTextBoxColumn72
        '
        Me.DataGridViewTextBoxColumn72.DataPropertyName = "PHYSICS"
        Me.DataGridViewTextBoxColumn72.HeaderText = "PHYSICS"
        Me.DataGridViewTextBoxColumn72.Name = "DataGridViewTextBoxColumn72"
        '
        'DataGridViewTextBoxColumn73
        '
        Me.DataGridViewTextBoxColumn73.DataPropertyName = "PHYSICSGRADE"
        Me.DataGridViewTextBoxColumn73.HeaderText = "PHYSICSGRADE"
        Me.DataGridViewTextBoxColumn73.Name = "DataGridViewTextBoxColumn73"
        '
        'DataGridViewTextBoxColumn74
        '
        Me.DataGridViewTextBoxColumn74.DataPropertyName = "BUSINESSSTUDIES"
        Me.DataGridViewTextBoxColumn74.HeaderText = "BUSINESSSTUDIES"
        Me.DataGridViewTextBoxColumn74.Name = "DataGridViewTextBoxColumn74"
        '
        'DataGridViewTextBoxColumn75
        '
        Me.DataGridViewTextBoxColumn75.DataPropertyName = "BGRADE"
        Me.DataGridViewTextBoxColumn75.HeaderText = "BGRADE"
        Me.DataGridViewTextBoxColumn75.Name = "DataGridViewTextBoxColumn75"
        '
        'DataGridViewTextBoxColumn76
        '
        Me.DataGridViewTextBoxColumn76.DataPropertyName = "COMPSTUDIES"
        Me.DataGridViewTextBoxColumn76.HeaderText = "COMPSTUDIES"
        Me.DataGridViewTextBoxColumn76.Name = "DataGridViewTextBoxColumn76"
        '
        'DataGridViewTextBoxColumn77
        '
        Me.DataGridViewTextBoxColumn77.DataPropertyName = "CGRADE"
        Me.DataGridViewTextBoxColumn77.HeaderText = "CGRADE"
        Me.DataGridViewTextBoxColumn77.Name = "DataGridViewTextBoxColumn77"
        '
        'DataGridViewTextBoxColumn78
        '
        Me.DataGridViewTextBoxColumn78.DataPropertyName = "AGRICULTURE"
        Me.DataGridViewTextBoxColumn78.HeaderText = "AGRICULTURE"
        Me.DataGridViewTextBoxColumn78.Name = "DataGridViewTextBoxColumn78"
        '
        'DataGridViewTextBoxColumn79
        '
        Me.DataGridViewTextBoxColumn79.DataPropertyName = "AGRIGRADE"
        Me.DataGridViewTextBoxColumn79.HeaderText = "AGRIGRADE"
        Me.DataGridViewTextBoxColumn79.Name = "DataGridViewTextBoxColumn79"
        '
        'DataGridViewTextBoxColumn80
        '
        Me.DataGridViewTextBoxColumn80.DataPropertyName = "HOMESCIENCE"
        Me.DataGridViewTextBoxColumn80.HeaderText = "HOMESCIENCE"
        Me.DataGridViewTextBoxColumn80.Name = "DataGridViewTextBoxColumn80"
        '
        'DataGridViewTextBoxColumn81
        '
        Me.DataGridViewTextBoxColumn81.DataPropertyName = "HSGRADE"
        Me.DataGridViewTextBoxColumn81.HeaderText = "HSGRADE"
        Me.DataGridViewTextBoxColumn81.Name = "DataGridViewTextBoxColumn81"
        '
        'DataGridViewTextBoxColumn82
        '
        Me.DataGridViewTextBoxColumn82.DataPropertyName = "HISTORY"
        Me.DataGridViewTextBoxColumn82.HeaderText = "HISTORY"
        Me.DataGridViewTextBoxColumn82.Name = "DataGridViewTextBoxColumn82"
        '
        'DataGridViewTextBoxColumn83
        '
        Me.DataGridViewTextBoxColumn83.DataPropertyName = "GRADEHIS"
        Me.DataGridViewTextBoxColumn83.HeaderText = "GRADEHIS"
        Me.DataGridViewTextBoxColumn83.Name = "DataGridViewTextBoxColumn83"
        '
        'DataGridViewTextBoxColumn84
        '
        Me.DataGridViewTextBoxColumn84.DataPropertyName = "CRE"
        Me.DataGridViewTextBoxColumn84.HeaderText = "CRE"
        Me.DataGridViewTextBoxColumn84.Name = "DataGridViewTextBoxColumn84"
        '
        'DataGridViewTextBoxColumn85
        '
        Me.DataGridViewTextBoxColumn85.DataPropertyName = "CREGRADE"
        Me.DataGridViewTextBoxColumn85.HeaderText = "CREGRADE"
        Me.DataGridViewTextBoxColumn85.Name = "DataGridViewTextBoxColumn85"
        '
        'DataGridViewTextBoxColumn86
        '
        Me.DataGridViewTextBoxColumn86.DataPropertyName = "GEOGRAPHY"
        Me.DataGridViewTextBoxColumn86.HeaderText = "GEOGRAPHY"
        Me.DataGridViewTextBoxColumn86.Name = "DataGridViewTextBoxColumn86"
        '
        'DataGridViewTextBoxColumn87
        '
        Me.DataGridViewTextBoxColumn87.DataPropertyName = "GEOGRADE"
        Me.DataGridViewTextBoxColumn87.HeaderText = "GEOGRADE"
        Me.DataGridViewTextBoxColumn87.Name = "DataGridViewTextBoxColumn87"
        '
        'DataGridViewTextBoxColumn88
        '
        Me.DataGridViewTextBoxColumn88.DataPropertyName = "SOCIALETHICS"
        Me.DataGridViewTextBoxColumn88.HeaderText = "SOCIALETHICS"
        Me.DataGridViewTextBoxColumn88.Name = "DataGridViewTextBoxColumn88"
        '
        'DataGridViewTextBoxColumn89
        '
        Me.DataGridViewTextBoxColumn89.DataPropertyName = "SEGRADE"
        Me.DataGridViewTextBoxColumn89.HeaderText = "SEGRADE"
        Me.DataGridViewTextBoxColumn89.Name = "DataGridViewTextBoxColumn89"
        '
        'DataGridViewTextBoxColumn90
        '
        Me.DataGridViewTextBoxColumn90.DataPropertyName = "HOMESCIENC"
        Me.DataGridViewTextBoxColumn90.HeaderText = "HOMESCIENC"
        Me.DataGridViewTextBoxColumn90.Name = "DataGridViewTextBoxColumn90"
        '
        'DataGridViewTextBoxColumn91
        '
        Me.DataGridViewTextBoxColumn91.DataPropertyName = "H/SGRADE"
        Me.DataGridViewTextBoxColumn91.HeaderText = "H/SGRADE"
        Me.DataGridViewTextBoxColumn91.Name = "DataGridViewTextBoxColumn91"
        '
        'DataGridViewTextBoxColumn92
        '
        Me.DataGridViewTextBoxColumn92.DataPropertyName = "SOCIALED"
        Me.DataGridViewTextBoxColumn92.HeaderText = "SOCIALED"
        Me.DataGridViewTextBoxColumn92.Name = "DataGridViewTextBoxColumn92"
        '
        'DataGridViewTextBoxColumn93
        '
        Me.DataGridViewTextBoxColumn93.DataPropertyName = "SGRADE"
        Me.DataGridViewTextBoxColumn93.HeaderText = "SGRADE"
        Me.DataGridViewTextBoxColumn93.Name = "DataGridViewTextBoxColumn93"
        '
        'DataGridViewTextBoxColumn94
        '
        Me.DataGridViewTextBoxColumn94.DataPropertyName = "POINTS"
        Me.DataGridViewTextBoxColumn94.HeaderText = "POINTS"
        Me.DataGridViewTextBoxColumn94.Name = "DataGridViewTextBoxColumn94"
        '
        'DataGridViewTextBoxColumn95
        '
        Me.DataGridViewTextBoxColumn95.DataPropertyName = "TOTALGRADE"
        Me.DataGridViewTextBoxColumn95.HeaderText = "TOTALGRADE"
        Me.DataGridViewTextBoxColumn95.Name = "DataGridViewTextBoxColumn95"
        '
        'DataGridViewTextBoxColumn96
        '
        Me.DataGridViewTextBoxColumn96.DataPropertyName = "EXAMSPERIOD"
        Me.DataGridViewTextBoxColumn96.HeaderText = "EXAMSPERIOD"
        Me.DataGridViewTextBoxColumn96.Name = "DataGridViewTextBoxColumn96"
        '
        'SearchToolStrip1
        '
        Me.SearchToolStrip1.Font = New System.Drawing.Font("Segoe UI", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.SearchToolStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._LIKEToolStripLabel1, Me._LIKEToolStripTextBox1, Me.SearchToolStripButton1})
        Me.SearchToolStrip1.Location = New System.Drawing.Point(0, 50)
        Me.SearchToolStrip1.Name = "SearchToolStrip1"
        Me.SearchToolStrip1.Padding = New System.Windows.Forms.Padding(0)
        Me.SearchToolStrip1.Size = New System.Drawing.Size(1129, 25)
        Me.SearchToolStrip1.TabIndex = 43
        Me.SearchToolStrip1.Text = "SearchToolStrip1"
        '
        '_LIKEToolStripLabel1
        '
        Me._LIKEToolStripLabel1.Font = New System.Drawing.Font("Segoe UI", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me._LIKEToolStripLabel1.Name = "_LIKEToolStripLabel1"
        Me._LIKEToolStripLabel1.Size = New System.Drawing.Size(163, 22)
        Me._LIKEToolStripLabel1.Text = "ENTER EXAMS REFNUMBER:"
        '
        '_LIKEToolStripTextBox1
        '
        Me._LIKEToolStripTextBox1.Name = "_LIKEToolStripTextBox1"
        Me._LIKEToolStripTextBox1.Size = New System.Drawing.Size(100, 25)
        '
        'SearchToolStripButton1
        '
        Me.SearchToolStripButton1.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.SearchToolStripButton1.ForeColor = System.Drawing.Color.Red
        Me.SearchToolStripButton1.Name = "SearchToolStripButton1"
        Me.SearchToolStripButton1.Size = New System.Drawing.Size(45, 22)
        Me.SearchToolStripButton1.Text = "Search"
        '
        'PERFORMANCETableAdapter
        '
        Me.PERFORMANCETableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.ATTEDANCETableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.EXAMSTIMETABLETableAdapter = Nothing
        Me.TableAdapterManager.loginTableAdapter = Nothing
        Me.TableAdapterManager.PAYMENTTableAdapter = Nothing
        Me.TableAdapterManager.PERFORMANCETableAdapter = Me.PERFORMANCETableAdapter
        Me.TableAdapterManager.REGISTATIONTableAdapter = Nothing
        Me.TableAdapterManager.TDUTIESTableAdapter = Nothing
        Me.TableAdapterManager.timetableTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'REGISTATIONTableAdapter
        '
        Me.REGISTATIONTableAdapter.ClearBeforeFill = True
        '
        'GroupBox2
        '
        Me.GroupBox2.BackColor = System.Drawing.Color.White
        Me.GroupBox2.Controls.Add(Me.PictureBox1)
        Me.GroupBox2.Controls.Add(Me.TextBox5)
        Me.GroupBox2.Controls.Add(Me.TextBox2)
        Me.GroupBox2.Controls.Add(Me.TextBox9)
        Me.GroupBox2.Controls.Add(Me.Label10)
        Me.GroupBox2.Controls.Add(Me.TextBox8)
        Me.GroupBox2.Controls.Add(Me.Label9)
        Me.GroupBox2.Controls.Add(EXAMSPERIODLabel)
        Me.GroupBox2.Controls.Add(Me.EXAMSPERIODComboBox)
        Me.GroupBox2.Controls.Add(Me.PERFORMANCEDataGridView)
        Me.GroupBox2.Controls.Add(Me.ComboBox1)
        Me.GroupBox2.Controls.Add(Me.TextBox7)
        Me.GroupBox2.Controls.Add(Me.Label7)
        Me.GroupBox2.Controls.Add(Me.Label6)
        Me.GroupBox2.Controls.Add(Me.TextBox6)
        Me.GroupBox2.Controls.Add(Me.TextBox4)
        Me.GroupBox2.Controls.Add(Me.TextBox3)
        Me.GroupBox2.Controls.Add(Me.Label35)
        Me.GroupBox2.Controls.Add(Me.Label34)
        Me.GroupBox2.Controls.Add(KCPERESULTLabel)
        Me.GroupBox2.Controls.Add(Me.KCPERESULTTextBox)
        Me.GroupBox2.Controls.Add(Me.Label5)
        Me.GroupBox2.Controls.Add(Me.Label4)
        Me.GroupBox2.Controls.Add(Me.TextBox1)
        Me.GroupBox2.Controls.Add(Me.Label3)
        Me.GroupBox2.Controls.Add(POINTSLabel)
        Me.GroupBox2.Controls.Add(Me.POINTSTextBox)
        Me.GroupBox2.Controls.Add(StudentpicLabel)
        Me.GroupBox2.Controls.Add(Me.StudentpicPictureBox)
        Me.GroupBox2.Controls.Add(TOTALGRADELabel)
        Me.GroupBox2.Controls.Add(Me.TOTALGRADETextBox)
        Me.GroupBox2.Controls.Add(Me.H_SGRADETextBox)
        Me.GroupBox2.Controls.Add(HOMESCIENCLabel)
        Me.GroupBox2.Controls.Add(Me.HOMESCIENCTextBox)
        Me.GroupBox2.Controls.Add(DATELabel)
        Me.GroupBox2.Controls.Add(Me.DATEDateTimePicker)
        Me.GroupBox2.Controls.Add(SEGRADELabel1)
        Me.GroupBox2.Controls.Add(Me.SEGRADETextBox)
        Me.GroupBox2.Controls.Add(TERMLabel)
        Me.GroupBox2.Controls.Add(Me.TERMTextBox)
        Me.GroupBox2.Controls.Add(STUDENTNUMBERLabel)
        Me.GroupBox2.Controls.Add(Me.STUDENTNUMBERTextBox)
        Me.GroupBox2.Controls.Add(EXAMREFNOLabel)
        Me.GroupBox2.Controls.Add(Me.EXAMREFNOTextBox)
        Me.GroupBox2.Controls.Add(SEGRADELabel)
        Me.GroupBox2.Controls.Add(Me.SOCIALETHICSTextBox)
        Me.GroupBox2.Controls.Add(Label2)
        Me.GroupBox2.Controls.Add(Label1)
        Me.GroupBox2.Controls.Add(Me.GEOGRADETextBox)
        Me.GroupBox2.Controls.Add(GEOGRAPHYLabel)
        Me.GroupBox2.Controls.Add(Me.GEOGRAPHYTextBox)
        Me.GroupBox2.Controls.Add(Me.CREGRADETextBox)
        Me.GroupBox2.Controls.Add(CRELabel)
        Me.GroupBox2.Controls.Add(Me.CRETextBox)
        Me.GroupBox2.Controls.Add(Me.GRADEHISTextBox)
        Me.GroupBox2.Controls.Add(HISTORYLabel)
        Me.GroupBox2.Controls.Add(Me.HISTORYTextBox)
        Me.GroupBox2.Controls.Add(Me.AGRIGRADETextBox)
        Me.GroupBox2.Controls.Add(AGRICULTURELabel)
        Me.GroupBox2.Controls.Add(Me.AGRICULTURETextBox)
        Me.GroupBox2.Controls.Add(Me.CGRADETextBox)
        Me.GroupBox2.Controls.Add(COMPSTUDIESLabel)
        Me.GroupBox2.Controls.Add(Me.COMPSTUDIESTextBox)
        Me.GroupBox2.Controls.Add(Me.BGRADETextBox)
        Me.GroupBox2.Controls.Add(BUSINESSSTUDIESLabel)
        Me.GroupBox2.Controls.Add(Me.BUSINESSSTUDIESTextBox)
        Me.GroupBox2.Controls.Add(Me.PHYSICSGRADETextBox)
        Me.GroupBox2.Controls.Add(PHYSICSLabel)
        Me.GroupBox2.Controls.Add(Me.PHYSICSTextBox)
        Me.GroupBox2.Controls.Add(Me.CHEMGRADETextBox)
        Me.GroupBox2.Controls.Add(CHEMISTRYLabel)
        Me.GroupBox2.Controls.Add(Me.CHEMISTRYTextBox)
        Me.GroupBox2.Controls.Add(Me.BIOGRADETextBox)
        Me.GroupBox2.Controls.Add(BIOLOGYLabel)
        Me.GroupBox2.Controls.Add(Me.BIOLOGYTextBox)
        Me.GroupBox2.Controls.Add(Me.KISWAGRADETextBox)
        Me.GroupBox2.Controls.Add(KISWAHILILabel)
        Me.GroupBox2.Controls.Add(Me.KISWAHILITextBox)
        Me.GroupBox2.Controls.Add(Me.MATHSGRADETextBox)
        Me.GroupBox2.Controls.Add(MATHSLabel)
        Me.GroupBox2.Controls.Add(Me.MATHSTextBox)
        Me.GroupBox2.Controls.Add(Me.ENGGRADETextBox)
        Me.GroupBox2.Controls.Add(ENGLISHLabel)
        Me.GroupBox2.Controls.Add(Me.ENGLISHTextBox)
        Me.GroupBox2.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox2.ForeColor = System.Drawing.Color.Navy
        Me.GroupBox2.Location = New System.Drawing.Point(34, 78)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(831, 731)
        Me.GroupBox2.TabIndex = 96
        Me.GroupBox2.TabStop = False
        Me.GroupBox2.Text = "Result Slip"
        '
        'TextBox5
        '
        Me.TextBox5.Location = New System.Drawing.Point(480, 616)
        Me.TextBox5.Name = "TextBox5"
        Me.TextBox5.Size = New System.Drawing.Size(100, 21)
        Me.TextBox5.TabIndex = 102
        '
        'TextBox2
        '
        Me.TextBox2.Location = New System.Drawing.Point(573, 497)
        Me.TextBox2.Name = "TextBox2"
        Me.TextBox2.Size = New System.Drawing.Size(100, 21)
        Me.TextBox2.TabIndex = 101
        '
        'TextBox9
        '
        Me.TextBox9.Location = New System.Drawing.Point(315, 581)
        Me.TextBox9.Name = "TextBox9"
        Me.TextBox9.Size = New System.Drawing.Size(100, 21)
        Me.TextBox9.TabIndex = 100
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(261, 586)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(42, 13)
        Me.Label10.TabIndex = 99
        Me.Label10.Text = "Out Of"
        '
        'TextBox8
        '
        Me.TextBox8.Location = New System.Drawing.Point(155, 578)
        Me.TextBox8.Name = "TextBox8"
        Me.TextBox8.Size = New System.Drawing.Size(100, 21)
        Me.TextBox8.TabIndex = 98
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(100, 581)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(49, 13)
        Me.Label9.TabIndex = 97
        Me.Label9.Text = "Postion"
        '
        'EXAMSPERIODComboBox
        '
        Me.EXAMSPERIODComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "EXAMSPERIOD", True))
        Me.EXAMSPERIODComboBox.FormattingEnabled = True
        Me.EXAMSPERIODComboBox.Items.AddRange(New Object() {"TERM1", "TERM2", "TERM3", "CAT1", "CAT2"})
        Me.EXAMSPERIODComboBox.Location = New System.Drawing.Point(564, 223)
        Me.EXAMSPERIODComboBox.Name = "EXAMSPERIODComboBox"
        Me.EXAMSPERIODComboBox.Size = New System.Drawing.Size(121, 21)
        Me.EXAMSPERIODComboBox.TabIndex = 96
        Me.EXAMSPERIODComboBox.Visible = False
        '
        'PERFORMANCEDataGridView
        '
        Me.PERFORMANCEDataGridView.AutoGenerateColumns = False
        Me.PERFORMANCEDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.PERFORMANCEDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23, Me.DataGridViewTextBoxColumn24, Me.DataGridViewTextBoxColumn25, Me.DataGridViewTextBoxColumn26, Me.DataGridViewTextBoxColumn27, Me.DataGridViewTextBoxColumn28, Me.DataGridViewTextBoxColumn29, Me.DataGridViewTextBoxColumn30, Me.DataGridViewTextBoxColumn31, Me.DataGridViewTextBoxColumn32, Me.DataGridViewTextBoxColumn33, Me.DataGridViewTextBoxColumn34, Me.DataGridViewTextBoxColumn35, Me.DataGridViewTextBoxColumn36, Me.DataGridViewTextBoxColumn37, Me.DataGridViewTextBoxColumn38, Me.DataGridViewTextBoxColumn39, Me.DataGridViewTextBoxColumn40, Me.DataGridViewTextBoxColumn41, Me.DataGridViewTextBoxColumn42, Me.DataGridViewTextBoxColumn43, Me.DataGridViewTextBoxColumn44, Me.DataGridViewTextBoxColumn45, Me.DataGridViewTextBoxColumn46, Me.DataGridViewTextBoxColumn47, Me.DataGridViewTextBoxColumn48, Me.DataGridViewTextBoxColumn49, Me.DataGridViewTextBoxColumn50, Me.DataGridViewTextBoxColumn51, Me.DataGridViewTextBoxColumn52, Me.DataGridViewTextBoxColumn53, Me.DataGridViewTextBoxColumn54, Me.DataGridViewTextBoxColumn55, Me.DataGridViewTextBoxColumn56, Me.DataGridViewTextBoxColumn57})
        Me.PERFORMANCEDataGridView.DataSource = Me.PERFORMANCEBindingSource
        Me.PERFORMANCEDataGridView.Location = New System.Drawing.Point(594, 668)
        Me.PERFORMANCEDataGridView.Name = "PERFORMANCEDataGridView"
        Me.PERFORMANCEDataGridView.Size = New System.Drawing.Size(258, 205)
        Me.PERFORMANCEDataGridView.TabIndex = 95
        Me.PERFORMANCEDataGridView.Visible = False
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.DataPropertyName = "EXAMREFNO"
        Me.DataGridViewTextBoxColumn20.HeaderText = "EXAMREFNO"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.DataPropertyName = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn21.HeaderText = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.DataPropertyName = "TERM"
        Me.DataGridViewTextBoxColumn22.HeaderText = "TERM"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.DataPropertyName = "DATE"
        Me.DataGridViewTextBoxColumn23.HeaderText = "DATE"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        '
        'DataGridViewTextBoxColumn24
        '
        Me.DataGridViewTextBoxColumn24.DataPropertyName = "ENGLISH"
        Me.DataGridViewTextBoxColumn24.HeaderText = "ENGLISH"
        Me.DataGridViewTextBoxColumn24.Name = "DataGridViewTextBoxColumn24"
        '
        'DataGridViewTextBoxColumn25
        '
        Me.DataGridViewTextBoxColumn25.DataPropertyName = "ENGGRADE"
        Me.DataGridViewTextBoxColumn25.HeaderText = "ENGGRADE"
        Me.DataGridViewTextBoxColumn25.Name = "DataGridViewTextBoxColumn25"
        '
        'DataGridViewTextBoxColumn26
        '
        Me.DataGridViewTextBoxColumn26.DataPropertyName = "MATHS"
        Me.DataGridViewTextBoxColumn26.HeaderText = "MATHS"
        Me.DataGridViewTextBoxColumn26.Name = "DataGridViewTextBoxColumn26"
        '
        'DataGridViewTextBoxColumn27
        '
        Me.DataGridViewTextBoxColumn27.DataPropertyName = "MATHSGRADE"
        Me.DataGridViewTextBoxColumn27.HeaderText = "MATHSGRADE"
        Me.DataGridViewTextBoxColumn27.Name = "DataGridViewTextBoxColumn27"
        '
        'DataGridViewTextBoxColumn28
        '
        Me.DataGridViewTextBoxColumn28.DataPropertyName = "KISWAHILI"
        Me.DataGridViewTextBoxColumn28.HeaderText = "KISWAHILI"
        Me.DataGridViewTextBoxColumn28.Name = "DataGridViewTextBoxColumn28"
        '
        'DataGridViewTextBoxColumn29
        '
        Me.DataGridViewTextBoxColumn29.DataPropertyName = "KISWAGRADE"
        Me.DataGridViewTextBoxColumn29.HeaderText = "KISWAGRADE"
        Me.DataGridViewTextBoxColumn29.Name = "DataGridViewTextBoxColumn29"
        '
        'DataGridViewTextBoxColumn30
        '
        Me.DataGridViewTextBoxColumn30.DataPropertyName = "BIOLOGY"
        Me.DataGridViewTextBoxColumn30.HeaderText = "BIOLOGY"
        Me.DataGridViewTextBoxColumn30.Name = "DataGridViewTextBoxColumn30"
        '
        'DataGridViewTextBoxColumn31
        '
        Me.DataGridViewTextBoxColumn31.DataPropertyName = "BIOGRADE"
        Me.DataGridViewTextBoxColumn31.HeaderText = "BIOGRADE"
        Me.DataGridViewTextBoxColumn31.Name = "DataGridViewTextBoxColumn31"
        '
        'DataGridViewTextBoxColumn32
        '
        Me.DataGridViewTextBoxColumn32.DataPropertyName = "CHEMISTRY"
        Me.DataGridViewTextBoxColumn32.HeaderText = "CHEMISTRY"
        Me.DataGridViewTextBoxColumn32.Name = "DataGridViewTextBoxColumn32"
        '
        'DataGridViewTextBoxColumn33
        '
        Me.DataGridViewTextBoxColumn33.DataPropertyName = "CHEMGRADE"
        Me.DataGridViewTextBoxColumn33.HeaderText = "CHEMGRADE"
        Me.DataGridViewTextBoxColumn33.Name = "DataGridViewTextBoxColumn33"
        '
        'DataGridViewTextBoxColumn34
        '
        Me.DataGridViewTextBoxColumn34.DataPropertyName = "PHYSICS"
        Me.DataGridViewTextBoxColumn34.HeaderText = "PHYSICS"
        Me.DataGridViewTextBoxColumn34.Name = "DataGridViewTextBoxColumn34"
        '
        'DataGridViewTextBoxColumn35
        '
        Me.DataGridViewTextBoxColumn35.DataPropertyName = "PHYSICSGRADE"
        Me.DataGridViewTextBoxColumn35.HeaderText = "PHYSICSGRADE"
        Me.DataGridViewTextBoxColumn35.Name = "DataGridViewTextBoxColumn35"
        '
        'DataGridViewTextBoxColumn36
        '
        Me.DataGridViewTextBoxColumn36.DataPropertyName = "BUSINESSSTUDIES"
        Me.DataGridViewTextBoxColumn36.HeaderText = "BUSINESSSTUDIES"
        Me.DataGridViewTextBoxColumn36.Name = "DataGridViewTextBoxColumn36"
        '
        'DataGridViewTextBoxColumn37
        '
        Me.DataGridViewTextBoxColumn37.DataPropertyName = "BGRADE"
        Me.DataGridViewTextBoxColumn37.HeaderText = "BGRADE"
        Me.DataGridViewTextBoxColumn37.Name = "DataGridViewTextBoxColumn37"
        '
        'DataGridViewTextBoxColumn38
        '
        Me.DataGridViewTextBoxColumn38.DataPropertyName = "COMPSTUDIES"
        Me.DataGridViewTextBoxColumn38.HeaderText = "COMPSTUDIES"
        Me.DataGridViewTextBoxColumn38.Name = "DataGridViewTextBoxColumn38"
        '
        'DataGridViewTextBoxColumn39
        '
        Me.DataGridViewTextBoxColumn39.DataPropertyName = "CGRADE"
        Me.DataGridViewTextBoxColumn39.HeaderText = "CGRADE"
        Me.DataGridViewTextBoxColumn39.Name = "DataGridViewTextBoxColumn39"
        '
        'DataGridViewTextBoxColumn40
        '
        Me.DataGridViewTextBoxColumn40.DataPropertyName = "AGRICULTURE"
        Me.DataGridViewTextBoxColumn40.HeaderText = "AGRICULTURE"
        Me.DataGridViewTextBoxColumn40.Name = "DataGridViewTextBoxColumn40"
        '
        'DataGridViewTextBoxColumn41
        '
        Me.DataGridViewTextBoxColumn41.DataPropertyName = "AGRIGRADE"
        Me.DataGridViewTextBoxColumn41.HeaderText = "AGRIGRADE"
        Me.DataGridViewTextBoxColumn41.Name = "DataGridViewTextBoxColumn41"
        '
        'DataGridViewTextBoxColumn42
        '
        Me.DataGridViewTextBoxColumn42.DataPropertyName = "HOMESCIENCE"
        Me.DataGridViewTextBoxColumn42.HeaderText = "HOMESCIENCE"
        Me.DataGridViewTextBoxColumn42.Name = "DataGridViewTextBoxColumn42"
        '
        'DataGridViewTextBoxColumn43
        '
        Me.DataGridViewTextBoxColumn43.DataPropertyName = "HSGRADE"
        Me.DataGridViewTextBoxColumn43.HeaderText = "HSGRADE"
        Me.DataGridViewTextBoxColumn43.Name = "DataGridViewTextBoxColumn43"
        '
        'DataGridViewTextBoxColumn44
        '
        Me.DataGridViewTextBoxColumn44.DataPropertyName = "HISTORY"
        Me.DataGridViewTextBoxColumn44.HeaderText = "HISTORY"
        Me.DataGridViewTextBoxColumn44.Name = "DataGridViewTextBoxColumn44"
        '
        'DataGridViewTextBoxColumn45
        '
        Me.DataGridViewTextBoxColumn45.DataPropertyName = "GRADEHIS"
        Me.DataGridViewTextBoxColumn45.HeaderText = "GRADEHIS"
        Me.DataGridViewTextBoxColumn45.Name = "DataGridViewTextBoxColumn45"
        '
        'DataGridViewTextBoxColumn46
        '
        Me.DataGridViewTextBoxColumn46.DataPropertyName = "CRE"
        Me.DataGridViewTextBoxColumn46.HeaderText = "CRE"
        Me.DataGridViewTextBoxColumn46.Name = "DataGridViewTextBoxColumn46"
        '
        'DataGridViewTextBoxColumn47
        '
        Me.DataGridViewTextBoxColumn47.DataPropertyName = "CREGRADE"
        Me.DataGridViewTextBoxColumn47.HeaderText = "CREGRADE"
        Me.DataGridViewTextBoxColumn47.Name = "DataGridViewTextBoxColumn47"
        '
        'DataGridViewTextBoxColumn48
        '
        Me.DataGridViewTextBoxColumn48.DataPropertyName = "GEOGRAPHY"
        Me.DataGridViewTextBoxColumn48.HeaderText = "GEOGRAPHY"
        Me.DataGridViewTextBoxColumn48.Name = "DataGridViewTextBoxColumn48"
        '
        'DataGridViewTextBoxColumn49
        '
        Me.DataGridViewTextBoxColumn49.DataPropertyName = "GEOGRADE"
        Me.DataGridViewTextBoxColumn49.HeaderText = "GEOGRADE"
        Me.DataGridViewTextBoxColumn49.Name = "DataGridViewTextBoxColumn49"
        '
        'DataGridViewTextBoxColumn50
        '
        Me.DataGridViewTextBoxColumn50.DataPropertyName = "SOCIALETHICS"
        Me.DataGridViewTextBoxColumn50.HeaderText = "SOCIALETHICS"
        Me.DataGridViewTextBoxColumn50.Name = "DataGridViewTextBoxColumn50"
        '
        'DataGridViewTextBoxColumn51
        '
        Me.DataGridViewTextBoxColumn51.DataPropertyName = "SEGRADE"
        Me.DataGridViewTextBoxColumn51.HeaderText = "SEGRADE"
        Me.DataGridViewTextBoxColumn51.Name = "DataGridViewTextBoxColumn51"
        '
        'DataGridViewTextBoxColumn52
        '
        Me.DataGridViewTextBoxColumn52.DataPropertyName = "HOMESCIENC"
        Me.DataGridViewTextBoxColumn52.HeaderText = "HOMESCIENC"
        Me.DataGridViewTextBoxColumn52.Name = "DataGridViewTextBoxColumn52"
        '
        'DataGridViewTextBoxColumn53
        '
        Me.DataGridViewTextBoxColumn53.DataPropertyName = "H/SGRADE"
        Me.DataGridViewTextBoxColumn53.HeaderText = "H/SGRADE"
        Me.DataGridViewTextBoxColumn53.Name = "DataGridViewTextBoxColumn53"
        '
        'DataGridViewTextBoxColumn54
        '
        Me.DataGridViewTextBoxColumn54.DataPropertyName = "SOCIALED"
        Me.DataGridViewTextBoxColumn54.HeaderText = "SOCIALED"
        Me.DataGridViewTextBoxColumn54.Name = "DataGridViewTextBoxColumn54"
        '
        'DataGridViewTextBoxColumn55
        '
        Me.DataGridViewTextBoxColumn55.DataPropertyName = "SGRADE"
        Me.DataGridViewTextBoxColumn55.HeaderText = "SGRADE"
        Me.DataGridViewTextBoxColumn55.Name = "DataGridViewTextBoxColumn55"
        '
        'DataGridViewTextBoxColumn56
        '
        Me.DataGridViewTextBoxColumn56.DataPropertyName = "POINTS"
        Me.DataGridViewTextBoxColumn56.HeaderText = "POINTS"
        Me.DataGridViewTextBoxColumn56.Name = "DataGridViewTextBoxColumn56"
        '
        'DataGridViewTextBoxColumn57
        '
        Me.DataGridViewTextBoxColumn57.DataPropertyName = "TOTALGRADE"
        Me.DataGridViewTextBoxColumn57.HeaderText = "TOTALGRADE"
        Me.DataGridViewTextBoxColumn57.Name = "DataGridViewTextBoxColumn57"
        '
        'ComboBox1
        '
        Me.ComboBox1.FormattingEnabled = True
        Me.ComboBox1.Items.AddRange(New Object() {"term1", "term2", "term3", "cat1", "cat2"})
        Me.ComboBox1.Location = New System.Drawing.Point(567, 250)
        Me.ComboBox1.Name = "ComboBox1"
        Me.ComboBox1.Size = New System.Drawing.Size(103, 21)
        Me.ComboBox1.TabIndex = 94
        Me.ComboBox1.Visible = False
        '
        'TextBox7
        '
        Me.TextBox7.Location = New System.Drawing.Point(573, 361)
        Me.TextBox7.Name = "TextBox7"
        Me.TextBox7.Size = New System.Drawing.Size(73, 21)
        Me.TextBox7.TabIndex = 93
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(557, 330)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(115, 26)
        Me.Label7.TabIndex = 90
        Me.Label7.Text = "+ or - with KCPE vs " & Global.Microsoft.VisualBasic.ChrW(13) & Global.Microsoft.VisualBasic.ChrW(10) & "Exams points"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(444, 619)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(30, 13)
        Me.Label6.TabIndex = 87
        Me.Label6.Text = "sign"
        '
        'TextBox6
        '
        Me.TextBox6.Location = New System.Drawing.Point(134, 602)
        Me.TextBox6.Multiline = True
        Me.TextBox6.Name = "TextBox6"
        Me.TextBox6.Size = New System.Drawing.Size(304, 49)
        Me.TextBox6.TabIndex = 86
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(600, 109)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.ReadOnly = True
        Me.TextBox4.Size = New System.Drawing.Size(85, 21)
        Me.TextBox4.TabIndex = 85
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(567, 293)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(85, 21)
        Me.TextBox3.TabIndex = 84
        '
        'Label35
        '
        Me.Label35.AutoSize = True
        Me.Label35.Location = New System.Drawing.Point(557, 274)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(179, 13)
        Me.Label35.TabIndex = 83
        Me.Label35.Text = " PROGRESS CONTRAST TO KCPE"
        '
        'Label34
        '
        Me.Label34.AutoSize = True
        Me.Label34.Location = New System.Drawing.Point(601, 91)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(78, 13)
        Me.Label34.TabIndex = 81
        Me.Label34.Text = "KCPE POINTS"
        '
        'KCPERESULTTextBox
        '
        Me.KCPERESULTTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "KCPERESULT", True))
        Me.KCPERESULTTextBox.Location = New System.Drawing.Point(604, 53)
        Me.KCPERESULTTextBox.Multiline = True
        Me.KCPERESULTTextBox.Name = "KCPERESULTTextBox"
        Me.KCPERESULTTextBox.ReadOnly = True
        Me.KCPERESULTTextBox.Size = New System.Drawing.Size(85, 35)
        Me.KCPERESULTTextBox.TabIndex = 80
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(5, 624)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(118, 13)
        Me.Label5.TabIndex = 68
        Me.Label5.Text = "Principle's Remarks"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(591, 481)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(30, 13)
        Me.Label4.TabIndex = 66
        Me.Label4.Text = "sign"
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(528, 411)
        Me.TextBox1.Multiline = True
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(223, 69)
        Me.TextBox1.TabIndex = 65
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(552, 385)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(148, 13)
        Me.Label3.TabIndex = 64
        Me.Label3.Text = "Class Teacher's Remarks"
        '
        'POINTSTextBox
        '
        Me.POINTSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "POINTS", True))
        Me.POINTSTextBox.Location = New System.Drawing.Point(320, 556)
        Me.POINTSTextBox.Name = "POINTSTextBox"
        Me.POINTSTextBox.Size = New System.Drawing.Size(85, 21)
        Me.POINTSTextBox.TabIndex = 63
        '
        'StudentpicPictureBox
        '
        Me.StudentpicPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.StudentpicPictureBox.DataBindings.Add(New System.Windows.Forms.Binding("Image", Me.REGISTATIONBindingSource, "studentpic", True))
        Me.StudentpicPictureBox.Location = New System.Drawing.Point(705, 47)
        Me.StudentpicPictureBox.Name = "StudentpicPictureBox"
        Me.StudentpicPictureBox.Size = New System.Drawing.Size(80, 88)
        Me.StudentpicPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.StudentpicPictureBox.TabIndex = 62
        Me.StudentpicPictureBox.TabStop = False
        '
        'TOTALGRADETextBox
        '
        Me.TOTALGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "TOTALGRADE", True))
        Me.TOTALGRADETextBox.Location = New System.Drawing.Point(528, 551)
        Me.TOTALGRADETextBox.Name = "TOTALGRADETextBox"
        Me.TOTALGRADETextBox.Size = New System.Drawing.Size(82, 21)
        Me.TOTALGRADETextBox.TabIndex = 43
        '
        'H_SGRADETextBox
        '
        Me.H_SGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "H/SGRADE", True))
        Me.H_SGRADETextBox.Location = New System.Drawing.Point(396, 524)
        Me.H_SGRADETextBox.Name = "H_SGRADETextBox"
        Me.H_SGRADETextBox.ReadOnly = True
        Me.H_SGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.H_SGRADETextBox.TabIndex = 40
        '
        'HOMESCIENCTextBox
        '
        Me.HOMESCIENCTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "HOMESCIENC", True))
        Me.HOMESCIENCTextBox.Location = New System.Drawing.Point(168, 529)
        Me.HOMESCIENCTextBox.Name = "HOMESCIENCTextBox"
        Me.HOMESCIENCTextBox.Size = New System.Drawing.Size(199, 21)
        Me.HOMESCIENCTextBox.TabIndex = 39
        '
        'DATEDateTimePicker
        '
        Me.DATEDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.PERFORMANCEBindingSource, "DATE", True))
        Me.DATEDateTimePicker.Location = New System.Drawing.Point(189, 169)
        Me.DATEDateTimePicker.Name = "DATEDateTimePicker"
        Me.DATEDateTimePicker.Size = New System.Drawing.Size(295, 21)
        Me.DATEDateTimePicker.TabIndex = 52
        '
        'SEGRADETextBox
        '
        Me.SEGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "SEGRADE", True))
        Me.SEGRADETextBox.Location = New System.Drawing.Point(189, 145)
        Me.SEGRADETextBox.Name = "SEGRADETextBox"
        Me.SEGRADETextBox.Size = New System.Drawing.Size(295, 21)
        Me.SEGRADETextBox.TabIndex = 4
        '
        'TERMTextBox
        '
        Me.TERMTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "TERM", True))
        Me.TERMTextBox.Location = New System.Drawing.Point(189, 117)
        Me.TERMTextBox.Name = "TERMTextBox"
        Me.TERMTextBox.Size = New System.Drawing.Size(295, 21)
        Me.TERMTextBox.TabIndex = 3
        '
        'STUDENTNUMBERTextBox
        '
        Me.STUDENTNUMBERTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "STUDENTNUMBER", True))
        Me.STUDENTNUMBERTextBox.Location = New System.Drawing.Point(189, 91)
        Me.STUDENTNUMBERTextBox.Name = "STUDENTNUMBERTextBox"
        Me.STUDENTNUMBERTextBox.Size = New System.Drawing.Size(295, 21)
        Me.STUDENTNUMBERTextBox.TabIndex = 2
        '
        'EXAMREFNOTextBox
        '
        Me.EXAMREFNOTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "EXAMREFNO", True))
        Me.EXAMREFNOTextBox.Location = New System.Drawing.Point(189, 75)
        Me.EXAMREFNOTextBox.Name = "EXAMREFNOTextBox"
        Me.EXAMREFNOTextBox.Size = New System.Drawing.Size(295, 21)
        Me.EXAMREFNOTextBox.TabIndex = 1
        '
        'SOCIALETHICSTextBox
        '
        Me.SOCIALETHICSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "SOCIALETHICS", True))
        Me.SOCIALETHICSTextBox.Location = New System.Drawing.Point(140, 555)
        Me.SOCIALETHICSTextBox.Name = "SOCIALETHICSTextBox"
        Me.SOCIALETHICSTextBox.Size = New System.Drawing.Size(115, 21)
        Me.SOCIALETHICSTextBox.TabIndex = 41
        '
        'GEOGRADETextBox
        '
        Me.GEOGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "GEOGRADE", True))
        Me.GEOGRADETextBox.Location = New System.Drawing.Point(396, 497)
        Me.GEOGRADETextBox.Name = "GEOGRADETextBox"
        Me.GEOGRADETextBox.ReadOnly = True
        Me.GEOGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.GEOGRADETextBox.TabIndex = 36
        '
        'GEOGRAPHYTextBox
        '
        Me.GEOGRAPHYTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "GEOGRAPHY", True))
        Me.GEOGRAPHYTextBox.Location = New System.Drawing.Point(168, 499)
        Me.GEOGRAPHYTextBox.Name = "GEOGRAPHYTextBox"
        Me.GEOGRAPHYTextBox.Size = New System.Drawing.Size(199, 21)
        Me.GEOGRAPHYTextBox.TabIndex = 34
        '
        'CREGRADETextBox
        '
        Me.CREGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "CREGRADE", True))
        Me.CREGRADETextBox.Location = New System.Drawing.Point(396, 472)
        Me.CREGRADETextBox.Name = "CREGRADETextBox"
        Me.CREGRADETextBox.ReadOnly = True
        Me.CREGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.CREGRADETextBox.TabIndex = 33
        '
        'CRETextBox
        '
        Me.CRETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "CRE", True))
        Me.CRETextBox.Location = New System.Drawing.Point(168, 472)
        Me.CRETextBox.Name = "CRETextBox"
        Me.CRETextBox.Size = New System.Drawing.Size(199, 21)
        Me.CRETextBox.TabIndex = 31
        '
        'GRADEHISTextBox
        '
        Me.GRADEHISTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "GRADEHIS", True))
        Me.GRADEHISTextBox.Location = New System.Drawing.Point(395, 445)
        Me.GRADEHISTextBox.Name = "GRADEHISTextBox"
        Me.GRADEHISTextBox.ReadOnly = True
        Me.GRADEHISTextBox.Size = New System.Drawing.Size(127, 21)
        Me.GRADEHISTextBox.TabIndex = 30
        '
        'HISTORYTextBox
        '
        Me.HISTORYTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "HISTORY", True))
        Me.HISTORYTextBox.Location = New System.Drawing.Point(168, 445)
        Me.HISTORYTextBox.Name = "HISTORYTextBox"
        Me.HISTORYTextBox.Size = New System.Drawing.Size(199, 21)
        Me.HISTORYTextBox.TabIndex = 28
        '
        'AGRIGRADETextBox
        '
        Me.AGRIGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "AGRIGRADE", True))
        Me.AGRIGRADETextBox.Location = New System.Drawing.Point(395, 418)
        Me.AGRIGRADETextBox.Name = "AGRIGRADETextBox"
        Me.AGRIGRADETextBox.ReadOnly = True
        Me.AGRIGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.AGRIGRADETextBox.TabIndex = 27
        '
        'AGRICULTURETextBox
        '
        Me.AGRICULTURETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "AGRICULTURE", True))
        Me.AGRICULTURETextBox.Location = New System.Drawing.Point(168, 418)
        Me.AGRICULTURETextBox.Name = "AGRICULTURETextBox"
        Me.AGRICULTURETextBox.Size = New System.Drawing.Size(199, 21)
        Me.AGRICULTURETextBox.TabIndex = 25
        '
        'CGRADETextBox
        '
        Me.CGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "CGRADE", True))
        Me.CGRADETextBox.Location = New System.Drawing.Point(396, 385)
        Me.CGRADETextBox.Name = "CGRADETextBox"
        Me.CGRADETextBox.ReadOnly = True
        Me.CGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.CGRADETextBox.TabIndex = 24
        '
        'COMPSTUDIESTextBox
        '
        Me.COMPSTUDIESTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "COMPSTUDIES", True))
        Me.COMPSTUDIESTextBox.Location = New System.Drawing.Point(168, 391)
        Me.COMPSTUDIESTextBox.Name = "COMPSTUDIESTextBox"
        Me.COMPSTUDIESTextBox.Size = New System.Drawing.Size(199, 21)
        Me.COMPSTUDIESTextBox.TabIndex = 22
        '
        'BGRADETextBox
        '
        Me.BGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "BGRADE", True))
        Me.BGRADETextBox.Location = New System.Drawing.Point(396, 356)
        Me.BGRADETextBox.Name = "BGRADETextBox"
        Me.BGRADETextBox.ReadOnly = True
        Me.BGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.BGRADETextBox.TabIndex = 21
        '
        'BUSINESSSTUDIESTextBox
        '
        Me.BUSINESSSTUDIESTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "BUSINESSSTUDIES", True))
        Me.BUSINESSSTUDIESTextBox.Location = New System.Drawing.Point(168, 366)
        Me.BUSINESSSTUDIESTextBox.Name = "BUSINESSSTUDIESTextBox"
        Me.BUSINESSSTUDIESTextBox.Size = New System.Drawing.Size(199, 21)
        Me.BUSINESSSTUDIESTextBox.TabIndex = 19
        '
        'PHYSICSGRADETextBox
        '
        Me.PHYSICSGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "PHYSICSGRADE", True))
        Me.PHYSICSGRADETextBox.Location = New System.Drawing.Point(396, 330)
        Me.PHYSICSGRADETextBox.Name = "PHYSICSGRADETextBox"
        Me.PHYSICSGRADETextBox.ReadOnly = True
        Me.PHYSICSGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.PHYSICSGRADETextBox.TabIndex = 18
        '
        'PHYSICSTextBox
        '
        Me.PHYSICSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "PHYSICS", True))
        Me.PHYSICSTextBox.Location = New System.Drawing.Point(168, 339)
        Me.PHYSICSTextBox.Name = "PHYSICSTextBox"
        Me.PHYSICSTextBox.Size = New System.Drawing.Size(199, 21)
        Me.PHYSICSTextBox.TabIndex = 16
        '
        'CHEMGRADETextBox
        '
        Me.CHEMGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "CHEMGRADE", True))
        Me.CHEMGRADETextBox.Location = New System.Drawing.Point(396, 312)
        Me.CHEMGRADETextBox.Name = "CHEMGRADETextBox"
        Me.CHEMGRADETextBox.ReadOnly = True
        Me.CHEMGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.CHEMGRADETextBox.TabIndex = 15
        '
        'CHEMISTRYTextBox
        '
        Me.CHEMISTRYTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "CHEMISTRY", True))
        Me.CHEMISTRYTextBox.Location = New System.Drawing.Point(168, 318)
        Me.CHEMISTRYTextBox.Name = "CHEMISTRYTextBox"
        Me.CHEMISTRYTextBox.Size = New System.Drawing.Size(199, 21)
        Me.CHEMISTRYTextBox.TabIndex = 13
        '
        'BIOGRADETextBox
        '
        Me.BIOGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "BIOGRADE", True))
        Me.BIOGRADETextBox.Location = New System.Drawing.Point(396, 286)
        Me.BIOGRADETextBox.Name = "BIOGRADETextBox"
        Me.BIOGRADETextBox.ReadOnly = True
        Me.BIOGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.BIOGRADETextBox.TabIndex = 12
        '
        'BIOLOGYTextBox
        '
        Me.BIOLOGYTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "BIOLOGY", True))
        Me.BIOLOGYTextBox.Location = New System.Drawing.Point(168, 293)
        Me.BIOLOGYTextBox.Name = "BIOLOGYTextBox"
        Me.BIOLOGYTextBox.Size = New System.Drawing.Size(199, 21)
        Me.BIOLOGYTextBox.TabIndex = 10
        '
        'KISWAGRADETextBox
        '
        Me.KISWAGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "KISWAGRADE", True))
        Me.KISWAGRADETextBox.Location = New System.Drawing.Point(396, 265)
        Me.KISWAGRADETextBox.Name = "KISWAGRADETextBox"
        Me.KISWAGRADETextBox.ReadOnly = True
        Me.KISWAGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.KISWAGRADETextBox.TabIndex = 9
        '
        'KISWAHILITextBox
        '
        Me.KISWAHILITextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "KISWAHILI", True))
        Me.KISWAHILITextBox.Location = New System.Drawing.Point(168, 266)
        Me.KISWAHILITextBox.Name = "KISWAHILITextBox"
        Me.KISWAHILITextBox.Size = New System.Drawing.Size(199, 21)
        Me.KISWAHILITextBox.TabIndex = 7
        '
        'MATHSGRADETextBox
        '
        Me.MATHSGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "MATHSGRADE", True))
        Me.MATHSGRADETextBox.Location = New System.Drawing.Point(396, 239)
        Me.MATHSGRADETextBox.Name = "MATHSGRADETextBox"
        Me.MATHSGRADETextBox.ReadOnly = True
        Me.MATHSGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.MATHSGRADETextBox.TabIndex = 6
        '
        'MATHSTextBox
        '
        Me.MATHSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "MATHS", True))
        Me.MATHSTextBox.Location = New System.Drawing.Point(168, 239)
        Me.MATHSTextBox.Name = "MATHSTextBox"
        Me.MATHSTextBox.Size = New System.Drawing.Size(199, 21)
        Me.MATHSTextBox.TabIndex = 4
        '
        'ENGGRADETextBox
        '
        Me.ENGGRADETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "ENGGRADE", True))
        Me.ENGGRADETextBox.Location = New System.Drawing.Point(396, 216)
        Me.ENGGRADETextBox.Name = "ENGGRADETextBox"
        Me.ENGGRADETextBox.ReadOnly = True
        Me.ENGGRADETextBox.Size = New System.Drawing.Size(127, 21)
        Me.ENGGRADETextBox.TabIndex = 3
        '
        'ENGLISHTextBox
        '
        Me.ENGLISHTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.PERFORMANCEBindingSource, "ENGLISH", True))
        Me.ENGLISHTextBox.Location = New System.Drawing.Point(168, 216)
        Me.ENGLISHTextBox.Name = "ENGLISHTextBox"
        Me.ENGLISHTextBox.Size = New System.Drawing.Size(199, 21)
        Me.ENGLISHTextBox.TabIndex = 5
        '
        'PictureBox1
        '
        Me.PictureBox1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.PictureBox1.Image = CType(resources.GetObject("PictureBox1.Image"), System.Drawing.Image)
        Me.PictureBox1.Location = New System.Drawing.Point(42, 9)
        Me.PictureBox1.Margin = New System.Windows.Forms.Padding(4)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(555, 59)
        Me.PictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.PictureBox1.TabIndex = 103
        Me.PictureBox1.TabStop = False
        '
        'PERFRMANCEFORM
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.AliceBlue
        Me.ClientSize = New System.Drawing.Size(1028, 750)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.PERFORMANCEDataGridView1)
        Me.Controls.Add(Me.SearchToolStrip1)
        Me.Controls.Add(Me.SearchToolStrip)
        Me.Controls.Add(Me.REGISTATIONDataGridView)
        Me.Controls.Add(Me.PERFORMANCEBindingNavigator)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button3)
        Me.Font = New System.Drawing.Font("Tahoma", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Navy
        Me.Name = "PERFRMANCEFORM"
        Me.Text = "PERFRMANCEFORM"
        CType(Me.PERFORMANCEBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.PERFORMANCEBindingNavigator.ResumeLayout(False)
        Me.PERFORMANCEBindingNavigator.PerformLayout()
        CType(Me.PERFORMANCEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REGISTATIONBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REGISTATIONDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SearchToolStrip.ResumeLayout(False)
        Me.SearchToolStrip.PerformLayout()
        CType(Me.PERFORMANCEDataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SearchToolStrip1.ResumeLayout(False)
        Me.SearchToolStrip1.PerformLayout()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox2.PerformLayout()
        CType(Me.PERFORMANCEDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.StudentpicPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Database1DataSet As SCHOOLMANAGEMENTSYSTEM.Database1DataSet
    Friend WithEvents PERFORMANCEBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents PERFORMANCETableAdapter As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.PERFORMANCETableAdapter
    Friend WithEvents TableAdapterManager As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents PERFORMANCEBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents PERFORMANCEBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents PrintDocument1 As System.Drawing.Printing.PrintDocument
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents REGISTATIONBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents REGISTATIONTableAdapter As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.REGISTATIONTableAdapter
    Friend WithEvents REGISTATIONDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn1 As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn2 As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SearchToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents _LIKEToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents _LIKEToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents SearchToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents PERFORMANCEDataGridView1 As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn58 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn59 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn60 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn61 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn62 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn63 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn64 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn65 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn66 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn67 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn68 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn69 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn70 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn71 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn72 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn73 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn74 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn75 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn76 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn77 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn78 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn79 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn80 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn81 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn82 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn83 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn84 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn85 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn86 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn87 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn88 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn89 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn90 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn91 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn92 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn93 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn94 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn95 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn96 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents SearchToolStrip1 As System.Windows.Forms.ToolStrip
    Friend WithEvents _LIKEToolStripLabel1 As System.Windows.Forms.ToolStripLabel
    Friend WithEvents _LIKEToolStripTextBox1 As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents SearchToolStripButton1 As System.Windows.Forms.ToolStripButton
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents PERFORMANCEDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn24 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn25 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn26 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn27 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn28 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn29 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn30 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn31 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn32 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn33 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn34 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn35 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn36 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn37 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn38 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn39 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn40 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn41 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn42 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn43 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn44 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn45 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn46 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn47 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn48 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn49 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn50 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn51 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn52 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn53 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn54 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn55 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn56 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn57 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents ComboBox1 As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox7 As System.Windows.Forms.TextBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents TextBox6 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents KCPERESULTTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents POINTSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentpicPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents TOTALGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents H_SGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents HOMESCIENCTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DATEDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents SEGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents TERMTextBox As System.Windows.Forms.TextBox
    Friend WithEvents STUDENTNUMBERTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EXAMREFNOTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SOCIALETHICSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GEOGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents GEOGRAPHYTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CREGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents CRETextBox As System.Windows.Forms.TextBox
    Friend WithEvents GRADEHISTextBox As System.Windows.Forms.TextBox
    Friend WithEvents HISTORYTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AGRIGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents AGRICULTURETextBox As System.Windows.Forms.TextBox
    Friend WithEvents CGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents COMPSTUDIESTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents BUSINESSSTUDIESTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PHYSICSGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents PHYSICSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CHEMGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents CHEMISTRYTextBox As System.Windows.Forms.TextBox
    Friend WithEvents BIOGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents BIOLOGYTextBox As System.Windows.Forms.TextBox
    Friend WithEvents KISWAGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents KISWAHILITextBox As System.Windows.Forms.TextBox
    Friend WithEvents MATHSGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents MATHSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ENGGRADETextBox As System.Windows.Forms.TextBox
    Friend WithEvents ENGLISHTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EXAMSPERIODComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents TextBox9 As System.Windows.Forms.TextBox
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents TextBox8 As System.Windows.Forms.TextBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents TextBox5 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox2 As System.Windows.Forms.TextBox
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
End Class
