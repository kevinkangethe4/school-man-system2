﻿Imports System.Drawing.Printing
Public Class grouptimetable
    Private mRow As Integer = 0
    Private newpage As Boolean = True
    Private Sub TimetableBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TimetableBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TimetableBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub grouptimetable_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.timetable' table. You can move, or remove it, as needed.
        Me.TimetableTableAdapter.Fill(Me.Database1DataSet.timetable)

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub

    Private Sub TextBox2_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox2.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.timetable
        dv.RowFilter = "[Class] like'" & TextBox2.Text & "%'"

        TimetableDataGridView.DataSource = dv
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.timetable
        dv.RowFilter = "[Day] like'" & TextBox1.Text & "%'"

        TimetableDataGridView.DataSource = dv
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub TextBox3_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs)

    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim PrintDlg As PrintDialog = New PrintDialog()
        Dim PrintDlgRslt As DialogResult = New DialogResult()
        Dim MyDoc As PrintDocument = New PrintDocument()

        PrintDlg.Document = MyDoc

        PrintDlgRslt = PrintDlg.ShowDialog()
        If PrintDlgRslt = Windows.Forms.DialogResult.OK Then
            AddHandler MyDoc.PrintPage, AddressOf PrintDocument1_PrintPage
            MyDoc.Print()
        End If
    End Sub

    Private Sub PrintDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.BeginPrint
        mRow = 0
        newpage = True
        PrintPreviewDialog1.PrintPreviewControl.StartPage = 0
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.0
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.TimetableDataGridView.Width, Me.TimetableDataGridView.Height)
        TimetableDataGridView.DrawToBitmap(bm, New Rectangle(0, 0, Me.TimetableDataGridView.Width, Me.TimetableDataGridView.Height))
        e.Graphics.DrawImage(bm, 0, 0)
    End Sub

    Private Sub TimetableDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub TimetableDataGridView_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs)
       
    End Sub

    Private Sub TimetableDataGridView_CellContentClick_1(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles TimetableDataGridView.CellContentClick

    End Sub

    Private Sub TimetableDataGridView_RowPostPaint1(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles TimetableDataGridView.RowPostPaint
        Dim dg As DataGridView = DirectCast(sender, DataGridView)
        Dim rownumber As String = (e.RowIndex + 1).ToString()
        While rownumber.Length < dg.RowCount.ToString().Length
            rownumber = "0" & rownumber

        End While
        Dim size As SizeF = e.Graphics.MeasureString(rownumber, Me.Font)
        If dg.RowHeadersWidth < CInt(size.Width + 20) Then
            dg.RowHeadersWidth = CInt(size.Width + 20)

        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(rownumber, dg.Font, b, e.RowBounds.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))
    End Sub
End Class