﻿
Imports System.Drawing.Printing
Public Class Form2

    Private Sub ATTEDANCEBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ATTEDANCEBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.ATTEDANCEBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.ATTEDANCE' table. You can move, or remove it, as needed.
        Me.ATTEDANCETableAdapter.Fill(Me.Database1DataSet.ATTEDANCE)

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.ATTEDANCE
        dv.RowFilter = "[studentnumber] like'" & TextBox1.Text & "%'"

        ATTEDANCEDataGridView.DataSource = dv
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim fg As PrintDialog = New PrintDialog
        Dim er As DialogResult = New DialogResult
        Dim mydoc As PrintDocument = New PrintDocument
        fg.Document = mydoc
        er = fg.ShowDialog
        If er = Windows.Forms.DialogResult.OK Then
            AddHandler mydoc.PrintPage, AddressOf PrintDocument1_PrintPage
            mydoc.Print()

        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.ATTEDANCEDataGridView.Width, Me.ATTEDANCEDataGridView.Height)
        ATTEDANCEDataGridView.DrawToBitmap(bm, New Rectangle(0, 0, Me.ATTEDANCEDataGridView.Width, Me.ATTEDANCEDataGridView.Height))
        e.Graphics.DrawImage(bm, 0, 0)
    End Sub
End Class