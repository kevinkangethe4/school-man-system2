﻿Imports System.Data.SqlClient
Public Class login
    Dim xuserid As Integer
    Dim xcountx As Integer
    Dim ix As Double

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
    Private Sub txtUserName_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs)
        Dim dv As DataTable = New DataTable()


    End Sub
    Private Sub txtUserName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub login_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.login' table. You can move, or remove it, as needed.
        Me.LoginTableAdapter.Fill(Me.Database1DataSet.login)
        checkServer()
        xcountx = 0
        username = ""
        xuserid = xUser_ID
        xUser_ID = 0
        txtUserName.Select()
        txtUserName.Text = ""
        LevelTextBox.Visible = False
        LevelTextBox1.Visible = False
        LevelTextBox2.Visible = False
        LevelTextBox3.Visible = False
        LevelTextBox4.Visible = False
        LevelTextBox5.Visible = False
    End Sub

    Private Sub btnSubmit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSubmit.Click
        InsertDefaultUserPermission()
        ExecuteSQLQuery(" SELECT  userName, Passward FROM   login WHERE   (userName = '" & txtUserName.Text & "' ) AND (passward = '" & txtPassword.Text & "')")
        If sqlDT.Rows.Count > 0 Then
            'if match user name & password

            username = sqlDT.Rows(0)("username")
            xUserPassword = sqlDT.Rows(0)("passward")

            txtPassword.Text = ""
            txtUserName.Text = ""

            Form1.Show()
        Else
            MessageBox.Show("Wrong Passward or Username")

        End If
    End Sub

    Private Sub btnClose_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Application.Exit()
    End Sub


  
    Private Sub LoginBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.LoginBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub UsernameToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles UsernameToolStripButton.Click
        Try
            Me.LoginTableAdapter.username(Me.Database1DataSet.login, _LIKEToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub LevelTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LevelTextBox.TextChanged
        If LevelTextBox.Text = "User" Then
            Form1.ACCOUNTToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub LoginBindingNavigator_RefreshItems(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoginBindingNavigator.RefreshItems

    End Sub

    Private Sub LevelTextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LevelTextBox1.TextChanged
        If LevelTextBox.Text = "User" Then
            Form1.PAYMENTSToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub LevelTextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LevelTextBox2.TextChanged
        If LevelTextBox2.Text = "reg" Then
            Form1.PAYMENTSToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub LevelTextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LevelTextBox3.TextChanged
        If LevelTextBox3.Text = "reg" Then
            Form1.ACCOUNTToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub LevelTextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LevelTextBox4.TextChanged
        If LevelTextBox4.Text = "acco" Then
            Form1.PERFOMANCEToolStripMenuItem.Enabled = False
        End If
    End Sub

    Private Sub LevelTextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LevelTextBox5.TextChanged
        If LevelTextBox5.Text = "acco" Then
            Form1.ACCOUNTToolStripMenuItem.Enabled = False
        End If
    End Sub
End Class