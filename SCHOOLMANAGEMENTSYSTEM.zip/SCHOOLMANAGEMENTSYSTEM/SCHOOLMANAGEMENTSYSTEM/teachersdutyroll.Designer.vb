﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class teachersdutyroll
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim WEEKNUMBERLabel As System.Windows.Forms.Label
        Dim DAYRANGELabel As System.Windows.Forms.Label
        Dim TEACHER_S_1Label As System.Windows.Forms.Label
        Dim TEACHER_S2Label As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(teachersdutyroll))
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.WEEKNUMBERTextBox = New System.Windows.Forms.TextBox()
        Me.TDUTIESBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database1DataSet = New SCHOOLMANAGEMENTSYSTEM.Database1DataSet()
        Me.DAYRANGETextBox = New System.Windows.Forms.TextBox()
        Me.TEACHER_S_1TextBox = New System.Windows.Forms.TextBox()
        Me.TEACHER_S2TextBox = New System.Windows.Forms.TextBox()
        Me.TDUTIESTableAdapter = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TDUTIESTableAdapter()
        Me.TableAdapterManager = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager()
        Me.TDUTIESBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TDUTIESBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        WEEKNUMBERLabel = New System.Windows.Forms.Label()
        DAYRANGELabel = New System.Windows.Forms.Label()
        TEACHER_S_1Label = New System.Windows.Forms.Label()
        TEACHER_S2Label = New System.Windows.Forms.Label()
        Me.GroupBox1.SuspendLayout()
        CType(Me.TDUTIESBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TDUTIESBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TDUTIESBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'WEEKNUMBERLabel
        '
        WEEKNUMBERLabel.AutoSize = True
        WEEKNUMBERLabel.Location = New System.Drawing.Point(41, 36)
        WEEKNUMBERLabel.Name = "WEEKNUMBERLabel"
        WEEKNUMBERLabel.Size = New System.Drawing.Size(100, 13)
        WEEKNUMBERLabel.TabIndex = 0
        WEEKNUMBERLabel.Text = "WEEKNUMBER:"
        '
        'DAYRANGELabel
        '
        DAYRANGELabel.AutoSize = True
        DAYRANGELabel.Location = New System.Drawing.Point(41, 62)
        DAYRANGELabel.Name = "DAYRANGELabel"
        DAYRANGELabel.Size = New System.Drawing.Size(91, 13)
        DAYRANGELabel.TabIndex = 2
        DAYRANGELabel.Text = "DATE RANGE:"
        '
        'TEACHER_S_1Label
        '
        TEACHER_S_1Label.AutoSize = True
        TEACHER_S_1Label.Location = New System.Drawing.Point(41, 88)
        TEACHER_S_1Label.Name = "TEACHER_S_1Label"
        TEACHER_S_1Label.Size = New System.Drawing.Size(91, 13)
        TEACHER_S_1Label.TabIndex = 4
        TEACHER_S_1Label.Text = "TEACHER'S 1:"
        '
        'TEACHER_S2Label
        '
        TEACHER_S2Label.AutoSize = True
        TEACHER_S2Label.Location = New System.Drawing.Point(41, 114)
        TEACHER_S2Label.Name = "TEACHER_S2Label"
        TEACHER_S2Label.Size = New System.Drawing.Size(87, 13)
        TEACHER_S2Label.TabIndex = 6
        TEACHER_S2Label.Text = "TEACHER'S2:"
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Controls.Add(WEEKNUMBERLabel)
        Me.GroupBox1.Controls.Add(Me.WEEKNUMBERTextBox)
        Me.GroupBox1.Controls.Add(DAYRANGELabel)
        Me.GroupBox1.Controls.Add(Me.DAYRANGETextBox)
        Me.GroupBox1.Controls.Add(TEACHER_S_1Label)
        Me.GroupBox1.Controls.Add(Me.TEACHER_S_1TextBox)
        Me.GroupBox1.Controls.Add(TEACHER_S2Label)
        Me.GroupBox1.Controls.Add(Me.TEACHER_S2TextBox)
        Me.GroupBox1.Location = New System.Drawing.Point(33, 96)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(792, 257)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        '
        'WEEKNUMBERTextBox
        '
        Me.WEEKNUMBERTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TDUTIESBindingSource, "WEEKNUMBER", True))
        Me.WEEKNUMBERTextBox.Location = New System.Drawing.Point(152, 33)
        Me.WEEKNUMBERTextBox.Name = "WEEKNUMBERTextBox"
        Me.WEEKNUMBERTextBox.Size = New System.Drawing.Size(354, 20)
        Me.WEEKNUMBERTextBox.TabIndex = 1
        '
        'TDUTIESBindingSource
        '
        Me.TDUTIESBindingSource.DataMember = "TDUTIES"
        Me.TDUTIESBindingSource.DataSource = Me.Database1DataSet
        '
        'Database1DataSet
        '
        Me.Database1DataSet.DataSetName = "Database1DataSet"
        Me.Database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'DAYRANGETextBox
        '
        Me.DAYRANGETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TDUTIESBindingSource, "DAYRANGE", True))
        Me.DAYRANGETextBox.Location = New System.Drawing.Point(152, 59)
        Me.DAYRANGETextBox.Name = "DAYRANGETextBox"
        Me.DAYRANGETextBox.Size = New System.Drawing.Size(354, 20)
        Me.DAYRANGETextBox.TabIndex = 3
        '
        'TEACHER_S_1TextBox
        '
        Me.TEACHER_S_1TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TDUTIESBindingSource, "TEACHER'S 1", True))
        Me.TEACHER_S_1TextBox.Location = New System.Drawing.Point(152, 85)
        Me.TEACHER_S_1TextBox.Name = "TEACHER_S_1TextBox"
        Me.TEACHER_S_1TextBox.Size = New System.Drawing.Size(354, 20)
        Me.TEACHER_S_1TextBox.TabIndex = 5
        '
        'TEACHER_S2TextBox
        '
        Me.TEACHER_S2TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TDUTIESBindingSource, "TEACHER'S2", True))
        Me.TEACHER_S2TextBox.Location = New System.Drawing.Point(152, 111)
        Me.TEACHER_S2TextBox.Name = "TEACHER_S2TextBox"
        Me.TEACHER_S2TextBox.Size = New System.Drawing.Size(354, 20)
        Me.TEACHER_S2TextBox.TabIndex = 7
        '
        'TDUTIESTableAdapter
        '
        Me.TDUTIESTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.ATTEDANCETableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.EXAMSTIMETABLETableAdapter = Nothing
        Me.TableAdapterManager.loginTableAdapter = Nothing
        Me.TableAdapterManager.PAYMENTTableAdapter = Nothing
        Me.TableAdapterManager.PERFORMANCETableAdapter = Nothing
        Me.TableAdapterManager.REGISTATIONTableAdapter = Nothing
        Me.TableAdapterManager.TDUTIESTableAdapter = Me.TDUTIESTableAdapter
        Me.TableAdapterManager.timetableTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TDUTIESBindingNavigator
        '
        Me.TDUTIESBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TDUTIESBindingNavigator.BindingSource = Me.TDUTIESBindingSource
        Me.TDUTIESBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TDUTIESBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TDUTIESBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TDUTIESBindingNavigatorSaveItem})
        Me.TDUTIESBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TDUTIESBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TDUTIESBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TDUTIESBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TDUTIESBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TDUTIESBindingNavigator.Name = "TDUTIESBindingNavigator"
        Me.TDUTIESBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TDUTIESBindingNavigator.Size = New System.Drawing.Size(856, 25)
        Me.TDUTIESBindingNavigator.TabIndex = 1
        Me.TDUTIESBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TDUTIESBindingNavigatorSaveItem
        '
        Me.TDUTIESBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TDUTIESBindingNavigatorSaveItem.Image = CType(resources.GetObject("TDUTIESBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TDUTIESBindingNavigatorSaveItem.Name = "TDUTIESBindingNavigatorSaveItem"
        Me.TDUTIESBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TDUTIESBindingNavigatorSaveItem.Text = "Save Data"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(206, 158)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 23)
        Me.Button1.TabIndex = 9
        Me.Button1.Text = "ADD NEW"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(101, 158)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(87, 23)
        Me.Button2.TabIndex = 10
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'teachersdutyroll
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(856, 393)
        Me.Controls.Add(Me.TDUTIESBindingNavigator)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Name = "teachersdutyroll"
        Me.Text = "teachersdutyroll"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.TDUTIESBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TDUTIESBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TDUTIESBindingNavigator.ResumeLayout(False)
        Me.TDUTIESBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Database1DataSet As SCHOOLMANAGEMENTSYSTEM.Database1DataSet
    Friend WithEvents TDUTIESBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TDUTIESTableAdapter As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TDUTIESTableAdapter
    Friend WithEvents TableAdapterManager As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents TDUTIESBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TDUTIESBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents WEEKNUMBERTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DAYRANGETextBox As System.Windows.Forms.TextBox
    Friend WithEvents TEACHER_S_1TextBox As System.Windows.Forms.TextBox
    Friend WithEvents TEACHER_S2TextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
