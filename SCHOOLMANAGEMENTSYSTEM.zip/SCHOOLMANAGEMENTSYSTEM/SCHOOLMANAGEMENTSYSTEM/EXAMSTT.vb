﻿Public Class EXAMSTT

    Private Sub EXAMSTIMETABLEBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXAMSTIMETABLEBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.EXAMSTIMETABLEBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub EXAMSTT_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.EXAMSTIMETABLE' table. You can move, or remove it, as needed.
        Me.EXAMSTIMETABLETableAdapter.Fill(Me.Database1DataSet.EXAMSTIMETABLE)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        MsgBox("ADD OR EDIT RECORDS")
        Me.EXAMSTIMETABLEBindingSource.AddNew()
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Me.Validate()
        Me.EXAMSTIMETABLEBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)
        MsgBox("SAVED")
    End Sub
End Class