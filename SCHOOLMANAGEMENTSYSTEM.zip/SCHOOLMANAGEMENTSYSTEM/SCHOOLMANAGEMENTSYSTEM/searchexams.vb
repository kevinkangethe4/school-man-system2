﻿
Imports System.Drawing.Printing
Public Class searchexams

    Private Sub PERFORMANCEBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PERFORMANCEBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.PERFORMANCEBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub searchexams_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.PERFORMANCE' table. You can move, or remove it, as needed.
        Me.PERFORMANCETableAdapter.Fill(Me.Database1DataSet.PERFORMANCE)

    End Sub

    Private Sub PERFORMANCEDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs) Handles PERFORMANCEDataGridView.CellContentClick

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim doc As New PrintDocument()
        AddHandler doc.PrintPage, AddressOf Me.PrintDocument1_PrintPage
        Dim dlgs As New PrintDialog()
        dlgs.Document = doc
        If dlgs.ShowDialog() = DialogResult.OK Then
            doc.Print()
        End If
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim x As Single = e.MarginBounds.Left
        Dim y As Single = e.MarginBounds.Top
        Dim bmp As New Bitmap(Me.GroupBox1.Width, Me.GroupBox1.Height)
        Me.GroupBox1.DrawToBitmap(bmp, New Rectangle(0, 0, Me.GroupBox1.Width, Me.GroupBox1.Height))
        e.Graphics.DrawImage(DirectCast(bmp, Image), x, y)
    End Sub

    Private Sub TextBox16_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox16.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.PERFORMANCE
        dv.RowFilter = "[TERM] like'" & TextBox16.Text & "%'"

        PERFORMANCEDataGridView.DataSource = dv
    End Sub

    Private Sub TextBox16_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox16.TextChanged

    End Sub

    Private Sub GroupBox1_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GroupBox1.Enter

    End Sub
    Private Sub TextBox2_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox2.GotFocus
        TextBox2.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(7).FormattedValue.ToString() <> String.Empty
                              Select Convert.ToInt32(ROW.Cells(7).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub

    Private Sub TextBox3_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox3.GotFocus
        TextBox3.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(9).FormattedValue.ToString() <> String.Empty
                                            Select Convert.ToInt32(ROW.Cells(9).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox4_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox4.GotFocus
        TextBox4.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(11).FormattedValue.ToString() <> String.Empty
                                            Select Convert.ToInt32(ROW.Cells(11).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox5_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox5.GotFocus
        TextBox5.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(13).FormattedValue.ToString() <> String.Empty
                                                    Select Convert.ToInt32(ROW.Cells(13).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox5_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox5.TextChanged

    End Sub

    Private Sub TextBox6_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox6.GotFocus
        TextBox6.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(15).FormattedValue.ToString() <> String.Empty
                                    Select Convert.ToInt32(ROW.Cells(15).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox6_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox6.TextChanged

    End Sub

    Private Sub TextBox7_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox7.GotFocus
        TextBox7.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(17).FormattedValue.ToString() <> String.Empty
                                                    Select Convert.ToInt32(ROW.Cells(17).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub TextBox15_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox15.GotFocus
        TextBox15.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(21).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(21).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox15_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox15.TextChanged

    End Sub

    Private Sub TextBox9_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox9.GotFocus
        TextBox9.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(25).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(25).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox9_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox9.TextChanged

    End Sub

    Private Sub TextBox10_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox10.GotFocus
        TextBox10.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(23).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(23).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox10_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox10.TextChanged

    End Sub

    Private Sub TextBox11_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox11.GotFocus
        TextBox11.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(27).FormattedValue.ToString() <> String.Empty
                                                   Select Convert.ToInt32(ROW.Cells(27).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox11_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox11.TextChanged

    End Sub

    Private Sub TextBox8_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox8.GotFocus
        TextBox8.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(19).FormattedValue.ToString() <> String.Empty
                                                           Select Convert.ToInt32(ROW.Cells(19).FormattedValue)).Average().ToString()
    End Sub

    Private Sub TextBox8_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox8.TextChanged

    End Sub

    Private Sub TextBox12_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox12.GotFocus
        TextBox12.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(31).FormattedValue.ToString() <> String.Empty
                                                         Select Convert.ToInt32(ROW.Cells(31).FormattedValue)).Average().ToString()
    End Sub
    Private Sub TextBox1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox1.GotFocus
        TextBox1.Text = (From ROW As DataGridViewRow In PERFORMANCEDataGridView.Rows Where ROW.Cells(5).FormattedValue.ToString() <> String.Empty
                         Select Convert.ToInt32(ROW.Cells(5).FormattedValue)).Average().ToString()
    End Sub

    Private Sub PERFORMANCEDataGridView_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs) Handles PERFORMANCEDataGridView.RowPostPaint
        Dim dg As DataGridView = DirectCast(sender, DataGridView)
        Dim rownumber As String = (e.RowIndex + 1).ToString()
        While rownumber.Length < dg.RowCount.ToString().Length
            rownumber = "0" & rownumber

        End While
        Dim size As SizeF = e.Graphics.MeasureString(rownumber, Me.Font)
        If dg.RowHeadersWidth < CInt(size.Width + 20) Then
            dg.RowHeadersWidth = CInt(size.Width + 20)

        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(rownumber, dg.Font, b, e.RowBounds.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim doc As New PrintDocument()
        AddHandler doc.PrintPage, AddressOf Me.PrintDocument2_PrintPage
        Dim dlgs As New PrintDialog()
        dlgs.Document = doc
        If dlgs.ShowDialog() = DialogResult.OK Then
            doc.Print()
        End If
    End Sub

    Private Sub PrintDocument2_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument2.PrintPage
        Dim x As Single = e.MarginBounds.Left
        Dim y As Single = e.MarginBounds.Top
        Dim bmp As New Bitmap(Me.GroupBox3.Width, Me.GroupBox3.Height)
        Me.GroupBox3.DrawToBitmap(bmp, New Rectangle(0, 0, Me.GroupBox3.Width, Me.GroupBox3.Height))
        e.Graphics.DrawImage(DirectCast(bmp, Image), x, y)
    End Sub
End Class