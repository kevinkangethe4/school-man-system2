﻿Imports System.Drawing.Printing
Public Class GROUPREGvb
    Private mRow As Integer = 0
    Private newpage As Boolean = True
    Private Sub REGISTATIONBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REGISTATIONBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.REGISTATIONBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub GROUPREGvb_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.REGISTATION' table. You can move, or remove it, as needed.
        Me.REGISTATIONTableAdapter.Fill(Me.Database1DataSet.REGISTATION)

    End Sub

    Private Sub TextBox1_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox1.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.REGISTATION
        dv.RowFilter = "[STUDENTNUMBER] like'" & TextBox1.Text & "%'"

        REGISTATIONDataGridView.DataSource = dv
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim PrintDlg As PrintDialog = New PrintDialog()
        Dim PrintDlgRslt As DialogResult = New DialogResult()
        Dim MyDoc As PrintDocument = New PrintDocument()

        PrintDlg.Document = MyDoc

        PrintDlgRslt = PrintDlg.ShowDialog()
        If PrintDlgRslt = Windows.Forms.DialogResult.OK Then
            AddHandler MyDoc.PrintPage, AddressOf PrintDocument1_PrintPage
            MyDoc.Print()
        End If
    End Sub

    Private Sub PrintPreviewDialog1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreviewDialog1.Load

    End Sub

    Private Sub PrintDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.BeginPrint
        mRow = 0
        newpage = True
        PrintPreviewDialog1.PrintPreviewControl.StartPage = 0
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.0
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.REGISTATIONDataGridView.Width, Me.REGISTATIONDataGridView.Height)
        REGISTATIONDataGridView.DrawToBitmap(bm, New Rectangle(0, 0, Me.REGISTATIONDataGridView.Width, Me.REGISTATIONDataGridView.Height))
        e.Graphics.DrawImage(bm, 0, 0)
    End Sub

    Private Sub REGISTATIONDataGridView_CellContentClick(ByVal sender As System.Object, ByVal e As System.Windows.Forms.DataGridViewCellEventArgs)

    End Sub

    Private Sub REGISTATIONDataGridView_RowPostPaint(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewRowPostPaintEventArgs)
        Dim dg As DataGridView = DirectCast(sender, DataGridView)
        Dim rownumber As String = (e.RowIndex + 1).ToString()
        While rownumber.Length < dg.RowCount.ToString().Length
            rownumber = "0" & rownumber

        End While
        Dim size As SizeF = e.Graphics.MeasureString(rownumber, Me.Font)
        If dg.RowHeadersWidth < CInt(size.Width + 20) Then
            dg.RowHeadersWidth = CInt(size.Width + 20)

        End If
        Dim b As Brush = SystemBrushes.ControlText
        e.Graphics.DrawString(rownumber, dg.Font, b, e.RowBounds.X + 15, e.RowBounds.Location.Y + ((e.RowBounds.Height - size.Height) / 2))
    End Sub

    Private Sub TextBox2_KeyUp(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles TextBox2.KeyUp
        Dim dv As DataView = New DataView()

        dv.Table = Database1DataSet.REGISTATION
        dv.RowFilter = "[CLASS] like'" & TextBox2.Text & "%'"

        REGISTATIONDataGridView.DataSource = dv
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged

    End Sub
End Class