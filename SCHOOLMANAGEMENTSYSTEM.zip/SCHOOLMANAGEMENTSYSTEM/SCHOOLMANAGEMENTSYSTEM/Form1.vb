﻿Public Class Form1

    Private Sub PERFORMANCEFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PERFORMANCEFORMToolStripMenuItem.Click
        Dim BN As New PERFRMANCEFORM
        BN.ShowDialog()
    End Sub

    Private Sub GROUPPERFORMANCEFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPPERFORMANCEFORMToolStripMenuItem.Click
        Dim S As New performance
        S.ShowDialog()
    End Sub

    Private Sub REGISTRATIONFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REGISTRATIONFORMToolStripMenuItem.Click
        Dim A As New registratio
        A.ShowDialog()
    End Sub

    Private Sub PAYMENTSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PAYMENTSToolStripMenuItem.Click

    End Sub

    Private Sub PAYMENTFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PAYMENTFORMToolStripMenuItem.Click
        FRMPAYMENT.Show()
    End Sub

    Private Sub PEFORMANCEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        RTPPERFORMANCE.Show()
    End Sub

    Private Sub PROGRESSGRAPHToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PROGRESSGRAPHToolStripMenuItem.Click
        searchexams.Show()
    End Sub

    Private Sub EXITToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Me.Close()
    End Sub

    Private Sub ACCOUNTSETTINSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ACCOUNTSETTINSToolStripMenuItem.Click
        accountsettingvb.Show()
    End Sub

    Private Sub GROUPSREGISTRATIONFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPSREGISTRATIONFORMToolStripMenuItem.Click
        GROUPREGvb.Show()
    End Sub

    Private Sub ATTANDANCEFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ATTANDANCEFORMToolStripMenuItem.Click
        ATTEDANCE.Show()
    End Sub

    Private Sub ATTANDANCEGROUPFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ATTANDANCEGROUPFORMToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub HELPFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HELPFORMToolStripMenuItem.Click
        FRMTIMETABLE.Show()
    End Sub

    Private Sub PAYMENTGROUPFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PAYMENTGROUPFORMToolStripMenuItem.Click
        PAYEMENTGROUPvb.Show()
    End Sub

    Private Sub HELPToolStripMenuItem2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HELPToolStripMenuItem2.Click
        Help.Show()
    End Sub

    Private Sub GROUPTIMETABLEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPTIMETABLEToolStripMenuItem.Click
        grouptimetable.Show()
    End Sub

    Private Sub EDITEXAMSTIMETABLEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EDITEXAMSTIMETABLEToolStripMenuItem.Click
        EXAMSTT.Show()
    End Sub

    Private Sub GROUPEXAMSTIMETABLEToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPEXAMSTIMETABLEToolStripMenuItem.Click
        GEXAMS.Show()
    End Sub

    Private Sub EDITDUTYROLLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EDITDUTYROLLToolStripMenuItem.Click
        teachersdutyroll.Show()
    End Sub

    Private Sub GROUPDUTYROLLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPDUTYROLLToolStripMenuItem.Click
        GROUPDUTYROLL.Show()
    End Sub

    Private Sub EXITToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem1.Click
        Me.Close()

    End Sub

    Private Sub MenuStrip1_ItemClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.ToolStripItemClickedEventArgs) Handles MenuStrip1.ItemClicked

    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub

    Private Sub REGISTRATIONFORMToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REGISTRATIONFORMToolStripMenuItem1.Click
        registratio.Show()
    End Sub

    Private Sub REGISTRATIONToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles REGISTRATIONToolStripMenuItem.Click

    End Sub

    Private Sub SEARCHSTUDENTDETAILSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SEARCHSTUDENTDETAILSToolStripMenuItem.Click
        GROUPREGvb.Show()
    End Sub

    Private Sub PERFORMANCEFORMToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PERFORMANCEFORMToolStripMenuItem1.Click
        Dim BN As New PERFRMANCEFORM
        BN.ShowDialog()
    End Sub

    Private Sub SEARCHSTUDENTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SEARCHSTUDENTToolStripMenuItem.Click
        Dim S As New performance
        S.ShowDialog()
    End Sub

    Private Sub PAYEMENTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PAYEMENTToolStripMenuItem.Click
        FRMPAYMENT.Show()
    End Sub

    Private Sub SEARCHPAYEMENTSDETAILSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SEARCHPAYEMENTSDETAILSToolStripMenuItem.Click
        PAYEMENTGROUPvb.Show()
    End Sub

    Private Sub ATTAENDANCEFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ATTAENDANCEFORMToolStripMenuItem.Click
        ATTEDANCE.Show()
    End Sub

    Private Sub SEARCHDETAILSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SEARCHDETAILSToolStripMenuItem.Click
        Form2.Show()
    End Sub

    Private Sub TIMETABLEFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TIMETABLEFORMToolStripMenuItem.Click
        FRMTIMETABLE.Show()
    End Sub

    Private Sub GROUPTIMETABLEToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPTIMETABLEToolStripMenuItem1.Click
        grouptimetable.Show()
    End Sub

    Private Sub EXAMTTFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXAMTTFORMToolStripMenuItem.Click
        EXAMSTT.Show()
    End Sub

    Private Sub GROUPEXAMSTTToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPEXAMSTTToolStripMenuItem.Click
        GEXAMS.Show()
    End Sub

    Private Sub DUTYROLLFORMToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DUTYROLLFORMToolStripMenuItem.Click
        teachersdutyroll.Show()
    End Sub

    Private Sub GROUPROLLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GROUPROLLToolStripMenuItem.Click
        GROUPDUTYROLL.Show()
    End Sub

    Private Sub HELPToolStripMenuItem3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles HELPToolStripMenuItem3.Click
        Help.Show()
    End Sub

    Private Sub EXITToolStripMenuItem_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXITToolStripMenuItem.Click
        Me.Close()
    End Sub


    Private Sub SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SEARCHFORGROUPCLASSPAYMENTSDETAILSToolStripMenuItem.Click
        grouppayemntsvb.Show()
    End Sub
End Class
