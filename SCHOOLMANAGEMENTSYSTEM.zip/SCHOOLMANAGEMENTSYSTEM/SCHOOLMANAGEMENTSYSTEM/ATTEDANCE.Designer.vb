﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class ATTEDANCE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim AttedancerefnoLabel As System.Windows.Forms.Label
        Dim StudentnumberLabel As System.Windows.Forms.Label
        Dim StudentnameLabel As System.Windows.Forms.Label
        Dim YEAR_TERM_CLASSLabel As System.Windows.Forms.Label
        Dim DaypresentLabel As System.Windows.Forms.Label
        Dim OutoffLabel As System.Windows.Forms.Label
        Dim DayabsentLabel As System.Windows.Forms.Label
        Dim ReasonofabsentismLabel As System.Windows.Forms.Label
        Dim Attendence_percentageLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(ATTEDANCE))
        Me.Database1DataSet = New SCHOOLMANAGEMENTSYSTEM.Database1DataSet()
        Me.ATTEDANCEBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.ATTEDANCETableAdapter = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.ATTEDANCETableAdapter()
        Me.TableAdapterManager = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager()
        Me.ATTEDANCEBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.ATTEDANCEBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.AttedancerefnoTextBox = New System.Windows.Forms.TextBox()
        Me.StudentnumberTextBox = New System.Windows.Forms.TextBox()
        Me.StudentnameTextBox = New System.Windows.Forms.TextBox()
        Me.YEAR_TERM_CLASSTextBox = New System.Windows.Forms.TextBox()
        Me.DaypresentTextBox = New System.Windows.Forms.TextBox()
        Me.OutoffTextBox = New System.Windows.Forms.TextBox()
        Me.DayabsentTextBox = New System.Windows.Forms.TextBox()
        Me.ReasonofabsentismTextBox = New System.Windows.Forms.TextBox()
        Me.Attendence_percentageTextBox = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        AttedancerefnoLabel = New System.Windows.Forms.Label()
        StudentnumberLabel = New System.Windows.Forms.Label()
        StudentnameLabel = New System.Windows.Forms.Label()
        YEAR_TERM_CLASSLabel = New System.Windows.Forms.Label()
        DaypresentLabel = New System.Windows.Forms.Label()
        OutoffLabel = New System.Windows.Forms.Label()
        DayabsentLabel = New System.Windows.Forms.Label()
        ReasonofabsentismLabel = New System.Windows.Forms.Label()
        Attendence_percentageLabel = New System.Windows.Forms.Label()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ATTEDANCEBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ATTEDANCEBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ATTEDANCEBindingNavigator.SuspendLayout()
        Me.SuspendLayout()
        '
        'AttedancerefnoLabel
        '
        AttedancerefnoLabel.AutoSize = True
        AttedancerefnoLabel.Location = New System.Drawing.Point(30, 59)
        AttedancerefnoLabel.Name = "AttedancerefnoLabel"
        AttedancerefnoLabel.Size = New System.Drawing.Size(125, 16)
        AttedancerefnoLabel.TabIndex = 1
        AttedancerefnoLabel.Text = "Attedance ref no:"
        '
        'StudentnumberLabel
        '
        StudentnumberLabel.AutoSize = True
        StudentnumberLabel.Location = New System.Drawing.Point(30, 91)
        StudentnumberLabel.Name = "StudentnumberLabel"
        StudentnumberLabel.Size = New System.Drawing.Size(118, 16)
        StudentnumberLabel.TabIndex = 3
        StudentnumberLabel.Text = "Student Number:"
        '
        'StudentnameLabel
        '
        StudentnameLabel.AutoSize = True
        StudentnameLabel.Location = New System.Drawing.Point(30, 123)
        StudentnameLabel.Name = "StudentnameLabel"
        StudentnameLabel.Size = New System.Drawing.Size(104, 16)
        StudentnameLabel.TabIndex = 5
        StudentnameLabel.Text = "Student Name:"
        '
        'YEAR_TERM_CLASSLabel
        '
        YEAR_TERM_CLASSLabel.AutoSize = True
        YEAR_TERM_CLASSLabel.Location = New System.Drawing.Point(30, 155)
        YEAR_TERM_CLASSLabel.Name = "YEAR_TERM_CLASSLabel"
        YEAR_TERM_CLASSLabel.Size = New System.Drawing.Size(139, 16)
        YEAR_TERM_CLASSLabel.TabIndex = 7
        YEAR_TERM_CLASSLabel.Text = "YEAR/TERM/CLASS:"
        '
        'DaypresentLabel
        '
        DaypresentLabel.AutoSize = True
        DaypresentLabel.Location = New System.Drawing.Point(30, 187)
        DaypresentLabel.Name = "DaypresentLabel"
        DaypresentLabel.Size = New System.Drawing.Size(100, 16)
        DaypresentLabel.TabIndex = 9
        DaypresentLabel.Text = "Days Present:"
        '
        'OutoffLabel
        '
        OutoffLabel.AutoSize = True
        OutoffLabel.Location = New System.Drawing.Point(30, 219)
        OutoffLabel.Name = "OutoffLabel"
        OutoffLabel.Size = New System.Drawing.Size(59, 16)
        OutoffLabel.TabIndex = 11
        OutoffLabel.Text = "Out Off:"
        '
        'DayabsentLabel
        '
        DayabsentLabel.AutoSize = True
        DayabsentLabel.Location = New System.Drawing.Point(30, 251)
        DayabsentLabel.Name = "DayabsentLabel"
        DayabsentLabel.Size = New System.Drawing.Size(96, 16)
        DayabsentLabel.TabIndex = 13
        DayabsentLabel.Text = "Days Absent:"
        '
        'ReasonofabsentismLabel
        '
        ReasonofabsentismLabel.AutoSize = True
        ReasonofabsentismLabel.Location = New System.Drawing.Point(30, 283)
        ReasonofabsentismLabel.Name = "ReasonofabsentismLabel"
        ReasonofabsentismLabel.Size = New System.Drawing.Size(150, 16)
        ReasonofabsentismLabel.TabIndex = 15
        ReasonofabsentismLabel.Text = "Reason of Absentism:"
        '
        'Attendence_percentageLabel
        '
        Attendence_percentageLabel.AutoSize = True
        Attendence_percentageLabel.Location = New System.Drawing.Point(7, 356)
        Attendence_percentageLabel.Name = "Attendence_percentageLabel"
        Attendence_percentageLabel.Size = New System.Drawing.Size(173, 16)
        Attendence_percentageLabel.TabIndex = 17
        Attendence_percentageLabel.Text = "Attendence/Percentage:"
        '
        'Database1DataSet
        '
        Me.Database1DataSet.DataSetName = "Database1DataSet"
        Me.Database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'ATTEDANCEBindingSource
        '
        Me.ATTEDANCEBindingSource.DataMember = "ATTEDANCE"
        Me.ATTEDANCEBindingSource.DataSource = Me.Database1DataSet
        '
        'ATTEDANCETableAdapter
        '
        Me.ATTEDANCETableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.ATTEDANCETableAdapter = Me.ATTEDANCETableAdapter
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.loginTableAdapter = Nothing
        Me.TableAdapterManager.PAYMENTTableAdapter = Nothing
        Me.TableAdapterManager.PERFORMANCETableAdapter = Nothing
        Me.TableAdapterManager.REGISTATIONTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'ATTEDANCEBindingNavigator
        '
        Me.ATTEDANCEBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.ATTEDANCEBindingNavigator.BindingSource = Me.ATTEDANCEBindingSource
        Me.ATTEDANCEBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.ATTEDANCEBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.ATTEDANCEBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.ATTEDANCEBindingNavigatorSaveItem})
        Me.ATTEDANCEBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.ATTEDANCEBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.ATTEDANCEBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.ATTEDANCEBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.ATTEDANCEBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.ATTEDANCEBindingNavigator.Name = "ATTEDANCEBindingNavigator"
        Me.ATTEDANCEBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.ATTEDANCEBindingNavigator.Size = New System.Drawing.Size(1028, 25)
        Me.ATTEDANCEBindingNavigator.TabIndex = 0
        Me.ATTEDANCEBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(66, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'ATTEDANCEBindingNavigatorSaveItem
        '
        Me.ATTEDANCEBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.ATTEDANCEBindingNavigatorSaveItem.Image = CType(resources.GetObject("ATTEDANCEBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.ATTEDANCEBindingNavigatorSaveItem.Name = "ATTEDANCEBindingNavigatorSaveItem"
        Me.ATTEDANCEBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.ATTEDANCEBindingNavigatorSaveItem.Text = "Save Data"
        '
        'AttedancerefnoTextBox
        '
        Me.AttedancerefnoTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "attedancerefno", True))
        Me.AttedancerefnoTextBox.Location = New System.Drawing.Point(201, 55)
        Me.AttedancerefnoTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.AttedancerefnoTextBox.Name = "AttedancerefnoTextBox"
        Me.AttedancerefnoTextBox.Size = New System.Drawing.Size(826, 23)
        Me.AttedancerefnoTextBox.TabIndex = 2
        '
        'StudentnumberTextBox
        '
        Me.StudentnumberTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "studentnumber", True))
        Me.StudentnumberTextBox.Location = New System.Drawing.Point(201, 87)
        Me.StudentnumberTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.StudentnumberTextBox.Name = "StudentnumberTextBox"
        Me.StudentnumberTextBox.Size = New System.Drawing.Size(826, 23)
        Me.StudentnumberTextBox.TabIndex = 4
        '
        'StudentnameTextBox
        '
        Me.StudentnameTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "studentname", True))
        Me.StudentnameTextBox.Location = New System.Drawing.Point(201, 119)
        Me.StudentnameTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.StudentnameTextBox.Name = "StudentnameTextBox"
        Me.StudentnameTextBox.Size = New System.Drawing.Size(826, 23)
        Me.StudentnameTextBox.TabIndex = 6
        '
        'YEAR_TERM_CLASSTextBox
        '
        Me.YEAR_TERM_CLASSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "YEAR/TERM/CLASS", True))
        Me.YEAR_TERM_CLASSTextBox.Location = New System.Drawing.Point(201, 151)
        Me.YEAR_TERM_CLASSTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.YEAR_TERM_CLASSTextBox.Name = "YEAR_TERM_CLASSTextBox"
        Me.YEAR_TERM_CLASSTextBox.Size = New System.Drawing.Size(826, 23)
        Me.YEAR_TERM_CLASSTextBox.TabIndex = 8
        '
        'DaypresentTextBox
        '
        Me.DaypresentTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "daypresent", True))
        Me.DaypresentTextBox.Location = New System.Drawing.Point(201, 183)
        Me.DaypresentTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.DaypresentTextBox.Name = "DaypresentTextBox"
        Me.DaypresentTextBox.Size = New System.Drawing.Size(826, 23)
        Me.DaypresentTextBox.TabIndex = 10
        '
        'OutoffTextBox
        '
        Me.OutoffTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "outoff", True))
        Me.OutoffTextBox.Location = New System.Drawing.Point(201, 215)
        Me.OutoffTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.OutoffTextBox.Name = "OutoffTextBox"
        Me.OutoffTextBox.Size = New System.Drawing.Size(826, 23)
        Me.OutoffTextBox.TabIndex = 12
        '
        'DayabsentTextBox
        '
        Me.DayabsentTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "dayabsent", True))
        Me.DayabsentTextBox.Location = New System.Drawing.Point(201, 247)
        Me.DayabsentTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.DayabsentTextBox.Name = "DayabsentTextBox"
        Me.DayabsentTextBox.Size = New System.Drawing.Size(826, 23)
        Me.DayabsentTextBox.TabIndex = 14
        '
        'ReasonofabsentismTextBox
        '
        Me.ReasonofabsentismTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "reasonofabsentism", True))
        Me.ReasonofabsentismTextBox.Location = New System.Drawing.Point(201, 279)
        Me.ReasonofabsentismTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.ReasonofabsentismTextBox.Multiline = True
        Me.ReasonofabsentismTextBox.Name = "ReasonofabsentismTextBox"
        Me.ReasonofabsentismTextBox.Size = New System.Drawing.Size(685, 66)
        Me.ReasonofabsentismTextBox.TabIndex = 16
        '
        'Attendence_percentageTextBox
        '
        Me.Attendence_percentageTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.ATTEDANCEBindingSource, "attendence/percentage", True))
        Me.Attendence_percentageTextBox.Location = New System.Drawing.Point(190, 353)
        Me.Attendence_percentageTextBox.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Attendence_percentageTextBox.Name = "Attendence_percentageTextBox"
        Me.Attendence_percentageTextBox.Size = New System.Drawing.Size(826, 23)
        Me.Attendence_percentageTextBox.TabIndex = 18
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(167, 435)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(98, 23)
        Me.Button1.TabIndex = 19
        Me.Button1.Text = "ADD NEW"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(286, 435)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(75, 23)
        Me.Button2.TabIndex = 20
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'ATTEDANCE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 16.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1028, 585)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(AttedancerefnoLabel)
        Me.Controls.Add(Me.AttedancerefnoTextBox)
        Me.Controls.Add(StudentnumberLabel)
        Me.Controls.Add(Me.StudentnumberTextBox)
        Me.Controls.Add(StudentnameLabel)
        Me.Controls.Add(Me.StudentnameTextBox)
        Me.Controls.Add(YEAR_TERM_CLASSLabel)
        Me.Controls.Add(Me.YEAR_TERM_CLASSTextBox)
        Me.Controls.Add(DaypresentLabel)
        Me.Controls.Add(Me.DaypresentTextBox)
        Me.Controls.Add(OutoffLabel)
        Me.Controls.Add(Me.OutoffTextBox)
        Me.Controls.Add(DayabsentLabel)
        Me.Controls.Add(Me.DayabsentTextBox)
        Me.Controls.Add(ReasonofabsentismLabel)
        Me.Controls.Add(Me.ReasonofabsentismTextBox)
        Me.Controls.Add(Attendence_percentageLabel)
        Me.Controls.Add(Me.Attendence_percentageTextBox)
        Me.Controls.Add(Me.ATTEDANCEBindingNavigator)
        Me.Font = New System.Drawing.Font("Tahoma", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "ATTEDANCE"
        Me.Text = "ATTEDANCE"
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ATTEDANCEBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ATTEDANCEBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ATTEDANCEBindingNavigator.ResumeLayout(False)
        Me.ATTEDANCEBindingNavigator.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Database1DataSet As SCHOOLMANAGEMENTSYSTEM.Database1DataSet
    Friend WithEvents ATTEDANCEBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents ATTEDANCETableAdapter As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.ATTEDANCETableAdapter
    Friend WithEvents TableAdapterManager As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents ATTEDANCEBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents ATTEDANCEBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents AttedancerefnoTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentnumberTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StudentnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents YEAR_TERM_CLASSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DaypresentTextBox As System.Windows.Forms.TextBox
    Friend WithEvents OutoffTextBox As System.Windows.Forms.TextBox
    Friend WithEvents DayabsentTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ReasonofabsentismTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Attendence_percentageTextBox As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
