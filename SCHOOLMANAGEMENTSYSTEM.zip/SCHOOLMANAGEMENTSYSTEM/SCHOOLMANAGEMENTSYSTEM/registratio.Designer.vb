﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class registratio
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim FIRSTNAMELabel As System.Windows.Forms.Label
        Dim MIDDLENAMELabel As System.Windows.Forms.Label
        Dim LASTNAMELabel As System.Windows.Forms.Label
        Dim DATEOFBIRTHLabel As System.Windows.Forms.Label
        Dim ADDRESSLabel As System.Windows.Forms.Label
        Dim PHONENUMBERLabel As System.Windows.Forms.Label
        Dim EMAILLabel As System.Windows.Forms.Label
        Dim NEXTOFKINLabel As System.Windows.Forms.Label
        Dim NEXTOFKINRELATIONLabel As System.Windows.Forms.Label
        Dim REGISTRATIONDATELabel As System.Windows.Forms.Label
        Dim CLASSLabel As System.Windows.Forms.Label
        Dim STUDENTNUMBERLabel As System.Windows.Forms.Label
        Dim GENDERLabel As System.Windows.Forms.Label
        Dim StudentpicLabel As System.Windows.Forms.Label
        Dim ParentpicLabel As System.Windows.Forms.Label
        Dim SECONDGUARDIANLabel As System.Windows.Forms.Label
        Dim IDNUMBERLabel As System.Windows.Forms.Label
        Dim SECONDGUARDIANPHONENUMBERLabel As System.Windows.Forms.Label
        Dim RESIDENTLabel As System.Windows.Forms.Label
        Dim GUARDIANOccupation_Label As System.Windows.Forms.Label
        Dim KCPERESULTLabel As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(registratio))
        Me.REGISTATIONBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.REGISTATIONBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.Database1DataSet = New SCHOOLMANAGEMENTSYSTEM.Database1DataSet()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.REGISTATIONBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.FIRSTNAMETextBox = New System.Windows.Forms.TextBox()
        Me.MIDDLENAMETextBox = New System.Windows.Forms.TextBox()
        Me.LASTNAMETextBox = New System.Windows.Forms.TextBox()
        Me.DATEOFBIRTHDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.ADDRESSTextBox = New System.Windows.Forms.TextBox()
        Me.PHONENUMBERTextBox = New System.Windows.Forms.TextBox()
        Me.EMAILTextBox = New System.Windows.Forms.TextBox()
        Me.NEXTOFKINTextBox = New System.Windows.Forms.TextBox()
        Me.NEXTOFKINRELATIONTextBox = New System.Windows.Forms.TextBox()
        Me.REGISTRATIONDATEDateTimePicker = New System.Windows.Forms.DateTimePicker()
        Me.GENDERComboBox = New System.Windows.Forms.ComboBox()
        Me.STUDENTNUMBERTextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.StudentpicPictureBox = New System.Windows.Forms.PictureBox()
        Me.ParentpicPictureBox = New System.Windows.Forms.PictureBox()
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.TextBox3 = New System.Windows.Forms.TextBox()
        Me.TextBox4 = New System.Windows.Forms.TextBox()
        Me.SECONDGUARDIANTextBox = New System.Windows.Forms.TextBox()
        Me.IDNUMBERTextBox = New System.Windows.Forms.TextBox()
        Me.SECONDGUARDIANPHONENUMBERTextBox = New System.Windows.Forms.TextBox()
        Me.RESIDENTTextBox = New System.Windows.Forms.TextBox()
        Me.GUARDIANOccupation_TextBox = New System.Windows.Forms.TextBox()
        Me.REGISTATIONTableAdapter = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.REGISTATIONTableAdapter()
        Me.TableAdapterManager = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager()
        Me.CLASSTextBox = New System.Windows.Forms.TextBox()
        Me.REGISTATIONDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewImageColumn1 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewImageColumn2 = New System.Windows.Forms.DataGridViewImageColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Search_STUDENTNUMBERToolStrip = New System.Windows.Forms.ToolStrip()
        Me._LIKEToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me._LIKEToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me.Search_STUDENTNUMBERToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.KCPERESULTTextBox = New System.Windows.Forms.TextBox()
        FIRSTNAMELabel = New System.Windows.Forms.Label()
        MIDDLENAMELabel = New System.Windows.Forms.Label()
        LASTNAMELabel = New System.Windows.Forms.Label()
        DATEOFBIRTHLabel = New System.Windows.Forms.Label()
        ADDRESSLabel = New System.Windows.Forms.Label()
        PHONENUMBERLabel = New System.Windows.Forms.Label()
        EMAILLabel = New System.Windows.Forms.Label()
        NEXTOFKINLabel = New System.Windows.Forms.Label()
        NEXTOFKINRELATIONLabel = New System.Windows.Forms.Label()
        REGISTRATIONDATELabel = New System.Windows.Forms.Label()
        CLASSLabel = New System.Windows.Forms.Label()
        STUDENTNUMBERLabel = New System.Windows.Forms.Label()
        GENDERLabel = New System.Windows.Forms.Label()
        StudentpicLabel = New System.Windows.Forms.Label()
        ParentpicLabel = New System.Windows.Forms.Label()
        SECONDGUARDIANLabel = New System.Windows.Forms.Label()
        IDNUMBERLabel = New System.Windows.Forms.Label()
        SECONDGUARDIANPHONENUMBERLabel = New System.Windows.Forms.Label()
        RESIDENTLabel = New System.Windows.Forms.Label()
        GUARDIANOccupation_Label = New System.Windows.Forms.Label()
        KCPERESULTLabel = New System.Windows.Forms.Label()
        CType(Me.REGISTATIONBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.REGISTATIONBindingNavigator.SuspendLayout()
        CType(Me.REGISTATIONBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox1.SuspendLayout()
        CType(Me.StudentpicPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.ParentpicPictureBox, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.REGISTATIONDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Search_STUDENTNUMBERToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'FIRSTNAMELabel
        '
        FIRSTNAMELabel.AutoSize = True
        FIRSTNAMELabel.Location = New System.Drawing.Point(14, 101)
        FIRSTNAMELabel.Name = "FIRSTNAMELabel"
        FIRSTNAMELabel.Size = New System.Drawing.Size(85, 14)
        FIRSTNAMELabel.TabIndex = 1
        FIRSTNAMELabel.Text = "FIRST NAME:"
        '
        'MIDDLENAMELabel
        '
        MIDDLENAMELabel.AutoSize = True
        MIDDLENAMELabel.Location = New System.Drawing.Point(14, 129)
        MIDDLENAMELabel.Name = "MIDDLENAMELabel"
        MIDDLENAMELabel.Size = New System.Drawing.Size(98, 14)
        MIDDLENAMELabel.TabIndex = 3
        MIDDLENAMELabel.Text = "MIDDLE NAME:"
        '
        'LASTNAMELabel
        '
        LASTNAMELabel.AutoSize = True
        LASTNAMELabel.Location = New System.Drawing.Point(14, 157)
        LASTNAMELabel.Name = "LASTNAMELabel"
        LASTNAMELabel.Size = New System.Drawing.Size(81, 14)
        LASTNAMELabel.TabIndex = 5
        LASTNAMELabel.Text = "LAST NAME:"
        '
        'DATEOFBIRTHLabel
        '
        DATEOFBIRTHLabel.AutoSize = True
        DATEOFBIRTHLabel.Location = New System.Drawing.Point(14, 186)
        DATEOFBIRTHLabel.Name = "DATEOFBIRTHLabel"
        DATEOFBIRTHLabel.Size = New System.Drawing.Size(104, 14)
        DATEOFBIRTHLabel.TabIndex = 7
        DATEOFBIRTHLabel.Text = "DATE OF BIRTH:"
        '
        'ADDRESSLabel
        '
        ADDRESSLabel.AutoSize = True
        ADDRESSLabel.Location = New System.Drawing.Point(14, 213)
        ADDRESSLabel.Name = "ADDRESSLabel"
        ADDRESSLabel.Size = New System.Drawing.Size(70, 14)
        ADDRESSLabel.TabIndex = 9
        ADDRESSLabel.Text = "ADDRESS:"
        '
        'PHONENUMBERLabel
        '
        PHONENUMBERLabel.AutoSize = True
        PHONENUMBERLabel.Location = New System.Drawing.Point(14, 241)
        PHONENUMBERLabel.Name = "PHONENUMBERLabel"
        PHONENUMBERLabel.Size = New System.Drawing.Size(176, 14)
        PHONENUMBERLabel.TabIndex = 11
        PHONENUMBERLabel.Text = "GUARDIAN PHONE NUMBER:"
        '
        'EMAILLabel
        '
        EMAILLabel.AutoSize = True
        EMAILLabel.Location = New System.Drawing.Point(14, 269)
        EMAILLabel.Name = "EMAILLabel"
        EMAILLabel.Size = New System.Drawing.Size(119, 14)
        EMAILLabel.TabIndex = 13
        EMAILLabel.Text = "GUARDIAN EMAIL:"
        '
        'NEXTOFKINLabel
        '
        NEXTOFKINLabel.AutoSize = True
        NEXTOFKINLabel.Location = New System.Drawing.Point(14, 302)
        NEXTOFKINLabel.Name = "NEXTOFKINLabel"
        NEXTOFKINLabel.Size = New System.Drawing.Size(166, 14)
        NEXTOFKINLabel.TabIndex = 15
        NEXTOFKINLabel.Text = "GUARDIAN/PARENT NAME"
        '
        'NEXTOFKINRELATIONLabel
        '
        NEXTOFKINRELATIONLabel.AutoSize = True
        NEXTOFKINRELATIONLabel.Location = New System.Drawing.Point(14, 333)
        NEXTOFKINRELATIONLabel.Name = "NEXTOFKINRELATIONLabel"
        NEXTOFKINRELATIONLabel.Size = New System.Drawing.Size(208, 14)
        NEXTOFKINRELATIONLabel.TabIndex = 17
        NEXTOFKINRELATIONLabel.Text = "GUARDIAN /PARENT ID NUMBER:"
        '
        'REGISTRATIONDATELabel
        '
        REGISTRATIONDATELabel.AutoSize = True
        REGISTRATIONDATELabel.Location = New System.Drawing.Point(12, 367)
        REGISTRATIONDATELabel.Name = "REGISTRATIONDATELabel"
        REGISTRATIONDATELabel.Size = New System.Drawing.Size(138, 14)
        REGISTRATIONDATELabel.TabIndex = 19
        REGISTRATIONDATELabel.Text = "REGISTRATION DATE:"
        '
        'CLASSLabel
        '
        CLASSLabel.AutoSize = True
        CLASSLabel.Location = New System.Drawing.Point(18, 404)
        CLASSLabel.Name = "CLASSLabel"
        CLASSLabel.Size = New System.Drawing.Size(86, 14)
        CLASSLabel.TabIndex = 21
        CLASSLabel.Text = "CLASS/YEAR"
        '
        'STUDENTNUMBERLabel
        '
        STUDENTNUMBERLabel.AutoSize = True
        STUDENTNUMBERLabel.Location = New System.Drawing.Point(14, 59)
        STUDENTNUMBERLabel.Name = "STUDENTNUMBERLabel"
        STUDENTNUMBERLabel.Size = New System.Drawing.Size(120, 14)
        STUDENTNUMBERLabel.TabIndex = 23
        STUDENTNUMBERLabel.Text = "STUDENT NUMBER:"
        '
        'GENDERLabel
        '
        GENDERLabel.AutoSize = True
        GENDERLabel.Location = New System.Drawing.Point(14, 435)
        GENDERLabel.Name = "GENDERLabel"
        GENDERLabel.Size = New System.Drawing.Size(59, 14)
        GENDERLabel.TabIndex = 25
        GENDERLabel.Text = "GENDER:"
        '
        'StudentpicLabel
        '
        StudentpicLabel.AutoSize = True
        StudentpicLabel.Location = New System.Drawing.Point(788, 87)
        StudentpicLabel.Name = "StudentpicLabel"
        StudentpicLabel.Size = New System.Drawing.Size(107, 14)
        StudentpicLabel.TabIndex = 28
        StudentpicLabel.Text = "STUDENT PHOTO"
        '
        'ParentpicLabel
        '
        ParentpicLabel.AutoSize = True
        ParentpicLabel.Location = New System.Drawing.Point(788, 277)
        ParentpicLabel.Name = "ParentpicLabel"
        ParentpicLabel.Size = New System.Drawing.Size(122, 14)
        ParentpicLabel.TabIndex = 30
        ParentpicLabel.Text = "GUARDIAN PHOTO:"
        '
        'SECONDGUARDIANLabel
        '
        SECONDGUARDIANLabel.AutoSize = True
        SECONDGUARDIANLabel.Location = New System.Drawing.Point(15, 474)
        SECONDGUARDIANLabel.Name = "SECONDGUARDIANLabel"
        SECONDGUARDIANLabel.Size = New System.Drawing.Size(139, 14)
        SECONDGUARDIANLabel.TabIndex = 37
        SECONDGUARDIANLabel.Text = "2GUARDIAN/PARENT:"
        '
        'IDNUMBERLabel
        '
        IDNUMBERLabel.AutoSize = True
        IDNUMBERLabel.Location = New System.Drawing.Point(14, 502)
        IDNUMBERLabel.Name = "IDNUMBERLabel"
        IDNUMBERLabel.Size = New System.Drawing.Size(208, 14)
        IDNUMBERLabel.TabIndex = 38
        IDNUMBERLabel.Text = "2GUARDIAN/PARENT IDNUMBER:"
        '
        'SECONDGUARDIANPHONENUMBERLabel
        '
        SECONDGUARDIANPHONENUMBERLabel.AutoSize = True
        SECONDGUARDIANPHONENUMBERLabel.Location = New System.Drawing.Point(12, 534)
        SECONDGUARDIANPHONENUMBERLabel.Name = "SECONDGUARDIANPHONENUMBERLabel"
        SECONDGUARDIANPHONENUMBERLabel.Size = New System.Drawing.Size(184, 14)
        SECONDGUARDIANPHONENUMBERLabel.TabIndex = 40
        SECONDGUARDIANPHONENUMBERLabel.Text = "GUARDIAN2 PHONE NUMBER:"
        '
        'RESIDENTLabel
        '
        RESIDENTLabel.AutoSize = True
        RESIDENTLabel.Location = New System.Drawing.Point(15, 557)
        RESIDENTLabel.Name = "RESIDENTLabel"
        RESIDENTLabel.Size = New System.Drawing.Size(71, 14)
        RESIDENTLabel.TabIndex = 42
        RESIDENTLabel.Text = "RESIDENT:"
        '
        'GUARDIANOccupation_Label
        '
        GUARDIANOccupation_Label.AutoSize = True
        GUARDIANOccupation_Label.Location = New System.Drawing.Point(14, 583)
        GUARDIANOccupation_Label.Name = "GUARDIANOccupation_Label"
        GUARDIANOccupation_Label.Size = New System.Drawing.Size(153, 14)
        GUARDIANOccupation_Label.TabIndex = 44
        GUARDIANOccupation_Label.Text = "GUARDIAN Occupation :"
        '
        'KCPERESULTLabel
        '
        KCPERESULTLabel.AutoSize = True
        KCPERESULTLabel.Location = New System.Drawing.Point(16, 621)
        KCPERESULTLabel.Name = "KCPERESULTLabel"
        KCPERESULTLabel.Size = New System.Drawing.Size(88, 14)
        KCPERESULTLabel.TabIndex = 49
        KCPERESULTLabel.Text = "KCPERESULT:"
        '
        'REGISTATIONBindingNavigator
        '
        Me.REGISTATIONBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.REGISTATIONBindingNavigator.BindingSource = Me.REGISTATIONBindingSource
        Me.REGISTATIONBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.REGISTATIONBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.REGISTATIONBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.REGISTATIONBindingNavigatorSaveItem})
        Me.REGISTATIONBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.REGISTATIONBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.REGISTATIONBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.REGISTATIONBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.REGISTATIONBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.REGISTATIONBindingNavigator.Name = "REGISTATIONBindingNavigator"
        Me.REGISTATIONBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.REGISTATIONBindingNavigator.Size = New System.Drawing.Size(1073, 25)
        Me.REGISTATIONBindingNavigator.TabIndex = 0
        Me.REGISTATIONBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'REGISTATIONBindingSource
        '
        Me.REGISTATIONBindingSource.DataMember = "REGISTATION"
        Me.REGISTATIONBindingSource.DataSource = Me.Database1DataSet
        '
        'Database1DataSet
        '
        Me.Database1DataSet.DataSetName = "Database1DataSet"
        Me.Database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(50, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'REGISTATIONBindingNavigatorSaveItem
        '
        Me.REGISTATIONBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.REGISTATIONBindingNavigatorSaveItem.Image = CType(resources.GetObject("REGISTATIONBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.REGISTATIONBindingNavigatorSaveItem.Name = "REGISTATIONBindingNavigatorSaveItem"
        Me.REGISTATIONBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.REGISTATIONBindingNavigatorSaveItem.Text = "Save Data"
        '
        'FIRSTNAMETextBox
        '
        Me.FIRSTNAMETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "FIRSTNAME", True))
        Me.FIRSTNAMETextBox.Location = New System.Drawing.Point(288, 98)
        Me.FIRSTNAMETextBox.Name = "FIRSTNAMETextBox"
        Me.FIRSTNAMETextBox.Size = New System.Drawing.Size(451, 22)
        Me.FIRSTNAMETextBox.TabIndex = 2
        '
        'MIDDLENAMETextBox
        '
        Me.MIDDLENAMETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "MIDDLENAME", True))
        Me.MIDDLENAMETextBox.Location = New System.Drawing.Point(288, 126)
        Me.MIDDLENAMETextBox.Name = "MIDDLENAMETextBox"
        Me.MIDDLENAMETextBox.Size = New System.Drawing.Size(451, 22)
        Me.MIDDLENAMETextBox.TabIndex = 4
        '
        'LASTNAMETextBox
        '
        Me.LASTNAMETextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "LASTNAME", True))
        Me.LASTNAMETextBox.Location = New System.Drawing.Point(288, 154)
        Me.LASTNAMETextBox.Name = "LASTNAMETextBox"
        Me.LASTNAMETextBox.Size = New System.Drawing.Size(451, 22)
        Me.LASTNAMETextBox.TabIndex = 6
        '
        'DATEOFBIRTHDateTimePicker
        '
        Me.DATEOFBIRTHDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.REGISTATIONBindingSource, "DATEOFBIRTH", True))
        Me.DATEOFBIRTHDateTimePicker.Location = New System.Drawing.Point(288, 182)
        Me.DATEOFBIRTHDateTimePicker.Name = "DATEOFBIRTHDateTimePicker"
        Me.DATEOFBIRTHDateTimePicker.Size = New System.Drawing.Size(451, 22)
        Me.DATEOFBIRTHDateTimePicker.TabIndex = 8
        '
        'ADDRESSTextBox
        '
        Me.ADDRESSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "ADDRESS", True))
        Me.ADDRESSTextBox.Location = New System.Drawing.Point(288, 210)
        Me.ADDRESSTextBox.Name = "ADDRESSTextBox"
        Me.ADDRESSTextBox.Size = New System.Drawing.Size(451, 22)
        Me.ADDRESSTextBox.TabIndex = 10
        '
        'PHONENUMBERTextBox
        '
        Me.PHONENUMBERTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "PHONENUMBER", True))
        Me.PHONENUMBERTextBox.Location = New System.Drawing.Point(288, 238)
        Me.PHONENUMBERTextBox.Name = "PHONENUMBERTextBox"
        Me.PHONENUMBERTextBox.Size = New System.Drawing.Size(451, 22)
        Me.PHONENUMBERTextBox.TabIndex = 12
        '
        'EMAILTextBox
        '
        Me.EMAILTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "EMAIL", True))
        Me.EMAILTextBox.Location = New System.Drawing.Point(288, 266)
        Me.EMAILTextBox.Name = "EMAILTextBox"
        Me.EMAILTextBox.Size = New System.Drawing.Size(451, 22)
        Me.EMAILTextBox.TabIndex = 14
        '
        'NEXTOFKINTextBox
        '
        Me.NEXTOFKINTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "NEXTOFKIN", True))
        Me.NEXTOFKINTextBox.Location = New System.Drawing.Point(288, 294)
        Me.NEXTOFKINTextBox.Name = "NEXTOFKINTextBox"
        Me.NEXTOFKINTextBox.Size = New System.Drawing.Size(451, 22)
        Me.NEXTOFKINTextBox.TabIndex = 16
        '
        'NEXTOFKINRELATIONTextBox
        '
        Me.NEXTOFKINRELATIONTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "NEXTOFKINRELATION", True))
        Me.NEXTOFKINRELATIONTextBox.Location = New System.Drawing.Point(288, 333)
        Me.NEXTOFKINRELATIONTextBox.Name = "NEXTOFKINRELATIONTextBox"
        Me.NEXTOFKINRELATIONTextBox.Size = New System.Drawing.Size(451, 22)
        Me.NEXTOFKINRELATIONTextBox.TabIndex = 18
        '
        'REGISTRATIONDATEDateTimePicker
        '
        Me.REGISTRATIONDATEDateTimePicker.DataBindings.Add(New System.Windows.Forms.Binding("Value", Me.REGISTATIONBindingSource, "REGISTRATIONDATE", True))
        Me.REGISTRATIONDATEDateTimePicker.Location = New System.Drawing.Point(288, 367)
        Me.REGISTRATIONDATEDateTimePicker.Name = "REGISTRATIONDATEDateTimePicker"
        Me.REGISTRATIONDATEDateTimePicker.Size = New System.Drawing.Size(451, 22)
        Me.REGISTRATIONDATEDateTimePicker.TabIndex = 20
        '
        'GENDERComboBox
        '
        Me.GENDERComboBox.AllowDrop = True
        Me.GENDERComboBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "GENDER", True))
        Me.GENDERComboBox.FormattingEnabled = True
        Me.GENDERComboBox.Items.AddRange(New Object() {"Male", "Female"})
        Me.GENDERComboBox.Location = New System.Drawing.Point(288, 435)
        Me.GENDERComboBox.Name = "GENDERComboBox"
        Me.GENDERComboBox.Size = New System.Drawing.Size(451, 22)
        Me.GENDERComboBox.TabIndex = 26
        '
        'STUDENTNUMBERTextBox
        '
        Me.STUDENTNUMBERTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "STUDENTNUMBER", True))
        Me.STUDENTNUMBERTextBox.Location = New System.Drawing.Point(288, 59)
        Me.STUDENTNUMBERTextBox.Name = "STUDENTNUMBERTextBox"
        Me.STUDENTNUMBERTextBox.Size = New System.Drawing.Size(451, 22)
        Me.STUDENTNUMBERTextBox.TabIndex = 27
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.Button2)
        Me.GroupBox1.Controls.Add(Me.Button1)
        Me.GroupBox1.Location = New System.Drawing.Point(735, 502)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(338, 48)
        Me.GroupBox1.TabIndex = 28
        Me.GroupBox1.TabStop = False
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(153, 20)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(87, 25)
        Me.Button2.TabIndex = 1
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(27, 20)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(87, 25)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "ADD NEW"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'StudentpicPictureBox
        '
        Me.StudentpicPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.StudentpicPictureBox.DataBindings.Add(New System.Windows.Forms.Binding("Image", Me.REGISTATIONBindingSource, "studentpic", True))
        Me.StudentpicPictureBox.Location = New System.Drawing.Point(776, 104)
        Me.StudentpicPictureBox.Name = "StudentpicPictureBox"
        Me.StudentpicPictureBox.Size = New System.Drawing.Size(174, 113)
        Me.StudentpicPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.StudentpicPictureBox.TabIndex = 29
        Me.StudentpicPictureBox.TabStop = False
        '
        'ParentpicPictureBox
        '
        Me.ParentpicPictureBox.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ParentpicPictureBox.DataBindings.Add(New System.Windows.Forms.Binding("Image", Me.REGISTATIONBindingSource, "parentpic", True))
        Me.ParentpicPictureBox.Location = New System.Drawing.Point(785, 294)
        Me.ParentpicPictureBox.Name = "ParentpicPictureBox"
        Me.ParentpicPictureBox.Size = New System.Drawing.Size(165, 135)
        Me.ParentpicPictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.ParentpicPictureBox.TabIndex = 31
        Me.ParentpicPictureBox.TabStop = False
        '
        'Button3
        '
        Me.Button3.Location = New System.Drawing.Point(810, 251)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(75, 23)
        Me.Button3.TabIndex = 32
        Me.Button3.Text = "Browse"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button4
        '
        Me.Button4.Location = New System.Drawing.Point(810, 465)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 23)
        Me.Button4.TabIndex = 34
        Me.Button4.Text = "Browse"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'TextBox3
        '
        Me.TextBox3.Location = New System.Drawing.Point(795, 223)
        Me.TextBox3.Name = "TextBox3"
        Me.TextBox3.Size = New System.Drawing.Size(100, 22)
        Me.TextBox3.TabIndex = 36
        '
        'TextBox4
        '
        Me.TextBox4.Location = New System.Drawing.Point(795, 435)
        Me.TextBox4.Name = "TextBox4"
        Me.TextBox4.Size = New System.Drawing.Size(100, 22)
        Me.TextBox4.TabIndex = 37
        '
        'SECONDGUARDIANTextBox
        '
        Me.SECONDGUARDIANTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "SECONDGUARDIAN", True))
        Me.SECONDGUARDIANTextBox.Location = New System.Drawing.Point(288, 466)
        Me.SECONDGUARDIANTextBox.Name = "SECONDGUARDIANTextBox"
        Me.SECONDGUARDIANTextBox.Size = New System.Drawing.Size(441, 22)
        Me.SECONDGUARDIANTextBox.TabIndex = 38
        '
        'IDNUMBERTextBox
        '
        Me.IDNUMBERTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "IDNUMBER", True))
        Me.IDNUMBERTextBox.Location = New System.Drawing.Point(288, 494)
        Me.IDNUMBERTextBox.Name = "IDNUMBERTextBox"
        Me.IDNUMBERTextBox.Size = New System.Drawing.Size(441, 22)
        Me.IDNUMBERTextBox.TabIndex = 39
        '
        'SECONDGUARDIANPHONENUMBERTextBox
        '
        Me.SECONDGUARDIANPHONENUMBERTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "SECONDGUARDIANPHONENUMBER", True))
        Me.SECONDGUARDIANPHONENUMBERTextBox.Location = New System.Drawing.Point(288, 526)
        Me.SECONDGUARDIANPHONENUMBERTextBox.Name = "SECONDGUARDIANPHONENUMBERTextBox"
        Me.SECONDGUARDIANPHONENUMBERTextBox.Size = New System.Drawing.Size(441, 22)
        Me.SECONDGUARDIANPHONENUMBERTextBox.TabIndex = 41
        '
        'RESIDENTTextBox
        '
        Me.RESIDENTTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "RESIDENT", True))
        Me.RESIDENTTextBox.Location = New System.Drawing.Point(288, 554)
        Me.RESIDENTTextBox.Name = "RESIDENTTextBox"
        Me.RESIDENTTextBox.Size = New System.Drawing.Size(441, 22)
        Me.RESIDENTTextBox.TabIndex = 43
        '
        'GUARDIANOccupation_TextBox
        '
        Me.GUARDIANOccupation_TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "GUARDIANOccupation ", True))
        Me.GUARDIANOccupation_TextBox.Location = New System.Drawing.Point(288, 583)
        Me.GUARDIANOccupation_TextBox.Name = "GUARDIANOccupation_TextBox"
        Me.GUARDIANOccupation_TextBox.Size = New System.Drawing.Size(441, 22)
        Me.GUARDIANOccupation_TextBox.TabIndex = 45
        '
        'REGISTATIONTableAdapter
        '
        Me.REGISTATIONTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.ATTEDANCETableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.EXAMSTIMETABLETableAdapter = Nothing
        Me.TableAdapterManager.loginTableAdapter = Nothing
        Me.TableAdapterManager.PAYMENTTableAdapter = Nothing
        Me.TableAdapterManager.PERFORMANCETableAdapter = Nothing
        Me.TableAdapterManager.REGISTATIONTableAdapter = Me.REGISTATIONTableAdapter
        Me.TableAdapterManager.TDUTIESTableAdapter = Nothing
        Me.TableAdapterManager.timetableTableAdapter = Nothing
        Me.TableAdapterManager.UpdateOrder = SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'CLASSTextBox
        '
        Me.CLASSTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "CLASS", True))
        Me.CLASSTextBox.Location = New System.Drawing.Point(288, 410)
        Me.CLASSTextBox.Name = "CLASSTextBox"
        Me.CLASSTextBox.Size = New System.Drawing.Size(451, 22)
        Me.CLASSTextBox.TabIndex = 48
        '
        'REGISTATIONDataGridView
        '
        Me.REGISTATIONDataGridView.AutoGenerateColumns = False
        Me.REGISTATIONDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.REGISTATIONDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewImageColumn1, Me.DataGridViewImageColumn2, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19})
        Me.REGISTATIONDataGridView.DataSource = Me.REGISTATIONBindingSource
        Me.REGISTATIONDataGridView.Location = New System.Drawing.Point(735, 594)
        Me.REGISTATIONDataGridView.Name = "REGISTATIONDataGridView"
        Me.REGISTATIONDataGridView.Size = New System.Drawing.Size(265, 220)
        Me.REGISTATIONDataGridView.TabIndex = 48
        Me.REGISTATIONDataGridView.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "FIRSTNAME"
        Me.DataGridViewTextBoxColumn1.HeaderText = "FIRSTNAME"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "MIDDLENAME"
        Me.DataGridViewTextBoxColumn2.HeaderText = "MIDDLENAME"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "LASTNAME"
        Me.DataGridViewTextBoxColumn3.HeaderText = "LASTNAME"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "DATEOFBIRTH"
        Me.DataGridViewTextBoxColumn4.HeaderText = "DATEOFBIRTH"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "ADDRESS"
        Me.DataGridViewTextBoxColumn5.HeaderText = "ADDRESS"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "PHONENUMBER"
        Me.DataGridViewTextBoxColumn6.HeaderText = "PHONENUMBER"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "EMAIL"
        Me.DataGridViewTextBoxColumn7.HeaderText = "EMAIL"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "NEXTOFKIN"
        Me.DataGridViewTextBoxColumn8.HeaderText = "NEXTOFKIN"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "NEXTOFKINRELATION"
        Me.DataGridViewTextBoxColumn9.HeaderText = "NEXTOFKINRELATION"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "REGISTRATIONDATE"
        Me.DataGridViewTextBoxColumn10.HeaderText = "REGISTRATIONDATE"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "CLASS"
        Me.DataGridViewTextBoxColumn11.HeaderText = "CLASS"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn12.HeaderText = "STUDENTNUMBER"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "GENDER"
        Me.DataGridViewTextBoxColumn13.HeaderText = "GENDER"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewImageColumn1
        '
        Me.DataGridViewImageColumn1.DataPropertyName = "studentpic"
        Me.DataGridViewImageColumn1.HeaderText = "studentpic"
        Me.DataGridViewImageColumn1.Name = "DataGridViewImageColumn1"
        '
        'DataGridViewImageColumn2
        '
        Me.DataGridViewImageColumn2.DataPropertyName = "parentpic"
        Me.DataGridViewImageColumn2.HeaderText = "parentpic"
        Me.DataGridViewImageColumn2.Name = "DataGridViewImageColumn2"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "SECONDGUARDIAN"
        Me.DataGridViewTextBoxColumn14.HeaderText = "SECONDGUARDIAN"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "IDNUMBER"
        Me.DataGridViewTextBoxColumn15.HeaderText = "IDNUMBER"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "SECONDGUARDIANPHONENUMBER"
        Me.DataGridViewTextBoxColumn16.HeaderText = "SECONDGUARDIANPHONENUMBER"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "RESIDENT"
        Me.DataGridViewTextBoxColumn17.HeaderText = "RESIDENT"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.DataPropertyName = "GUARDIANOccupation "
        Me.DataGridViewTextBoxColumn18.HeaderText = "GUARDIANOccupation "
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.DataPropertyName = "KCPERESULT"
        Me.DataGridViewTextBoxColumn19.HeaderText = "KCPERESULT"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        '
        'Search_STUDENTNUMBERToolStrip
        '
        Me.Search_STUDENTNUMBERToolStrip.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Search_STUDENTNUMBERToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._LIKEToolStripLabel, Me._LIKEToolStripTextBox, Me.Search_STUDENTNUMBERToolStripButton})
        Me.Search_STUDENTNUMBERToolStrip.Location = New System.Drawing.Point(0, 25)
        Me.Search_STUDENTNUMBERToolStrip.Name = "Search_STUDENTNUMBERToolStrip"
        Me.Search_STUDENTNUMBERToolStrip.Size = New System.Drawing.Size(1073, 25)
        Me.Search_STUDENTNUMBERToolStrip.TabIndex = 49
        Me.Search_STUDENTNUMBERToolStrip.Text = "Search_STUDENTNUMBERToolStrip"
        '
        '_LIKEToolStripLabel
        '
        Me._LIKEToolStripLabel.Name = "_LIKEToolStripLabel"
        Me._LIKEToolStripLabel.Size = New System.Drawing.Size(146, 22)
        Me._LIKEToolStripLabel.Text = "Enter Student Number"
        '
        '_LIKEToolStripTextBox
        '
        Me._LIKEToolStripTextBox.Name = "_LIKEToolStripTextBox"
        Me._LIKEToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        'Search_STUDENTNUMBERToolStripButton
        '
        Me.Search_STUDENTNUMBERToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me.Search_STUDENTNUMBERToolStripButton.ForeColor = System.Drawing.Color.Red
        Me.Search_STUDENTNUMBERToolStripButton.Name = "Search_STUDENTNUMBERToolStripButton"
        Me.Search_STUDENTNUMBERToolStripButton.Size = New System.Drawing.Size(52, 22)
        Me.Search_STUDENTNUMBERToolStripButton.Text = "Search"
        '
        'KCPERESULTTextBox
        '
        Me.KCPERESULTTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.REGISTATIONBindingSource, "KCPERESULT", True))
        Me.KCPERESULTTextBox.Location = New System.Drawing.Point(288, 621)
        Me.KCPERESULTTextBox.Multiline = True
        Me.KCPERESULTTextBox.Name = "KCPERESULTTextBox"
        Me.KCPERESULTTextBox.Size = New System.Drawing.Size(163, 38)
        Me.KCPERESULTTextBox.TabIndex = 50
        '
        'registratio
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 14.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1028, 750)
        Me.Controls.Add(KCPERESULTLabel)
        Me.Controls.Add(Me.KCPERESULTTextBox)
        Me.Controls.Add(Me.Search_STUDENTNUMBERToolStrip)
        Me.Controls.Add(Me.REGISTATIONDataGridView)
        Me.Controls.Add(Me.CLASSTextBox)
        Me.Controls.Add(GUARDIANOccupation_Label)
        Me.Controls.Add(Me.GUARDIANOccupation_TextBox)
        Me.Controls.Add(RESIDENTLabel)
        Me.Controls.Add(Me.RESIDENTTextBox)
        Me.Controls.Add(SECONDGUARDIANPHONENUMBERLabel)
        Me.Controls.Add(Me.SECONDGUARDIANPHONENUMBERTextBox)
        Me.Controls.Add(IDNUMBERLabel)
        Me.Controls.Add(Me.IDNUMBERTextBox)
        Me.Controls.Add(SECONDGUARDIANLabel)
        Me.Controls.Add(Me.SECONDGUARDIANTextBox)
        Me.Controls.Add(Me.TextBox4)
        Me.Controls.Add(Me.TextBox3)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Button3)
        Me.Controls.Add(ParentpicLabel)
        Me.Controls.Add(Me.ParentpicPictureBox)
        Me.Controls.Add(StudentpicLabel)
        Me.Controls.Add(Me.StudentpicPictureBox)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.STUDENTNUMBERTextBox)
        Me.Controls.Add(FIRSTNAMELabel)
        Me.Controls.Add(Me.FIRSTNAMETextBox)
        Me.Controls.Add(MIDDLENAMELabel)
        Me.Controls.Add(Me.MIDDLENAMETextBox)
        Me.Controls.Add(LASTNAMELabel)
        Me.Controls.Add(Me.LASTNAMETextBox)
        Me.Controls.Add(DATEOFBIRTHLabel)
        Me.Controls.Add(Me.DATEOFBIRTHDateTimePicker)
        Me.Controls.Add(ADDRESSLabel)
        Me.Controls.Add(Me.ADDRESSTextBox)
        Me.Controls.Add(PHONENUMBERLabel)
        Me.Controls.Add(Me.PHONENUMBERTextBox)
        Me.Controls.Add(EMAILLabel)
        Me.Controls.Add(Me.EMAILTextBox)
        Me.Controls.Add(NEXTOFKINLabel)
        Me.Controls.Add(Me.NEXTOFKINTextBox)
        Me.Controls.Add(NEXTOFKINRELATIONLabel)
        Me.Controls.Add(Me.NEXTOFKINRELATIONTextBox)
        Me.Controls.Add(REGISTRATIONDATELabel)
        Me.Controls.Add(Me.REGISTRATIONDATEDateTimePicker)
        Me.Controls.Add(CLASSLabel)
        Me.Controls.Add(STUDENTNUMBERLabel)
        Me.Controls.Add(GENDERLabel)
        Me.Controls.Add(Me.GENDERComboBox)
        Me.Controls.Add(Me.REGISTATIONBindingNavigator)
        Me.Font = New System.Drawing.Font("Tahoma", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.Blue
        Me.Name = "registratio"
        Me.Text = "registration"
        CType(Me.REGISTATIONBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.REGISTATIONBindingNavigator.ResumeLayout(False)
        Me.REGISTATIONBindingNavigator.PerformLayout()
        CType(Me.REGISTATIONBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox1.ResumeLayout(False)
        CType(Me.StudentpicPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.ParentpicPictureBox, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.REGISTATIONDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Search_STUDENTNUMBERToolStrip.ResumeLayout(False)
        Me.Search_STUDENTNUMBERToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Database1DataSet As SCHOOLMANAGEMENTSYSTEM.Database1DataSet
    Friend WithEvents REGISTATIONBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents REGISTATIONTableAdapter As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.REGISTATIONTableAdapter
    Friend WithEvents TableAdapterManager As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents REGISTATIONBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents REGISTATIONBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents FIRSTNAMETextBox As System.Windows.Forms.TextBox
    Friend WithEvents MIDDLENAMETextBox As System.Windows.Forms.TextBox
    Friend WithEvents LASTNAMETextBox As System.Windows.Forms.TextBox
    Friend WithEvents DATEOFBIRTHDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents ADDRESSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PHONENUMBERTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EMAILTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NEXTOFKINTextBox As System.Windows.Forms.TextBox
    Friend WithEvents NEXTOFKINRELATIONTextBox As System.Windows.Forms.TextBox
    Friend WithEvents REGISTRATIONDATEDateTimePicker As System.Windows.Forms.DateTimePicker
    Friend WithEvents GENDERComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents STUDENTNUMBERTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents PERFORMANCEBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents StudentpicPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents ParentpicPictureBox As System.Windows.Forms.PictureBox
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents OpenFileDialog1 As System.Windows.Forms.OpenFileDialog
    Friend WithEvents TextBox3 As System.Windows.Forms.TextBox
    Friend WithEvents TextBox4 As System.Windows.Forms.TextBox
    Friend WithEvents SECONDGUARDIANTextBox As System.Windows.Forms.TextBox
    Friend WithEvents IDNUMBERTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SECONDGUARDIANPHONENUMBERTextBox As System.Windows.Forms.TextBox
    Friend WithEvents RESIDENTTextBox As System.Windows.Forms.TextBox
    Friend WithEvents GUARDIANOccupation_TextBox As System.Windows.Forms.TextBox
    Friend WithEvents CLASSTextBox As System.Windows.Forms.TextBox
    Friend WithEvents REGISTATIONDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewImageColumn1 As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents DataGridViewImageColumn2 As System.Windows.Forms.DataGridViewImageColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents Search_STUDENTNUMBERToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents _LIKEToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents _LIKEToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents Search_STUDENTNUMBERToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents KCPERESULTTextBox As System.Windows.Forms.TextBox
End Class
