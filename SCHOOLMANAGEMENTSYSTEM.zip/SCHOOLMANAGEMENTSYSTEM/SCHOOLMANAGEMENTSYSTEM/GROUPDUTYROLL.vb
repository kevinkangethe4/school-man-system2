﻿Imports System.Drawing.Printing
Public Class GROUPDUTYROLL
    Private mRow As Integer = 0
    Private newpage As Boolean = True
    Private Sub TDUTIESBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TDUTIESBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.TDUTIESBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub GROUPDUTYROLL_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.TDUTIES' table. You can move, or remove it, as needed.
        Me.TDUTIESTableAdapter.Fill(Me.Database1DataSet.TDUTIES)

    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim PrintDlg As PrintDialog = New PrintDialog()
        Dim PrintDlgRslt As DialogResult = New DialogResult()
        Dim MyDoc As PrintDocument = New PrintDocument()

        PrintDlg.Document = MyDoc

        PrintDlgRslt = PrintDlg.ShowDialog()
        If PrintDlgRslt = Windows.Forms.DialogResult.OK Then
            AddHandler MyDoc.PrintPage, AddressOf PrintDocument1_PrintPage
            MyDoc.Print()
        End If
    End Sub

    Private Sub PrintDocument1_BeginPrint(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintEventArgs) Handles PrintDocument1.BeginPrint
        mRow = 0
        newpage = True
        PrintPreviewDialog1.PrintPreviewControl.StartPage = 0
        PrintPreviewDialog1.PrintPreviewControl.Zoom = 1.0
    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim bm As New Bitmap(Me.TDUTIESDataGridView.Width, Me.TDUTIESDataGridView.Height)
        TDUTIESDataGridView.DrawToBitmap(bm, New Rectangle(0, 0, Me.TDUTIESDataGridView.Width, Me.TDUTIESDataGridView.Height))
        e.Graphics.DrawImage(bm, 0, 0)
    End Sub
End Class