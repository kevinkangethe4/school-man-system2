﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FRMTIMETABLE
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DayLabel As System.Windows.Forms.Label
        Dim TLabel As System.Windows.Forms.Label
        Dim _3_20_4_00Label As System.Windows.Forms.Label
        Dim TeLabel As System.Windows.Forms.Label
        Dim _2_40_3_20Label As System.Windows.Forms.Label
        Dim TeaLabel As System.Windows.Forms.Label
        Dim _2_00_2_40Label As System.Windows.Forms.Label
        Dim LUNCHLabel As System.Windows.Forms.Label
        Dim TeacLabel As System.Windows.Forms.Label
        Dim _12_00_12_40Label As System.Windows.Forms.Label
        Dim TeachLabel As System.Windows.Forms.Label
        Dim _11_20_12_00Label As System.Windows.Forms.Label
        Dim BREARKLabel As System.Windows.Forms.Label
        Dim TeacherLabel As System.Windows.Forms.Label
        Dim _10_20_11_00Label As System.Windows.Forms.Label
        Dim TecLabel As System.Windows.Forms.Label
        Dim _9_40_10_20Label As System.Windows.Forms.Label
        Dim BREAKLabel As System.Windows.Forms.Label
        Dim EachLabel As System.Windows.Forms.Label
        Dim _9_20_9_20Label As System.Windows.Forms.Label
        Dim TeacheLabel As System.Windows.Forms.Label
        Dim _8_00_8_40Label As System.Windows.Forms.Label
        Dim ClassLabel As System.Windows.Forms.Label
        Dim DayLabel1 As System.Windows.Forms.Label
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(FRMTIMETABLE))
        Me.Database1DataSet = New SCHOOLMANAGEMENTSYSTEM.Database1DataSet()
        Me.TimetableBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TimetableTableAdapter = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.timetableTableAdapter()
        Me.TableAdapterManager = New SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager()
        Me.TimetableBindingNavigator = New System.Windows.Forms.BindingNavigator(Me.components)
        Me.BindingNavigatorAddNewItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorCountItem = New System.Windows.Forms.ToolStripLabel()
        Me.BindingNavigatorDeleteItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveFirstItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMovePreviousItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorPositionItem = New System.Windows.Forms.ToolStripTextBox()
        Me.BindingNavigatorSeparator1 = New System.Windows.Forms.ToolStripSeparator()
        Me.BindingNavigatorMoveNextItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorMoveLastItem = New System.Windows.Forms.ToolStripButton()
        Me.BindingNavigatorSeparator2 = New System.Windows.Forms.ToolStripSeparator()
        Me.TimetableBindingNavigatorSaveItem = New System.Windows.Forms.ToolStripButton()
        Me.TTextBox = New System.Windows.Forms.TextBox()
        Me._3_20_4_00TextBox = New System.Windows.Forms.TextBox()
        Me.TeTextBox = New System.Windows.Forms.TextBox()
        Me._2_40_3_20TextBox = New System.Windows.Forms.TextBox()
        Me.TeaTextBox = New System.Windows.Forms.TextBox()
        Me._2_00_2_40TextBox = New System.Windows.Forms.TextBox()
        Me.LUNCHTextBox = New System.Windows.Forms.TextBox()
        Me.TeacTextBox = New System.Windows.Forms.TextBox()
        Me._12_00_12_40TextBox = New System.Windows.Forms.TextBox()
        Me.TeachTextBox = New System.Windows.Forms.TextBox()
        Me._11_20_12_00TextBox = New System.Windows.Forms.TextBox()
        Me.BREARKTextBox = New System.Windows.Forms.TextBox()
        Me.TeacherTextBox = New System.Windows.Forms.TextBox()
        Me._10_20_11_00TextBox = New System.Windows.Forms.TextBox()
        Me.TecTextBox = New System.Windows.Forms.TextBox()
        Me._9_40_10_20TextBox = New System.Windows.Forms.TextBox()
        Me.BREAKTextBox = New System.Windows.Forms.TextBox()
        Me.EachTextBox = New System.Windows.Forms.TextBox()
        Me._9_20_9_20TextBox = New System.Windows.Forms.TextBox()
        Me.TeacheTextBox = New System.Windows.Forms.TextBox()
        Me._8_00_8_40TextBox = New System.Windows.Forms.TextBox()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.DayTextBox = New System.Windows.Forms.TextBox()
        Me.ClassTextBox = New System.Windows.Forms.TextBox()
        Me.TimetableDataGridView = New System.Windows.Forms.DataGridView()
        Me.DataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn2 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn3 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn4 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn5 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn6 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn7 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn8 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn9 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn10 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn11 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn12 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn13 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn14 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn15 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn16 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn17 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn18 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn19 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn20 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn21 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn22 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DataGridViewTextBoxColumn23 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me._ClassToolStrip = New System.Windows.Forms.ToolStrip()
        Me._LIKEToolStripLabel = New System.Windows.Forms.ToolStripLabel()
        Me._LIKEToolStripTextBox = New System.Windows.Forms.ToolStripTextBox()
        Me._ClassToolStripButton = New System.Windows.Forms.ToolStripButton()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        DayLabel = New System.Windows.Forms.Label()
        TLabel = New System.Windows.Forms.Label()
        _3_20_4_00Label = New System.Windows.Forms.Label()
        TeLabel = New System.Windows.Forms.Label()
        _2_40_3_20Label = New System.Windows.Forms.Label()
        TeaLabel = New System.Windows.Forms.Label()
        _2_00_2_40Label = New System.Windows.Forms.Label()
        LUNCHLabel = New System.Windows.Forms.Label()
        TeacLabel = New System.Windows.Forms.Label()
        _12_00_12_40Label = New System.Windows.Forms.Label()
        TeachLabel = New System.Windows.Forms.Label()
        _11_20_12_00Label = New System.Windows.Forms.Label()
        BREARKLabel = New System.Windows.Forms.Label()
        TeacherLabel = New System.Windows.Forms.Label()
        _10_20_11_00Label = New System.Windows.Forms.Label()
        TecLabel = New System.Windows.Forms.Label()
        _9_40_10_20Label = New System.Windows.Forms.Label()
        BREAKLabel = New System.Windows.Forms.Label()
        EachLabel = New System.Windows.Forms.Label()
        _9_20_9_20Label = New System.Windows.Forms.Label()
        TeacheLabel = New System.Windows.Forms.Label()
        _8_00_8_40Label = New System.Windows.Forms.Label()
        ClassLabel = New System.Windows.Forms.Label()
        DayLabel1 = New System.Windows.Forms.Label()
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TimetableBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TimetableBindingNavigator, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TimetableBindingNavigator.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        CType(Me.TimetableDataGridView, System.ComponentModel.ISupportInitialize).BeginInit()
        Me._ClassToolStrip.SuspendLayout()
        Me.SuspendLayout()
        '
        'DayLabel
        '
        DayLabel.AutoSize = True
        DayLabel.Location = New System.Drawing.Point(42, 644)
        DayLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        DayLabel.Name = "DayLabel"
        DayLabel.Size = New System.Drawing.Size(35, 15)
        DayLabel.TabIndex = 44
        DayLabel.Text = "Day:"
        AddHandler DayLabel.Click, AddressOf Me.DayLabel_Click
        '
        'TLabel
        '
        TLabel.AutoSize = True
        TLabel.Location = New System.Drawing.Point(8, 674)
        TLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TLabel.Name = "TLabel"
        TLabel.Size = New System.Drawing.Size(59, 15)
        TLabel.TabIndex = 40
        TLabel.Text = "Teacher"
        AddHandler TLabel.Click, AddressOf Me.TLabel_Click
        '
        '_3_20_4_00Label
        '
        _3_20_4_00Label.AutoSize = True
        _3_20_4_00Label.Location = New System.Drawing.Point(8, 644)
        _3_20_4_00Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _3_20_4_00Label.Name = "_3_20_4_00Label"
        _3_20_4_00Label.Size = New System.Drawing.Size(72, 15)
        _3_20_4_00Label.TabIndex = 38
        _3_20_4_00Label.Text = "3:20-4:00:"
        AddHandler _3_20_4_00Label.Click, AddressOf Me._3_20_4_00Label_Click
        '
        'TeLabel
        '
        TeLabel.AutoSize = True
        TeLabel.Location = New System.Drawing.Point(8, 614)
        TeLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TeLabel.Name = "TeLabel"
        TeLabel.Size = New System.Drawing.Size(59, 15)
        TeLabel.TabIndex = 36
        TeLabel.Text = "Teacher"
        AddHandler TeLabel.Click, AddressOf Me.TeLabel_Click
        '
        '_2_40_3_20Label
        '
        _2_40_3_20Label.AutoSize = True
        _2_40_3_20Label.Location = New System.Drawing.Point(8, 584)
        _2_40_3_20Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _2_40_3_20Label.Name = "_2_40_3_20Label"
        _2_40_3_20Label.Size = New System.Drawing.Size(72, 15)
        _2_40_3_20Label.TabIndex = 34
        _2_40_3_20Label.Text = "2:40-3:20:"
        AddHandler _2_40_3_20Label.Click, AddressOf Me._2_40_3_20Label_Click
        '
        'TeaLabel
        '
        TeaLabel.AutoSize = True
        TeaLabel.Location = New System.Drawing.Point(8, 554)
        TeaLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TeaLabel.Name = "TeaLabel"
        TeaLabel.Size = New System.Drawing.Size(59, 15)
        TeaLabel.TabIndex = 32
        TeaLabel.Text = "Teacher"
        AddHandler TeaLabel.Click, AddressOf Me.TeaLabel_Click
        '
        '_2_00_2_40Label
        '
        _2_00_2_40Label.AutoSize = True
        _2_00_2_40Label.Location = New System.Drawing.Point(8, 524)
        _2_00_2_40Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _2_00_2_40Label.Name = "_2_00_2_40Label"
        _2_00_2_40Label.Size = New System.Drawing.Size(72, 15)
        _2_00_2_40Label.TabIndex = 30
        _2_00_2_40Label.Text = "2:00-2:40:"
        AddHandler _2_00_2_40Label.Click, AddressOf Me._2_00_2_40Label_Click
        '
        'LUNCHLabel
        '
        LUNCHLabel.AutoSize = True
        LUNCHLabel.ForeColor = System.Drawing.Color.Fuchsia
        LUNCHLabel.Location = New System.Drawing.Point(8, 494)
        LUNCHLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        LUNCHLabel.Name = "LUNCHLabel"
        LUNCHLabel.Size = New System.Drawing.Size(58, 15)
        LUNCHLabel.TabIndex = 28
        LUNCHLabel.Text = "LUNCH:"
        AddHandler LUNCHLabel.Click, AddressOf Me.LUNCHLabel_Click
        '
        'TeacLabel
        '
        TeacLabel.AutoSize = True
        TeacLabel.Location = New System.Drawing.Point(8, 464)
        TeacLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TeacLabel.Name = "TeacLabel"
        TeacLabel.Size = New System.Drawing.Size(59, 15)
        TeacLabel.TabIndex = 26
        TeacLabel.Text = "Teacher"
        AddHandler TeacLabel.Click, AddressOf Me.TeacLabel_Click
        '
        '_12_00_12_40Label
        '
        _12_00_12_40Label.AutoSize = True
        _12_00_12_40Label.Location = New System.Drawing.Point(8, 434)
        _12_00_12_40Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _12_00_12_40Label.Name = "_12_00_12_40Label"
        _12_00_12_40Label.Size = New System.Drawing.Size(88, 15)
        _12_00_12_40Label.TabIndex = 24
        _12_00_12_40Label.Text = "12:00-12:40:"
        AddHandler _12_00_12_40Label.Click, AddressOf Me._12_00_12_40Label_Click
        '
        'TeachLabel
        '
        TeachLabel.AutoSize = True
        TeachLabel.Location = New System.Drawing.Point(8, 404)
        TeachLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TeachLabel.Name = "TeachLabel"
        TeachLabel.Size = New System.Drawing.Size(59, 15)
        TeachLabel.TabIndex = 22
        TeachLabel.Text = "Teacher"
        AddHandler TeachLabel.Click, AddressOf Me.TeachLabel_Click
        '
        '_11_20_12_00Label
        '
        _11_20_12_00Label.AutoSize = True
        _11_20_12_00Label.Location = New System.Drawing.Point(8, 374)
        _11_20_12_00Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _11_20_12_00Label.Name = "_11_20_12_00Label"
        _11_20_12_00Label.Size = New System.Drawing.Size(88, 15)
        _11_20_12_00Label.TabIndex = 20
        _11_20_12_00Label.Text = "11:20-12:00:"
        AddHandler _11_20_12_00Label.Click, AddressOf Me._11_20_12_00Label_Click
        '
        'BREARKLabel
        '
        BREARKLabel.AutoSize = True
        BREARKLabel.ForeColor = System.Drawing.Color.Fuchsia
        BREARKLabel.Location = New System.Drawing.Point(8, 344)
        BREARKLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        BREARKLabel.Name = "BREARKLabel"
        BREARKLabel.Size = New System.Drawing.Size(56, 15)
        BREARKLabel.TabIndex = 18
        BREARKLabel.Text = "BREAK:"
        AddHandler BREARKLabel.Click, AddressOf Me.BREARKLabel_Click
        '
        'TeacherLabel
        '
        TeacherLabel.AutoSize = True
        TeacherLabel.Location = New System.Drawing.Point(8, 314)
        TeacherLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TeacherLabel.Name = "TeacherLabel"
        TeacherLabel.Size = New System.Drawing.Size(63, 15)
        TeacherLabel.TabIndex = 16
        TeacherLabel.Text = "Teacher:"
        AddHandler TeacherLabel.Click, AddressOf Me.TeacherLabel_Click
        '
        '_10_20_11_00Label
        '
        _10_20_11_00Label.AutoSize = True
        _10_20_11_00Label.Location = New System.Drawing.Point(8, 284)
        _10_20_11_00Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _10_20_11_00Label.Name = "_10_20_11_00Label"
        _10_20_11_00Label.Size = New System.Drawing.Size(88, 15)
        _10_20_11_00Label.TabIndex = 14
        _10_20_11_00Label.Text = "10:20-11:00:"
        AddHandler _10_20_11_00Label.Click, AddressOf Me._10_20_11_00Label_Click
        '
        'TecLabel
        '
        TecLabel.AutoSize = True
        TecLabel.Location = New System.Drawing.Point(8, 254)
        TecLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TecLabel.Name = "TecLabel"
        TecLabel.Size = New System.Drawing.Size(59, 15)
        TecLabel.TabIndex = 12
        TecLabel.Text = "Teacher"
        AddHandler TecLabel.Click, AddressOf Me.TecLabel_Click
        '
        '_9_40_10_20Label
        '
        _9_40_10_20Label.AutoSize = True
        _9_40_10_20Label.Location = New System.Drawing.Point(8, 224)
        _9_40_10_20Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _9_40_10_20Label.Name = "_9_40_10_20Label"
        _9_40_10_20Label.Size = New System.Drawing.Size(80, 15)
        _9_40_10_20Label.TabIndex = 10
        _9_40_10_20Label.Text = "9:40-10:20:"
        AddHandler _9_40_10_20Label.Click, AddressOf Me._9_40_10_20Label_Click
        '
        'BREAKLabel
        '
        BREAKLabel.AutoSize = True
        BREAKLabel.ForeColor = System.Drawing.Color.Fuchsia
        BREAKLabel.Location = New System.Drawing.Point(8, 194)
        BREAKLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        BREAKLabel.Name = "BREAKLabel"
        BREAKLabel.Size = New System.Drawing.Size(56, 15)
        BREAKLabel.TabIndex = 8
        BREAKLabel.Text = "BREAK:"
        AddHandler BREAKLabel.Click, AddressOf Me.BREAKLabel_Click
        '
        'EachLabel
        '
        EachLabel.AutoSize = True
        EachLabel.Location = New System.Drawing.Point(8, 164)
        EachLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        EachLabel.Name = "EachLabel"
        EachLabel.Size = New System.Drawing.Size(59, 15)
        EachLabel.TabIndex = 6
        EachLabel.Text = "Teacher"
        AddHandler EachLabel.Click, AddressOf Me.EachLabel_Click
        '
        '_9_20_9_20Label
        '
        _9_20_9_20Label.AutoSize = True
        _9_20_9_20Label.Location = New System.Drawing.Point(8, 134)
        _9_20_9_20Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _9_20_9_20Label.Name = "_9_20_9_20Label"
        _9_20_9_20Label.Size = New System.Drawing.Size(72, 15)
        _9_20_9_20Label.TabIndex = 4
        _9_20_9_20Label.Text = "8:40-9:20:"
        AddHandler _9_20_9_20Label.Click, AddressOf Me._9_20_9_20Label_Click
        '
        'TeacheLabel
        '
        TeacheLabel.AutoSize = True
        TeacheLabel.Location = New System.Drawing.Point(8, 104)
        TeacheLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        TeacheLabel.Name = "TeacheLabel"
        TeacheLabel.Size = New System.Drawing.Size(59, 15)
        TeacheLabel.TabIndex = 2
        TeacheLabel.Text = "Teacher"
        AddHandler TeacheLabel.Click, AddressOf Me.TeacheLabel_Click
        '
        '_8_00_8_40Label
        '
        _8_00_8_40Label.AutoSize = True
        _8_00_8_40Label.Location = New System.Drawing.Point(8, 74)
        _8_00_8_40Label.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        _8_00_8_40Label.Name = "_8_00_8_40Label"
        _8_00_8_40Label.Size = New System.Drawing.Size(72, 15)
        _8_00_8_40Label.TabIndex = 0
        _8_00_8_40Label.Text = "8:00-8:40:"
        AddHandler _8_00_8_40Label.Click, AddressOf Me._8_00_8_40Label_Click
        '
        'ClassLabel
        '
        ClassLabel.AutoSize = True
        ClassLabel.Location = New System.Drawing.Point(16, 17)
        ClassLabel.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        ClassLabel.Name = "ClassLabel"
        ClassLabel.Size = New System.Drawing.Size(46, 15)
        ClassLabel.TabIndex = 44
        ClassLabel.Text = "Class:"
        AddHandler ClassLabel.Click, AddressOf Me.ClassLabel_Click
        '
        'DayLabel1
        '
        DayLabel1.AutoSize = True
        DayLabel1.Location = New System.Drawing.Point(16, 43)
        DayLabel1.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        DayLabel1.Name = "DayLabel1"
        DayLabel1.Size = New System.Drawing.Size(35, 15)
        DayLabel1.TabIndex = 45
        DayLabel1.Text = "Day:"
        AddHandler DayLabel1.Click, AddressOf Me.DayLabel1_Click
        '
        'Database1DataSet
        '
        Me.Database1DataSet.DataSetName = "Database1DataSet"
        Me.Database1DataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TimetableBindingSource
        '
        Me.TimetableBindingSource.DataMember = "timetable"
        Me.TimetableBindingSource.DataSource = Me.Database1DataSet
        '
        'TimetableTableAdapter
        '
        Me.TimetableTableAdapter.ClearBeforeFill = True
        '
        'TableAdapterManager
        '
        Me.TableAdapterManager.ATTEDANCETableAdapter = Nothing
        Me.TableAdapterManager.BackupDataSetBeforeUpdate = False
        Me.TableAdapterManager.loginTableAdapter = Nothing
        Me.TableAdapterManager.PAYMENTTableAdapter = Nothing
        Me.TableAdapterManager.PERFORMANCETableAdapter = Nothing
        Me.TableAdapterManager.REGISTATIONTableAdapter = Nothing
        Me.TableAdapterManager.timetableTableAdapter = Me.TimetableTableAdapter
        Me.TableAdapterManager.UpdateOrder = SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete
        '
        'TimetableBindingNavigator
        '
        Me.TimetableBindingNavigator.AddNewItem = Me.BindingNavigatorAddNewItem
        Me.TimetableBindingNavigator.BindingSource = Me.TimetableBindingSource
        Me.TimetableBindingNavigator.CountItem = Me.BindingNavigatorCountItem
        Me.TimetableBindingNavigator.DeleteItem = Me.BindingNavigatorDeleteItem
        Me.TimetableBindingNavigator.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BindingNavigatorMoveFirstItem, Me.BindingNavigatorMovePreviousItem, Me.BindingNavigatorSeparator, Me.BindingNavigatorPositionItem, Me.BindingNavigatorCountItem, Me.BindingNavigatorSeparator1, Me.BindingNavigatorMoveNextItem, Me.BindingNavigatorMoveLastItem, Me.BindingNavigatorSeparator2, Me.BindingNavigatorAddNewItem, Me.BindingNavigatorDeleteItem, Me.TimetableBindingNavigatorSaveItem})
        Me.TimetableBindingNavigator.Location = New System.Drawing.Point(0, 0)
        Me.TimetableBindingNavigator.MoveFirstItem = Me.BindingNavigatorMoveFirstItem
        Me.TimetableBindingNavigator.MoveLastItem = Me.BindingNavigatorMoveLastItem
        Me.TimetableBindingNavigator.MoveNextItem = Me.BindingNavigatorMoveNextItem
        Me.TimetableBindingNavigator.MovePreviousItem = Me.BindingNavigatorMovePreviousItem
        Me.TimetableBindingNavigator.Name = "TimetableBindingNavigator"
        Me.TimetableBindingNavigator.PositionItem = Me.BindingNavigatorPositionItem
        Me.TimetableBindingNavigator.Size = New System.Drawing.Size(1011, 25)
        Me.TimetableBindingNavigator.TabIndex = 1
        Me.TimetableBindingNavigator.Text = "BindingNavigator1"
        '
        'BindingNavigatorAddNewItem
        '
        Me.BindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorAddNewItem.Image = CType(resources.GetObject("BindingNavigatorAddNewItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorAddNewItem.Name = "BindingNavigatorAddNewItem"
        Me.BindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorAddNewItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorAddNewItem.Text = "Add new"
        '
        'BindingNavigatorCountItem
        '
        Me.BindingNavigatorCountItem.Name = "BindingNavigatorCountItem"
        Me.BindingNavigatorCountItem.Size = New System.Drawing.Size(35, 22)
        Me.BindingNavigatorCountItem.Text = "of {0}"
        Me.BindingNavigatorCountItem.ToolTipText = "Total number of items"
        '
        'BindingNavigatorDeleteItem
        '
        Me.BindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorDeleteItem.Image = CType(resources.GetObject("BindingNavigatorDeleteItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorDeleteItem.Name = "BindingNavigatorDeleteItem"
        Me.BindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorDeleteItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorDeleteItem.Text = "Delete"
        '
        'BindingNavigatorMoveFirstItem
        '
        Me.BindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveFirstItem.Image = CType(resources.GetObject("BindingNavigatorMoveFirstItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveFirstItem.Name = "BindingNavigatorMoveFirstItem"
        Me.BindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveFirstItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveFirstItem.Text = "Move first"
        '
        'BindingNavigatorMovePreviousItem
        '
        Me.BindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMovePreviousItem.Image = CType(resources.GetObject("BindingNavigatorMovePreviousItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMovePreviousItem.Name = "BindingNavigatorMovePreviousItem"
        Me.BindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMovePreviousItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMovePreviousItem.Text = "Move previous"
        '
        'BindingNavigatorSeparator
        '
        Me.BindingNavigatorSeparator.Name = "BindingNavigatorSeparator"
        Me.BindingNavigatorSeparator.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorPositionItem
        '
        Me.BindingNavigatorPositionItem.AccessibleName = "Position"
        Me.BindingNavigatorPositionItem.AutoSize = False
        Me.BindingNavigatorPositionItem.Name = "BindingNavigatorPositionItem"
        Me.BindingNavigatorPositionItem.Size = New System.Drawing.Size(65, 23)
        Me.BindingNavigatorPositionItem.Text = "0"
        Me.BindingNavigatorPositionItem.ToolTipText = "Current position"
        '
        'BindingNavigatorSeparator1
        '
        Me.BindingNavigatorSeparator1.Name = "BindingNavigatorSeparator1"
        Me.BindingNavigatorSeparator1.Size = New System.Drawing.Size(6, 25)
        '
        'BindingNavigatorMoveNextItem
        '
        Me.BindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveNextItem.Image = CType(resources.GetObject("BindingNavigatorMoveNextItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveNextItem.Name = "BindingNavigatorMoveNextItem"
        Me.BindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveNextItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveNextItem.Text = "Move next"
        '
        'BindingNavigatorMoveLastItem
        '
        Me.BindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.BindingNavigatorMoveLastItem.Image = CType(resources.GetObject("BindingNavigatorMoveLastItem.Image"), System.Drawing.Image)
        Me.BindingNavigatorMoveLastItem.Name = "BindingNavigatorMoveLastItem"
        Me.BindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = True
        Me.BindingNavigatorMoveLastItem.Size = New System.Drawing.Size(23, 22)
        Me.BindingNavigatorMoveLastItem.Text = "Move last"
        '
        'BindingNavigatorSeparator2
        '
        Me.BindingNavigatorSeparator2.Name = "BindingNavigatorSeparator2"
        Me.BindingNavigatorSeparator2.Size = New System.Drawing.Size(6, 25)
        '
        'TimetableBindingNavigatorSaveItem
        '
        Me.TimetableBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image
        Me.TimetableBindingNavigatorSaveItem.Image = CType(resources.GetObject("TimetableBindingNavigatorSaveItem.Image"), System.Drawing.Image)
        Me.TimetableBindingNavigatorSaveItem.Name = "TimetableBindingNavigatorSaveItem"
        Me.TimetableBindingNavigatorSaveItem.Size = New System.Drawing.Size(23, 22)
        Me.TimetableBindingNavigatorSaveItem.Text = "Save Data"
        '
        'TTextBox
        '
        Me.TTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "T", True))
        Me.TTextBox.Location = New System.Drawing.Point(105, 670)
        Me.TTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TTextBox.Name = "TTextBox"
        Me.TTextBox.Size = New System.Drawing.Size(711, 21)
        Me.TTextBox.TabIndex = 41
        '
        '_3_20_4_00TextBox
        '
        Me._3_20_4_00TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "3:20-4:00", True))
        Me._3_20_4_00TextBox.Location = New System.Drawing.Point(105, 640)
        Me._3_20_4_00TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._3_20_4_00TextBox.Name = "_3_20_4_00TextBox"
        Me._3_20_4_00TextBox.Size = New System.Drawing.Size(599, 21)
        Me._3_20_4_00TextBox.TabIndex = 39
        '
        'TeTextBox
        '
        Me.TeTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Te", True))
        Me.TeTextBox.Location = New System.Drawing.Point(105, 610)
        Me.TeTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TeTextBox.Name = "TeTextBox"
        Me.TeTextBox.Size = New System.Drawing.Size(599, 21)
        Me.TeTextBox.TabIndex = 37
        '
        '_2_40_3_20TextBox
        '
        Me._2_40_3_20TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "2:40-3:20", True))
        Me._2_40_3_20TextBox.Location = New System.Drawing.Point(105, 580)
        Me._2_40_3_20TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._2_40_3_20TextBox.Name = "_2_40_3_20TextBox"
        Me._2_40_3_20TextBox.Size = New System.Drawing.Size(599, 21)
        Me._2_40_3_20TextBox.TabIndex = 35
        '
        'TeaTextBox
        '
        Me.TeaTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Tea", True))
        Me.TeaTextBox.Location = New System.Drawing.Point(105, 550)
        Me.TeaTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TeaTextBox.Name = "TeaTextBox"
        Me.TeaTextBox.Size = New System.Drawing.Size(599, 21)
        Me.TeaTextBox.TabIndex = 33
        '
        '_2_00_2_40TextBox
        '
        Me._2_00_2_40TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "2:00-2:40", True))
        Me._2_00_2_40TextBox.Location = New System.Drawing.Point(105, 520)
        Me._2_00_2_40TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._2_00_2_40TextBox.Name = "_2_00_2_40TextBox"
        Me._2_00_2_40TextBox.Size = New System.Drawing.Size(599, 21)
        Me._2_00_2_40TextBox.TabIndex = 31
        '
        'LUNCHTextBox
        '
        Me.LUNCHTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.LUNCHTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "LUNCH", True))
        Me.LUNCHTextBox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.LUNCHTextBox.Location = New System.Drawing.Point(105, 490)
        Me.LUNCHTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.LUNCHTextBox.Name = "LUNCHTextBox"
        Me.LUNCHTextBox.ReadOnly = True
        Me.LUNCHTextBox.Size = New System.Drawing.Size(599, 21)
        Me.LUNCHTextBox.TabIndex = 29
        Me.LUNCHTextBox.Text = "LUNCH"
        '
        'TeacTextBox
        '
        Me.TeacTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Teac", True))
        Me.TeacTextBox.Location = New System.Drawing.Point(105, 460)
        Me.TeacTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TeacTextBox.Name = "TeacTextBox"
        Me.TeacTextBox.Size = New System.Drawing.Size(599, 21)
        Me.TeacTextBox.TabIndex = 27
        '
        '_12_00_12_40TextBox
        '
        Me._12_00_12_40TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "12:00-12:40", True))
        Me._12_00_12_40TextBox.Location = New System.Drawing.Point(105, 430)
        Me._12_00_12_40TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._12_00_12_40TextBox.Name = "_12_00_12_40TextBox"
        Me._12_00_12_40TextBox.Size = New System.Drawing.Size(599, 21)
        Me._12_00_12_40TextBox.TabIndex = 25
        '
        'TeachTextBox
        '
        Me.TeachTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Teach", True))
        Me.TeachTextBox.Location = New System.Drawing.Point(105, 400)
        Me.TeachTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TeachTextBox.Name = "TeachTextBox"
        Me.TeachTextBox.Size = New System.Drawing.Size(599, 21)
        Me.TeachTextBox.TabIndex = 23
        '
        '_11_20_12_00TextBox
        '
        Me._11_20_12_00TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "11:20-12:00", True))
        Me._11_20_12_00TextBox.Location = New System.Drawing.Point(105, 370)
        Me._11_20_12_00TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._11_20_12_00TextBox.Name = "_11_20_12_00TextBox"
        Me._11_20_12_00TextBox.Size = New System.Drawing.Size(599, 21)
        Me._11_20_12_00TextBox.TabIndex = 21
        '
        'BREARKTextBox
        '
        Me.BREARKTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BREARKTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "BREARK", True))
        Me.BREARKTextBox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BREARKTextBox.Location = New System.Drawing.Point(105, 340)
        Me.BREARKTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BREARKTextBox.Name = "BREARKTextBox"
        Me.BREARKTextBox.ReadOnly = True
        Me.BREARKTextBox.Size = New System.Drawing.Size(599, 21)
        Me.BREARKTextBox.TabIndex = 19
        Me.BREARKTextBox.Text = "BREAK"
        '
        'TeacherTextBox
        '
        Me.TeacherTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Teacher", True))
        Me.TeacherTextBox.Location = New System.Drawing.Point(105, 310)
        Me.TeacherTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TeacherTextBox.Name = "TeacherTextBox"
        Me.TeacherTextBox.Size = New System.Drawing.Size(599, 21)
        Me.TeacherTextBox.TabIndex = 17
        '
        '_10_20_11_00TextBox
        '
        Me._10_20_11_00TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "10:20-11:00", True))
        Me._10_20_11_00TextBox.Location = New System.Drawing.Point(104, 278)
        Me._10_20_11_00TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._10_20_11_00TextBox.Name = "_10_20_11_00TextBox"
        Me._10_20_11_00TextBox.Size = New System.Drawing.Size(599, 21)
        Me._10_20_11_00TextBox.TabIndex = 15
        '
        'TecTextBox
        '
        Me.TecTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Tec", True))
        Me.TecTextBox.Location = New System.Drawing.Point(105, 250)
        Me.TecTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TecTextBox.Name = "TecTextBox"
        Me.TecTextBox.Size = New System.Drawing.Size(599, 21)
        Me.TecTextBox.TabIndex = 13
        '
        '_9_40_10_20TextBox
        '
        Me._9_40_10_20TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "9:40-10:20", True))
        Me._9_40_10_20TextBox.Location = New System.Drawing.Point(105, 220)
        Me._9_40_10_20TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._9_40_10_20TextBox.Name = "_9_40_10_20TextBox"
        Me._9_40_10_20TextBox.Size = New System.Drawing.Size(599, 21)
        Me._9_40_10_20TextBox.TabIndex = 11
        '
        'BREAKTextBox
        '
        Me.BREAKTextBox.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.BREAKTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "BREAK", True))
        Me.BREAKTextBox.ForeColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BREAKTextBox.Location = New System.Drawing.Point(105, 190)
        Me.BREAKTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.BREAKTextBox.Name = "BREAKTextBox"
        Me.BREAKTextBox.ReadOnly = True
        Me.BREAKTextBox.Size = New System.Drawing.Size(599, 21)
        Me.BREAKTextBox.TabIndex = 9
        Me.BREAKTextBox.Text = "BREAK"
        '
        'EachTextBox
        '
        Me.EachTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "each", True))
        Me.EachTextBox.Location = New System.Drawing.Point(105, 160)
        Me.EachTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.EachTextBox.Name = "EachTextBox"
        Me.EachTextBox.Size = New System.Drawing.Size(599, 21)
        Me.EachTextBox.TabIndex = 7
        '
        '_9_20_9_20TextBox
        '
        Me._9_20_9_20TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "9:20-9:20", True))
        Me._9_20_9_20TextBox.Location = New System.Drawing.Point(105, 130)
        Me._9_20_9_20TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._9_20_9_20TextBox.Name = "_9_20_9_20TextBox"
        Me._9_20_9_20TextBox.Size = New System.Drawing.Size(599, 21)
        Me._9_20_9_20TextBox.TabIndex = 5
        '
        'TeacheTextBox
        '
        Me.TeacheTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Teache", True))
        Me.TeacheTextBox.Location = New System.Drawing.Point(105, 100)
        Me.TeacheTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.TeacheTextBox.Name = "TeacheTextBox"
        Me.TeacheTextBox.Size = New System.Drawing.Size(599, 21)
        Me.TeacheTextBox.TabIndex = 3
        '
        '_8_00_8_40TextBox
        '
        Me._8_00_8_40TextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "8:00-8:40", True))
        Me._8_00_8_40TextBox.Location = New System.Drawing.Point(105, 70)
        Me._8_00_8_40TextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me._8_00_8_40TextBox.Name = "_8_00_8_40TextBox"
        Me._8_00_8_40TextBox.Size = New System.Drawing.Size(599, 21)
        Me._8_00_8_40TextBox.TabIndex = 1
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(DayLabel1)
        Me.GroupBox1.Controls.Add(Me.DayTextBox)
        Me.GroupBox1.Controls.Add(ClassLabel)
        Me.GroupBox1.Controls.Add(Me.ClassTextBox)
        Me.GroupBox1.Controls.Add(_8_00_8_40Label)
        Me.GroupBox1.Controls.Add(Me._8_00_8_40TextBox)
        Me.GroupBox1.Controls.Add(TeacheLabel)
        Me.GroupBox1.Controls.Add(Me.TeacheTextBox)
        Me.GroupBox1.Controls.Add(_9_20_9_20Label)
        Me.GroupBox1.Controls.Add(Me._9_20_9_20TextBox)
        Me.GroupBox1.Controls.Add(EachLabel)
        Me.GroupBox1.Controls.Add(Me.EachTextBox)
        Me.GroupBox1.Controls.Add(BREAKLabel)
        Me.GroupBox1.Controls.Add(Me.BREAKTextBox)
        Me.GroupBox1.Controls.Add(_9_40_10_20Label)
        Me.GroupBox1.Controls.Add(Me._9_40_10_20TextBox)
        Me.GroupBox1.Controls.Add(TecLabel)
        Me.GroupBox1.Controls.Add(Me.TecTextBox)
        Me.GroupBox1.Controls.Add(_10_20_11_00Label)
        Me.GroupBox1.Controls.Add(Me._10_20_11_00TextBox)
        Me.GroupBox1.Controls.Add(TeacherLabel)
        Me.GroupBox1.Controls.Add(Me.TeacherTextBox)
        Me.GroupBox1.Controls.Add(BREARKLabel)
        Me.GroupBox1.Controls.Add(Me.BREARKTextBox)
        Me.GroupBox1.Controls.Add(_11_20_12_00Label)
        Me.GroupBox1.Controls.Add(Me._11_20_12_00TextBox)
        Me.GroupBox1.Controls.Add(TeachLabel)
        Me.GroupBox1.Controls.Add(Me.TeachTextBox)
        Me.GroupBox1.Controls.Add(_12_00_12_40Label)
        Me.GroupBox1.Controls.Add(Me._12_00_12_40TextBox)
        Me.GroupBox1.Controls.Add(TeacLabel)
        Me.GroupBox1.Controls.Add(Me.TeacTextBox)
        Me.GroupBox1.Controls.Add(LUNCHLabel)
        Me.GroupBox1.Controls.Add(Me.LUNCHTextBox)
        Me.GroupBox1.Controls.Add(_2_00_2_40Label)
        Me.GroupBox1.Controls.Add(Me._2_00_2_40TextBox)
        Me.GroupBox1.Controls.Add(TeaLabel)
        Me.GroupBox1.Controls.Add(Me.TeaTextBox)
        Me.GroupBox1.Controls.Add(_2_40_3_20Label)
        Me.GroupBox1.Controls.Add(Me._2_40_3_20TextBox)
        Me.GroupBox1.Controls.Add(TeLabel)
        Me.GroupBox1.Controls.Add(Me.TeTextBox)
        Me.GroupBox1.Controls.Add(_3_20_4_00Label)
        Me.GroupBox1.Controls.Add(Me._3_20_4_00TextBox)
        Me.GroupBox1.Controls.Add(TLabel)
        Me.GroupBox1.Controls.Add(Me.TTextBox)
        Me.GroupBox1.Controls.Add(DayLabel)
        Me.GroupBox1.Location = New System.Drawing.Point(22, 53)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.GroupBox1.Size = New System.Drawing.Size(769, 803)
        Me.GroupBox1.TabIndex = 0
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Input Time table"
        '
        'DayTextBox
        '
        Me.DayTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Day", True))
        Me.DayTextBox.Location = New System.Drawing.Point(104, 43)
        Me.DayTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.DayTextBox.Name = "DayTextBox"
        Me.DayTextBox.Size = New System.Drawing.Size(599, 21)
        Me.DayTextBox.TabIndex = 46
        '
        'ClassTextBox
        '
        Me.ClassTextBox.DataBindings.Add(New System.Windows.Forms.Binding("Text", Me.TimetableBindingSource, "Class", True))
        Me.ClassTextBox.Location = New System.Drawing.Point(105, 17)
        Me.ClassTextBox.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.ClassTextBox.Name = "ClassTextBox"
        Me.ClassTextBox.Size = New System.Drawing.Size(599, 21)
        Me.ClassTextBox.TabIndex = 45
        '
        'TimetableDataGridView
        '
        Me.TimetableDataGridView.AutoGenerateColumns = False
        Me.TimetableDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.TimetableDataGridView.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.DataGridViewTextBoxColumn1, Me.DataGridViewTextBoxColumn2, Me.DataGridViewTextBoxColumn3, Me.DataGridViewTextBoxColumn4, Me.DataGridViewTextBoxColumn5, Me.DataGridViewTextBoxColumn6, Me.DataGridViewTextBoxColumn7, Me.DataGridViewTextBoxColumn8, Me.DataGridViewTextBoxColumn9, Me.DataGridViewTextBoxColumn10, Me.DataGridViewTextBoxColumn11, Me.DataGridViewTextBoxColumn12, Me.DataGridViewTextBoxColumn13, Me.DataGridViewTextBoxColumn14, Me.DataGridViewTextBoxColumn15, Me.DataGridViewTextBoxColumn16, Me.DataGridViewTextBoxColumn17, Me.DataGridViewTextBoxColumn18, Me.DataGridViewTextBoxColumn19, Me.DataGridViewTextBoxColumn20, Me.DataGridViewTextBoxColumn21, Me.DataGridViewTextBoxColumn22, Me.DataGridViewTextBoxColumn23})
        Me.TimetableDataGridView.DataSource = Me.TimetableBindingSource
        Me.TimetableDataGridView.Location = New System.Drawing.Point(798, 312)
        Me.TimetableDataGridView.Name = "TimetableDataGridView"
        Me.TimetableDataGridView.Size = New System.Drawing.Size(192, 220)
        Me.TimetableDataGridView.TabIndex = 2
        Me.TimetableDataGridView.Visible = False
        '
        'DataGridViewTextBoxColumn1
        '
        Me.DataGridViewTextBoxColumn1.DataPropertyName = "8:00-8:40"
        Me.DataGridViewTextBoxColumn1.HeaderText = "8:00-8:40"
        Me.DataGridViewTextBoxColumn1.Name = "DataGridViewTextBoxColumn1"
        '
        'DataGridViewTextBoxColumn2
        '
        Me.DataGridViewTextBoxColumn2.DataPropertyName = "Teache"
        Me.DataGridViewTextBoxColumn2.HeaderText = "Teache"
        Me.DataGridViewTextBoxColumn2.Name = "DataGridViewTextBoxColumn2"
        '
        'DataGridViewTextBoxColumn3
        '
        Me.DataGridViewTextBoxColumn3.DataPropertyName = "9:20-9:20"
        Me.DataGridViewTextBoxColumn3.HeaderText = "9:20-9:20"
        Me.DataGridViewTextBoxColumn3.Name = "DataGridViewTextBoxColumn3"
        '
        'DataGridViewTextBoxColumn4
        '
        Me.DataGridViewTextBoxColumn4.DataPropertyName = "each"
        Me.DataGridViewTextBoxColumn4.HeaderText = "each"
        Me.DataGridViewTextBoxColumn4.Name = "DataGridViewTextBoxColumn4"
        '
        'DataGridViewTextBoxColumn5
        '
        Me.DataGridViewTextBoxColumn5.DataPropertyName = "BREAK"
        Me.DataGridViewTextBoxColumn5.HeaderText = "BREAK"
        Me.DataGridViewTextBoxColumn5.Name = "DataGridViewTextBoxColumn5"
        '
        'DataGridViewTextBoxColumn6
        '
        Me.DataGridViewTextBoxColumn6.DataPropertyName = "9:40-10:20"
        Me.DataGridViewTextBoxColumn6.HeaderText = "9:40-10:20"
        Me.DataGridViewTextBoxColumn6.Name = "DataGridViewTextBoxColumn6"
        '
        'DataGridViewTextBoxColumn7
        '
        Me.DataGridViewTextBoxColumn7.DataPropertyName = "Tec"
        Me.DataGridViewTextBoxColumn7.HeaderText = "Tec"
        Me.DataGridViewTextBoxColumn7.Name = "DataGridViewTextBoxColumn7"
        '
        'DataGridViewTextBoxColumn8
        '
        Me.DataGridViewTextBoxColumn8.DataPropertyName = "10:20-11:00"
        Me.DataGridViewTextBoxColumn8.HeaderText = "10:20-11:00"
        Me.DataGridViewTextBoxColumn8.Name = "DataGridViewTextBoxColumn8"
        '
        'DataGridViewTextBoxColumn9
        '
        Me.DataGridViewTextBoxColumn9.DataPropertyName = "Teacher"
        Me.DataGridViewTextBoxColumn9.HeaderText = "Teacher"
        Me.DataGridViewTextBoxColumn9.Name = "DataGridViewTextBoxColumn9"
        '
        'DataGridViewTextBoxColumn10
        '
        Me.DataGridViewTextBoxColumn10.DataPropertyName = "BREARK"
        Me.DataGridViewTextBoxColumn10.HeaderText = "BREARK"
        Me.DataGridViewTextBoxColumn10.Name = "DataGridViewTextBoxColumn10"
        '
        'DataGridViewTextBoxColumn11
        '
        Me.DataGridViewTextBoxColumn11.DataPropertyName = "11:20-12:00"
        Me.DataGridViewTextBoxColumn11.HeaderText = "11:20-12:00"
        Me.DataGridViewTextBoxColumn11.Name = "DataGridViewTextBoxColumn11"
        '
        'DataGridViewTextBoxColumn12
        '
        Me.DataGridViewTextBoxColumn12.DataPropertyName = "Teach"
        Me.DataGridViewTextBoxColumn12.HeaderText = "Teach"
        Me.DataGridViewTextBoxColumn12.Name = "DataGridViewTextBoxColumn12"
        '
        'DataGridViewTextBoxColumn13
        '
        Me.DataGridViewTextBoxColumn13.DataPropertyName = "12:00-12:40"
        Me.DataGridViewTextBoxColumn13.HeaderText = "12:00-12:40"
        Me.DataGridViewTextBoxColumn13.Name = "DataGridViewTextBoxColumn13"
        '
        'DataGridViewTextBoxColumn14
        '
        Me.DataGridViewTextBoxColumn14.DataPropertyName = "Teac"
        Me.DataGridViewTextBoxColumn14.HeaderText = "Teac"
        Me.DataGridViewTextBoxColumn14.Name = "DataGridViewTextBoxColumn14"
        '
        'DataGridViewTextBoxColumn15
        '
        Me.DataGridViewTextBoxColumn15.DataPropertyName = "LUNCH"
        Me.DataGridViewTextBoxColumn15.HeaderText = "LUNCH"
        Me.DataGridViewTextBoxColumn15.Name = "DataGridViewTextBoxColumn15"
        '
        'DataGridViewTextBoxColumn16
        '
        Me.DataGridViewTextBoxColumn16.DataPropertyName = "2:00-2:40"
        Me.DataGridViewTextBoxColumn16.HeaderText = "2:00-2:40"
        Me.DataGridViewTextBoxColumn16.Name = "DataGridViewTextBoxColumn16"
        '
        'DataGridViewTextBoxColumn17
        '
        Me.DataGridViewTextBoxColumn17.DataPropertyName = "Tea"
        Me.DataGridViewTextBoxColumn17.HeaderText = "Tea"
        Me.DataGridViewTextBoxColumn17.Name = "DataGridViewTextBoxColumn17"
        '
        'DataGridViewTextBoxColumn18
        '
        Me.DataGridViewTextBoxColumn18.DataPropertyName = "2:40-3:20"
        Me.DataGridViewTextBoxColumn18.HeaderText = "2:40-3:20"
        Me.DataGridViewTextBoxColumn18.Name = "DataGridViewTextBoxColumn18"
        '
        'DataGridViewTextBoxColumn19
        '
        Me.DataGridViewTextBoxColumn19.DataPropertyName = "Te"
        Me.DataGridViewTextBoxColumn19.HeaderText = "Te"
        Me.DataGridViewTextBoxColumn19.Name = "DataGridViewTextBoxColumn19"
        '
        'DataGridViewTextBoxColumn20
        '
        Me.DataGridViewTextBoxColumn20.DataPropertyName = "3:20-4:00"
        Me.DataGridViewTextBoxColumn20.HeaderText = "3:20-4:00"
        Me.DataGridViewTextBoxColumn20.Name = "DataGridViewTextBoxColumn20"
        '
        'DataGridViewTextBoxColumn21
        '
        Me.DataGridViewTextBoxColumn21.DataPropertyName = "T"
        Me.DataGridViewTextBoxColumn21.HeaderText = "T"
        Me.DataGridViewTextBoxColumn21.Name = "DataGridViewTextBoxColumn21"
        '
        'DataGridViewTextBoxColumn22
        '
        Me.DataGridViewTextBoxColumn22.DataPropertyName = "Class"
        Me.DataGridViewTextBoxColumn22.HeaderText = "Class"
        Me.DataGridViewTextBoxColumn22.Name = "DataGridViewTextBoxColumn22"
        '
        'DataGridViewTextBoxColumn23
        '
        Me.DataGridViewTextBoxColumn23.DataPropertyName = "Day"
        Me.DataGridViewTextBoxColumn23.HeaderText = "Day"
        Me.DataGridViewTextBoxColumn23.Name = "DataGridViewTextBoxColumn23"
        '
        '_ClassToolStrip
        '
        Me._ClassToolStrip.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me._LIKEToolStripLabel, Me._LIKEToolStripTextBox, Me._ClassToolStripButton})
        Me._ClassToolStrip.Location = New System.Drawing.Point(0, 25)
        Me._ClassToolStrip.Name = "_ClassToolStrip"
        Me._ClassToolStrip.Size = New System.Drawing.Size(1011, 25)
        Me._ClassToolStrip.TabIndex = 2
        Me._ClassToolStrip.Text = "_ClassToolStrip"
        '
        '_LIKEToolStripLabel
        '
        Me._LIKEToolStripLabel.Name = "_LIKEToolStripLabel"
        Me._LIKEToolStripLabel.Size = New System.Drawing.Size(116, 22)
        Me._LIKEToolStripLabel.Text = "ENTER CLASS NAME"
        '
        '_LIKEToolStripTextBox
        '
        Me._LIKEToolStripTextBox.Name = "_LIKEToolStripTextBox"
        Me._LIKEToolStripTextBox.Size = New System.Drawing.Size(100, 25)
        '
        '_ClassToolStripButton
        '
        Me._ClassToolStripButton.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Text
        Me._ClassToolStripButton.Name = "_ClassToolStripButton"
        Me._ClassToolStripButton.Size = New System.Drawing.Size(55, 22)
        Me._ClassToolStripButton.Text = "SEARCH"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(840, 96)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(93, 23)
        Me.Button1.TabIndex = 3
        Me.Button1.Text = "ADD NEW"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Location = New System.Drawing.Point(840, 127)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(93, 23)
        Me.Button2.TabIndex = 4
        Me.Button2.Text = "SAVE"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'FRMTIMETABLE
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(8.0!, 15.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.AutoScroll = True
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(1028, 750)
        Me.Controls.Add(Me.Button2)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.TimetableDataGridView)
        Me.Controls.Add(Me._ClassToolStrip)
        Me.Controls.Add(Me.TimetableBindingNavigator)
        Me.Controls.Add(Me.GroupBox1)
        Me.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ForeColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer))
        Me.Margin = New System.Windows.Forms.Padding(4, 3, 4, 3)
        Me.Name = "FRMTIMETABLE"
        Me.Text = "FRMTIMETABLE"
        CType(Me.Database1DataSet, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TimetableBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TimetableBindingNavigator, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TimetableBindingNavigator.ResumeLayout(False)
        Me.TimetableBindingNavigator.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.TimetableDataGridView, System.ComponentModel.ISupportInitialize).EndInit()
        Me._ClassToolStrip.ResumeLayout(False)
        Me._ClassToolStrip.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Database1DataSet As SCHOOLMANAGEMENTSYSTEM.Database1DataSet
    Friend WithEvents TimetableBindingSource As System.Windows.Forms.BindingSource
    Friend WithEvents TimetableTableAdapter As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.timetableTableAdapter
    Friend WithEvents TableAdapterManager As SCHOOLMANAGEMENTSYSTEM.Database1DataSetTableAdapters.TableAdapterManager
    Friend WithEvents TimetableBindingNavigator As System.Windows.Forms.BindingNavigator
    Friend WithEvents BindingNavigatorAddNewItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorCountItem As System.Windows.Forms.ToolStripLabel
    Friend WithEvents BindingNavigatorDeleteItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveFirstItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMovePreviousItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorPositionItem As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents BindingNavigatorSeparator1 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents BindingNavigatorMoveNextItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorMoveLastItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents BindingNavigatorSeparator2 As System.Windows.Forms.ToolStripSeparator
    Friend WithEvents TimetableBindingNavigatorSaveItem As System.Windows.Forms.ToolStripButton
    Friend WithEvents TTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _3_20_4_00TextBox As System.Windows.Forms.TextBox
    Friend WithEvents TeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _2_40_3_20TextBox As System.Windows.Forms.TextBox
    Friend WithEvents TeaTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _2_00_2_40TextBox As System.Windows.Forms.TextBox
    Friend WithEvents LUNCHTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TeacTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _12_00_12_40TextBox As System.Windows.Forms.TextBox
    Friend WithEvents TeachTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _11_20_12_00TextBox As System.Windows.Forms.TextBox
    Friend WithEvents BREARKTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TeacherTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _10_20_11_00TextBox As System.Windows.Forms.TextBox
    Friend WithEvents TecTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _9_40_10_20TextBox As System.Windows.Forms.TextBox
    Friend WithEvents BREAKTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EachTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _9_20_9_20TextBox As System.Windows.Forms.TextBox
    Friend WithEvents TeacheTextBox As System.Windows.Forms.TextBox
    Friend WithEvents _8_00_8_40TextBox As System.Windows.Forms.TextBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents DayTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ClassTextBox As System.Windows.Forms.TextBox
    Friend WithEvents TimetableDataGridView As System.Windows.Forms.DataGridView
    Friend WithEvents DataGridViewTextBoxColumn1 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn2 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn3 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn4 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn5 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn6 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn7 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn8 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn9 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn10 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn11 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn12 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn13 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn14 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn15 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn16 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn17 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn18 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn19 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn20 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn21 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn22 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents DataGridViewTextBoxColumn23 As System.Windows.Forms.DataGridViewTextBoxColumn
    Friend WithEvents _ClassToolStrip As System.Windows.Forms.ToolStrip
    Friend WithEvents _LIKEToolStripLabel As System.Windows.Forms.ToolStripLabel
    Friend WithEvents _LIKEToolStripTextBox As System.Windows.Forms.ToolStripTextBox
    Friend WithEvents _ClassToolStripButton As System.Windows.Forms.ToolStripButton
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
End Class
