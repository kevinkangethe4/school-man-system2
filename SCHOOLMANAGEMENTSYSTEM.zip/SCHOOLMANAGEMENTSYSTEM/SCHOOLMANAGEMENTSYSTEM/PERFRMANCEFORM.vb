﻿Imports System.Drawing.Printing
Imports System.Drawing.Graphics
Imports System.Drawing
Imports System.Windows.Forms
Imports System
Imports System.Collections.Generic
Imports System.Data
Imports System.Linq
Imports System.Text

Public Class PERFRMANCEFORM
    Private bmp As Bitmap
    Private Sub PERFORMANCEBindingNavigatorSaveItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PERFORMANCEBindingNavigatorSaveItem.Click
        Me.Validate()
        Me.PERFORMANCEBindingSource.EndEdit()
        Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)

    End Sub

    Private Sub PERFRMANCEFORM_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'TODO: This line of code loads data into the 'Database1DataSet.REGISTATION' table. You can move, or remove it, as needed.
        Me.REGISTATIONTableAdapter.Fill(Me.Database1DataSet.REGISTATION)
        'TODO: This line of code loads data into the 'Database1DataSet.PERFORMANCE' table. You can move, or remove it, as needed.
        Me.PERFORMANCETableAdapter.Fill(Me.Database1DataSet.PERFORMANCE)
        EXAMREFNOTextBox.Text = ""
        STUDENTNUMBERTextBox.Text = ""
        SEGRADETextBox.Text = ""
        TERMTextBox.Text = ""
        ENGLISHTextBox.Text = ""
        MATHSTextBox.Text = ""
        KISWAHILITextBox.Text = ""
        BIOLOGYTextBox.Text = ""
        CHEMISTRYTextBox.Text = ""
        PHYSICSTextBox.Text = ""
        COMPSTUDIESTextBox.Text = ""
        BUSINESSSTUDIESTextBox.Text = ""
        HISTORYTextBox.Text = ""
        GEOGRAPHYTextBox.Text = ""
        CRETextBox.Text = ""
        AGRICULTURETextBox.Text = ""
        HOMESCIENCTextBox.Text = ""
        'SOCIALEDTextBox.Text = ""
        SOCIALETHICSTextBox.Text = ""
        TOTALGRADETextBox.Text = ""
        ENGGRADETextBox.Text = ""
        MATHSGRADETextBox.Text = ""
        KISWAGRADETextBox.Text = ""
        BIOGRADETextBox.Text = ""
        CHEMGRADETextBox.Text = ""
        PHYSICSGRADETextBox.Text = ""
        BGRADETextBox.Text = ""
        CGRADETextBox.Text = ""
        GEOGRADETextBox.Text = ""
        GRADEHISTextBox.Text = ""
        ' SGRADETextBox.Text = ""
        H_SGRADETextBox.Text = ""
        AGRIGRADETextBox.Text = ""
        CREGRADETextBox.Text = ""



    End Sub

    Private Sub GroupBox2_Enter(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub SEGRADELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub ENGGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub ENGGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        

    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
       


    End Sub

    Private Sub SEGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub SOCIALETHICSTextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub SOCIALETHICSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub MATHSGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

        
    End Sub

    Private Sub MATHSGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub KISWAGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub KISWAGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BIOGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub BIOGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CHEMGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       


    End Sub

    Private Sub CHEMGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PHYSICSGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        



    End Sub

    Private Sub PHYSICSGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       


    End Sub

    Private Sub BGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       

    End Sub

    Private Sub CGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AGRIGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub AGRIGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GRADEHISTextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        

    End Sub

    Private Sub GRADEHISTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CREGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub CREGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GEOGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       

    End Sub

    Private Sub GEOGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
       

    End Sub

    Private Sub PrintDocument1_PrintPage(ByVal sender As System.Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintDocument1.PrintPage
        Dim x As Single = e.MarginBounds.Left
        Dim y As Single = e.MarginBounds.Top
        Dim bmp As New Bitmap(Me.GroupBox2.Width, Me.GroupBox2.Height)
        Me.GroupBox2.DrawToBitmap(bmp, New Rectangle(0, 0, Me.GroupBox2.Width, Me.GroupBox2.Height))
        e.Graphics.DrawImage(DirectCast(bmp, Image), x, y)
    End Sub

    Private Sub Button2_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Try
            Me.Validate()
            Me.PERFORMANCEBindingSource.EndEdit()
            Me.TableAdapterManager.UpdateAll(Me.Database1DataSet)
            MsgBox("SAVED")
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button3_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dim doc As New PrintDocument()
        AddHandler doc.PrintPage, AddressOf Me.PrintDocument1_PrintPage
        Dim dlgs As New PrintDialog()
        dlgs.Document = doc
        If dlgs.ShowDialog() = DialogResult.OK Then
            doc.Print()
        End If
    End Sub

    Private Sub Button1_Click_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Try
            Me.PERFORMANCEBindingSource.AddNew()
            MsgBox("ADD RECORD")

        Catch ex As Exception

        End Try
    End Sub

    Private Sub ENGGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
        






    End Sub

    Private Sub ENGGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub MATHSGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
        
    End Sub

    Private Sub MATHSGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub KISWAGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       

    End Sub

    Private Sub KISWAGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BIOGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub BIOGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CHEMGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub CHEMGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub PHYSICSGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub PHYSICSGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub BGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub BGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       

    End Sub

    Private Sub CGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AGRIGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub AGRIGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GRADEHISTextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
      
    End Sub

    Private Sub GRADEHISTextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub CREGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
      
    End Sub

    Private Sub CREGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GEOGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub GEOGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub SOCIALETHICSTextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub SOCIALETHICSTextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub GroupBox2_Enter_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub SGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       

    End Sub

    Private Sub SGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub H_SGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       


    End Sub

    Private Sub H_SGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub POINTSTextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
        ' POINTSTextBox.Text = SOCIALETHICSTextBox.Text / 1400 * 100
    End Sub

    Private Sub POINTSTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TOTALGRADETextBox_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)


       



    End Sub

    Private Sub TOTALGRADETextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub STUDENTNUMBER3ToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)


    End Sub

    Private Sub PrintPreviewDialog1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PrintPreviewDialog1.Load

    End Sub

    Private Sub POINTSLabel2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub SearchToolStripButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchToolStripButton.Click
        Try
            Me.REGISTATIONTableAdapter.Search(Me.Database1DataSet.REGISTATION, _LIKEToolStripTextBox.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub POINTSTextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub POINTSTextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub AGRICULTURELabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub KCPERESULTLabel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox40_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox40_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox41_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub TextBox41_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox42_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox41_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)
       



    End Sub

    Private Sub TextBox41_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox40_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox40_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox3_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)
       
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox4_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox7_GotFocus(ByVal sender As Object, ByVal e As System.EventArgs)

    End Sub

    Private Sub TextBox7_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub

    
    Private Sub SearchToolStripButton1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SearchToolStripButton1.Click
        Try
            Me.PERFORMANCETableAdapter.Search(Me.Database1DataSet.PERFORMANCE, _LIKEToolStripTextBox1.Text)
        Catch ex As System.Exception
            System.Windows.Forms.MessageBox.Show(ex.Message)
        End Try

    End Sub

    Private Sub _LIKEToolStripLabel1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles _LIKEToolStripLabel1.Click

    End Sub

    Private Sub EXAMREFNOTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EXAMREFNOTextBox.TextChanged

    End Sub

    Private Sub ENGLISHTextBox_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ENGLISHTextBox.TextChanged

    End Sub

    Private Sub ENGGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles ENGGRADETextBox.GotFocus
        If ENGLISHTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf ENGLISHTextBox.Text >= 85 Then
            ENGGRADETextBox.Text = "A"
        ElseIf ENGLISHTextBox.Text >= "79" Then
            ENGGRADETextBox.Text = "A-"
        ElseIf ENGLISHTextBox.Text >= 68 Then
            ENGGRADETextBox.Text = "B+"
        ElseIf ENGLISHTextBox.Text >= 62 Then
            ENGGRADETextBox.Text = "BPLAIN"
        ElseIf ENGLISHTextBox.Text >= 57 Then
            ENGGRADETextBox.Text = "B-"

        ElseIf ENGLISHTextBox.Text >= 50 Then
            ENGGRADETextBox.Text = "C+"
        ElseIf ENGLISHTextBox.Text >= 45 Then
            ENGGRADETextBox.Text = "CPLAIN"
        ElseIf ENGLISHTextBox.Text >= 40 Then
            ENGGRADETextBox.Text = "C-"
        ElseIf ENGLISHTextBox.Text >= 35 Then
            ENGGRADETextBox.Text = "D+"

        ElseIf ENGLISHTextBox.Text >= 27 Then
            ENGGRADETextBox.Text = "D PLAIN"
        ElseIf ENGLISHTextBox.Text >= 20 Then
            ENGGRADETextBox.Text = "D-"

        ElseIf ENGLISHTextBox.Text < 20 Then
            ENGGRADETextBox.Text = "E"
        End If

        If ENGLISHTextBox.Text > 50 And ComboBox1.Text = "cat1" Then
            ENGGRADETextBox.Text = "Not Applicable"
        ElseIf ENGLISHTextBox.Text >= 43 And ComboBox1.Text = "cat1" Then
            ENGGRADETextBox.Text = "A"
            '  ElseIf ENGLISHTextBox.
        End If
    End Sub

    Private Sub ENGGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ENGGRADETextBox.TextChanged
       
    End Sub

    Private Sub MATHSGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles MATHSGRADETextBox.GotFocus
        If MATHSTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf MATHSTextBox.Text >= 85 Then
            MATHSGRADETextBox.Text = "A"
        ElseIf MATHSTextBox.Text >= "75" Then
            MATHSGRADETextBox.Text = "A-"
        ElseIf MATHSTextBox.Text >= 68 Then
            MATHSGRADETextBox.Text = "B+"
        ElseIf MATHSTextBox.Text >= 62 Then
            MATHSGRADETextBox.Text = "BPLAIN"
        ElseIf MATHSTextBox.Text >= 57 Then
            MATHSGRADETextBox.Text = "B-"

        ElseIf MATHSTextBox.Text >= 50 Then
            MATHSGRADETextBox.Text = "C+"
        ElseIf MATHSTextBox.Text >= 45 Then
            MATHSGRADETextBox.Text = "CPLAIN"
        ElseIf MATHSTextBox.Text >= 40 Then
            MATHSGRADETextBox.Text = "C-"
        ElseIf MATHSTextBox.Text >= 35 Then
            MATHSGRADETextBox.Text = "D+"

        ElseIf MATHSTextBox.Text >= 27 Then
            MATHSGRADETextBox.Text = "D PLAIN"
        ElseIf MATHSTextBox.Text >= 20 Then
            MATHSGRADETextBox.Text = "D-"

        ElseIf MATHSTextBox.Text < 20 Then
            MATHSGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub MATHSGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MATHSGRADETextBox.TextChanged

    End Sub

    Private Sub KISWAGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles KISWAGRADETextBox.GotFocus
        If KISWAHILITextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf KISWAHILITextBox.Text >= 85 Then
            KISWAGRADETextBox.Text = "A"
        ElseIf KISWAHILITextBox.Text >= "75" Then
            KISWAGRADETextBox.Text = "A-"
        ElseIf KISWAHILITextBox.Text >= 68 Then
            KISWAGRADETextBox.Text = "B+"
        ElseIf KISWAHILITextBox.Text >= 62 Then
            KISWAGRADETextBox.Text = "BPLAIN"
        ElseIf KISWAHILITextBox.Text >= 57 Then
            KISWAGRADETextBox.Text = "B-"

        ElseIf KISWAHILITextBox.Text >= 50 Then
            KISWAGRADETextBox.Text = "C+"
        ElseIf KISWAHILITextBox.Text >= 45 Then
            KISWAGRADETextBox.Text = "CPLAIN"
        ElseIf KISWAHILITextBox.Text >= 40 Then
            KISWAGRADETextBox.Text = "C-"
        ElseIf KISWAHILITextBox.Text >= 35 Then
            KISWAGRADETextBox.Text = "D+"

        ElseIf KISWAHILITextBox.Text >= 27 Then
            KISWAGRADETextBox.Text = "D PLAIN"
        ElseIf KISWAHILITextBox.Text >= 20 Then
            KISWAGRADETextBox.Text = "D-"

        ElseIf KISWAHILITextBox.Text < 20 Then
            KISWAGRADETextBox.Text = "E"
        End If

    End Sub

    Private Sub KISWAGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles KISWAGRADETextBox.TextChanged

    End Sub

    Private Sub BIOGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles BIOGRADETextBox.GotFocus
        If BIOLOGYTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf BIOLOGYTextBox.Text >= 85 Then
            BIOGRADETextBox.Text = "A"
        ElseIf BIOLOGYTextBox.Text >= "79" Then
            BIOGRADETextBox.Text = "A-"
        ElseIf BIOLOGYTextBox.Text >= 68 Then
            BIOGRADETextBox.Text = "B+"
        ElseIf BIOLOGYTextBox.Text >= 62 Then
            BIOGRADETextBox.Text = "BPLAIN"
        ElseIf BIOLOGYTextBox.Text >= 57 Then
            BIOGRADETextBox.Text = "B-"

        ElseIf BIOLOGYTextBox.Text >= 50 Then
            BIOGRADETextBox.Text = "C+"
        ElseIf BIOLOGYTextBox.Text >= 45 Then
            BIOGRADETextBox.Text = "CPLAIN"
        ElseIf BIOLOGYTextBox.Text >= 40 Then
            BIOGRADETextBox.Text = "C-"
        ElseIf BIOLOGYTextBox.Text >= 35 Then
            BIOGRADETextBox.Text = "D+"

        ElseIf BIOLOGYTextBox.Text >= 27 Then
            BIOGRADETextBox.Text = "D PLAIN"
        ElseIf BIOLOGYTextBox.Text >= 20 Then
            BIOGRADETextBox.Text = "D-"

        ElseIf BIOLOGYTextBox.Text < 20 Then
            BIOGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub BIOGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BIOGRADETextBox.TextChanged

    End Sub

    Private Sub CHEMGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles CHEMGRADETextBox.GotFocus
        If CHEMISTRYTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf CHEMISTRYTextBox.Text >= 85 Then
            CHEMGRADETextBox.Text = "A"
        ElseIf CHEMISTRYTextBox.Text >= "79" Then
            CHEMGRADETextBox.Text = "A-"
        ElseIf CHEMISTRYTextBox.Text >= 68 Then
            CHEMGRADETextBox.Text = "B+"
        ElseIf CHEMISTRYTextBox.Text >= 62 Then
            CHEMGRADETextBox.Text = "BPLAIN"
        ElseIf CHEMISTRYTextBox.Text >= 57 Then
            CHEMGRADETextBox.Text = "B-"

        ElseIf CHEMISTRYTextBox.Text >= 50 Then
            CHEMGRADETextBox.Text = "C+"
        ElseIf CHEMISTRYTextBox.Text >= 45 Then
            CHEMGRADETextBox.Text = "CPLAIN"
        ElseIf CHEMISTRYTextBox.Text >= 40 Then
            CHEMGRADETextBox.Text = "C-"
        ElseIf CHEMISTRYTextBox.Text >= 35 Then
            CHEMGRADETextBox.Text = "D+"

        ElseIf CHEMISTRYTextBox.Text >= 27 Then
            CHEMGRADETextBox.Text = "D PLAIN"
        ElseIf CHEMISTRYTextBox.Text >= 20 Then
            CHEMGRADETextBox.Text = "D-"

        ElseIf CHEMISTRYTextBox.Text < 20 Then
            CHEMGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub CHEMGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CHEMGRADETextBox.TextChanged

    End Sub

    Private Sub BGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles BGRADETextBox.GotFocus
        If BUSINESSSTUDIESTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf BUSINESSSTUDIESTextBox.Text >= 85 Then
            BGRADETextBox.Text = "A"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 79 Then
            BGRADETextBox.Text = "A-"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 68 Then
            BGRADETextBox.Text = "B+"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 62 Then
            BGRADETextBox.Text = "BPLAIN"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 57 Then
            BGRADETextBox.Text = "B-"

        ElseIf BUSINESSSTUDIESTextBox.Text >= 50 Then
            BGRADETextBox.Text = "C+"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 45 Then
            BGRADETextBox.Text = "CPLAIN"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 40 Then
            BGRADETextBox.Text = "C-"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 35 Then
            BGRADETextBox.Text = "D+"

        ElseIf BUSINESSSTUDIESTextBox.Text >= 27 Then
            BGRADETextBox.Text = "D PLAIN"
        ElseIf BUSINESSSTUDIESTextBox.Text >= 20 Then
            BGRADETextBox.Text = "D-"

        ElseIf BUSINESSSTUDIESTextBox.Text < 20 Then
            BGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub BGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BGRADETextBox.TextChanged

    End Sub

    Private Sub PHYSICSGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles PHYSICSGRADETextBox.GotFocus
        If PHYSICSTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf PHYSICSTextBox.Text >= 85 Then
            PHYSICSGRADETextBox.Text = "A"
        ElseIf PHYSICSTextBox.Text >= "79" Then
            PHYSICSGRADETextBox.Text = "A-"
        ElseIf PHYSICSTextBox.Text >= 68 Then
            PHYSICSGRADETextBox.Text = "B+"
        ElseIf PHYSICSTextBox.Text >= 62 Then
            PHYSICSGRADETextBox.Text = "BPLAIN"
        ElseIf PHYSICSTextBox.Text >= 57 Then
            PHYSICSGRADETextBox.Text = "B-"

        ElseIf PHYSICSTextBox.Text >= 50 Then
            PHYSICSGRADETextBox.Text = "C+"
        ElseIf PHYSICSTextBox.Text >= 45 Then
            PHYSICSGRADETextBox.Text = "CPLAIN"
        ElseIf PHYSICSTextBox.Text >= 40 Then
            PHYSICSGRADETextBox.Text = "C-"
        ElseIf PHYSICSTextBox.Text >= 35 Then
            PHYSICSGRADETextBox.Text = "D+"

        ElseIf PHYSICSTextBox.Text >= 27 Then
            PHYSICSGRADETextBox.Text = "D PLAIN"
        ElseIf PHYSICSTextBox.Text >= 20 Then
            PHYSICSGRADETextBox.Text = "D-"

        ElseIf PHYSICSTextBox.Text < 20 Then
            PHYSICSGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub PHYSICSGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PHYSICSGRADETextBox.TextChanged

    End Sub

    Private Sub CGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles CGRADETextBox.GotFocus
        If COMPSTUDIESTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf COMPSTUDIESTextBox.Text >= 85 Then
            CGRADETextBox.Text = "A"
        ElseIf COMPSTUDIESTextBox.Text >= 79 Then
            CGRADETextBox.Text = "A-"
        ElseIf COMPSTUDIESTextBox.Text >= 68 Then
            CGRADETextBox.Text = "B+"
        ElseIf COMPSTUDIESTextBox.Text >= 62 Then
            CGRADETextBox.Text = "BPLAIN"
        ElseIf COMPSTUDIESTextBox.Text >= 57 Then
            CGRADETextBox.Text = "B-"

        ElseIf COMPSTUDIESTextBox.Text >= 50 Then
            CGRADETextBox.Text = "C+"
        ElseIf COMPSTUDIESTextBox.Text >= 45 Then
            CGRADETextBox.Text = "CPLAIN"
        ElseIf COMPSTUDIESTextBox.Text >= 40 Then
            CGRADETextBox.Text = "C-"
        ElseIf COMPSTUDIESTextBox.Text >= 35 Then
            CGRADETextBox.Text = "D+"

        ElseIf COMPSTUDIESTextBox.Text >= 27 Then
            CGRADETextBox.Text = "D PLAIN"
        ElseIf COMPSTUDIESTextBox.Text >= 20 Then
            CGRADETextBox.Text = "D-"

        ElseIf COMPSTUDIESTextBox.Text < 20 Then
            CGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub CGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CGRADETextBox.TextChanged

    End Sub

    Private Sub GRADEHISTextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles GRADEHISTextBox.GotFocus
        If HISTORYTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf HISTORYTextBox.Text >= 85 Then
            GRADEHISTextBox.Text = "A"
        ElseIf HISTORYTextBox.Text >= 79 Then
            GRADEHISTextBox.Text = "A-"
        ElseIf HISTORYTextBox.Text >= 68 Then
            GRADEHISTextBox.Text = "B+"
        ElseIf HISTORYTextBox.Text >= 62 Then
            GRADEHISTextBox.Text = "BPLAIN"
        ElseIf HISTORYTextBox.Text >= 57 Then
            GRADEHISTextBox.Text = "B-"

        ElseIf HISTORYTextBox.Text >= 50 Then
            GRADEHISTextBox.Text = "C+"
        ElseIf HISTORYTextBox.Text >= 45 Then
            GRADEHISTextBox.Text = "CPLAIN"
        ElseIf HISTORYTextBox.Text >= 40 Then
            GRADEHISTextBox.Text = "C-"
        ElseIf HISTORYTextBox.Text >= 35 Then
            GRADEHISTextBox.Text = "D+"

        ElseIf HISTORYTextBox.Text >= 27 Then
            GRADEHISTextBox.Text = "D PLAIN"
        ElseIf HISTORYTextBox.Text >= 20 Then
            GRADEHISTextBox.Text = "D-"

        ElseIf HISTORYTextBox.Text < 20 Then
            GRADEHISTextBox.Text = "E"
        End If
    End Sub

    Private Sub GRADEHISTextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GRADEHISTextBox.TextChanged

    End Sub

    Private Sub AGRIGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles AGRIGRADETextBox.GotFocus
        If AGRICULTURETextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf AGRICULTURETextBox.Text >= 85 Then
            AGRIGRADETextBox.Text = "A"
        ElseIf AGRICULTURETextBox.Text >= 79 Then
            AGRIGRADETextBox.Text = "A-"
        ElseIf AGRICULTURETextBox.Text >= 68 Then
            AGRIGRADETextBox.Text = "B+"
        ElseIf AGRICULTURETextBox.Text >= 62 Then
            AGRIGRADETextBox.Text = "BPLAIN"
        ElseIf AGRICULTURETextBox.Text >= 57 Then
            AGRIGRADETextBox.Text = "B-"

        ElseIf AGRICULTURETextBox.Text >= 50 Then
            AGRIGRADETextBox.Text = "C+"
        ElseIf AGRICULTURETextBox.Text >= 45 Then
            AGRIGRADETextBox.Text = "CPLAIN"
        ElseIf AGRICULTURETextBox.Text >= 40 Then
            AGRIGRADETextBox.Text = "C-"
        ElseIf AGRICULTURETextBox.Text >= 35 Then
            AGRIGRADETextBox.Text = "D+"

        ElseIf AGRICULTURETextBox.Text >= 27 Then
            AGRIGRADETextBox.Text = "D PLAIN"
        ElseIf AGRICULTURETextBox.Text >= 20 Then
            AGRIGRADETextBox.Text = "D-"

        ElseIf AGRICULTURETextBox.Text < 20 Then
            AGRIGRADETextBox.Text = "E"

        End If
    End Sub

    Private Sub AGRIGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AGRIGRADETextBox.TextChanged

    End Sub

    Private Sub CREGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles CREGRADETextBox.GotFocus
        If CRETextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf CRETextBox.Text >= 85 Then
            CREGRADETextBox.Text = "A"
        ElseIf CRETextBox.Text >= 79 Then
            CREGRADETextBox.Text = "A-"
        ElseIf CRETextBox.Text >= 68 Then
            CREGRADETextBox.Text = "B+"
        ElseIf CRETextBox.Text >= 62 Then
            CREGRADETextBox.Text = "BPLAIN"
        ElseIf CRETextBox.Text >= 57 Then
            CREGRADETextBox.Text = "B-"

        ElseIf CRETextBox.Text >= 50 Then
            CREGRADETextBox.Text = "C+"
        ElseIf CRETextBox.Text >= 45 Then
            CREGRADETextBox.Text = "CPLAIN"
        ElseIf CRETextBox.Text >= 40 Then
            CREGRADETextBox.Text = "C-"
        ElseIf CRETextBox.Text >= 35 Then
            CREGRADETextBox.Text = "D+"

        ElseIf CRETextBox.Text >= 27 Then
            CREGRADETextBox.Text = "D PLAIN"
        ElseIf CRETextBox.Text >= 20 Then
            CREGRADETextBox.Text = "D-"

        ElseIf CRETextBox.Text < 20 Then
            CREGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub CREGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CREGRADETextBox.TextChanged

    End Sub

    Private Sub GEOGRADETextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles GEOGRADETextBox.GotFocus
        If GEOGRAPHYTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf GEOGRAPHYTextBox.Text >= 85 Then
            GEOGRADETextBox.Text = "A"
        ElseIf GEOGRAPHYTextBox.Text >= 79 Then
            GEOGRADETextBox.Text = "A-"
        ElseIf GEOGRAPHYTextBox.Text >= 68 Then
            GEOGRADETextBox.Text = "B+"
        ElseIf GEOGRAPHYTextBox.Text >= 62 Then
            GEOGRADETextBox.Text = "BPLAIN"
        ElseIf GEOGRAPHYTextBox.Text >= 57 Then
            GEOGRADETextBox.Text = "B-"

        ElseIf GEOGRAPHYTextBox.Text >= 50 Then
            GEOGRADETextBox.Text = "C+"
        ElseIf GEOGRAPHYTextBox.Text >= 45 Then
            GEOGRADETextBox.Text = "CPLAIN"
        ElseIf GEOGRAPHYTextBox.Text >= 40 Then
            GEOGRADETextBox.Text = "C-"
        ElseIf GEOGRAPHYTextBox.Text >= 35 Then
            GEOGRADETextBox.Text = "D+"

        ElseIf GEOGRAPHYTextBox.Text >= 27 Then
            GEOGRADETextBox.Text = "D PLAIN"
        ElseIf GEOGRAPHYTextBox.Text >= 20 Then
            GEOGRADETextBox.Text = "D-"

        ElseIf GEOGRAPHYTextBox.Text < 20 Then
            GEOGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub GEOGRADETextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GEOGRADETextBox.TextChanged

    End Sub

    Private Sub H_SGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs) Handles H_SGRADETextBox.GotFocus
        If HOMESCIENCTextBox.Text > 100 Then
            MsgBox("not applicable")
        ElseIf HOMESCIENCTextBox.Text >= 85 Then
            H_SGRADETextBox.Text = "A"
        ElseIf HOMESCIENCTextBox.Text >= 79 Then
            H_SGRADETextBox.Text = "A-"
        ElseIf HOMESCIENCTextBox.Text >= 68 Then
            H_SGRADETextBox.Text = "B+"
        ElseIf HOMESCIENCTextBox.Text >= 62 Then
            H_SGRADETextBox.Text = "BPLAIN"
        ElseIf HOMESCIENCTextBox.Text >= 57 Then
            H_SGRADETextBox.Text = "B-"

        ElseIf HOMESCIENCTextBox.Text >= 50 Then
            H_SGRADETextBox.Text = "C+"
        ElseIf HOMESCIENCTextBox.Text >= 45 Then
            H_SGRADETextBox.Text = "CPLAIN"
        ElseIf HOMESCIENCTextBox.Text >= 40 Then
            H_SGRADETextBox.Text = "C-"
        ElseIf HOMESCIENCTextBox.Text >= 35 Then
            H_SGRADETextBox.Text = "D+"

        ElseIf HOMESCIENCTextBox.Text >= 27 Then
            H_SGRADETextBox.Text = "D PLAIN"
        ElseIf HOMESCIENCTextBox.Text >= 20 Then
            H_SGRADETextBox.Text = "D-"

        ElseIf HOMESCIENCTextBox.Text < 20 Then
            H_SGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub H_SGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles H_SGRADETextBox.TextChanged

    End Sub

    Private Sub SOCIALETHICSTextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles SOCIALETHICSTextBox.GotFocus
        SOCIALETHICSTextBox.Text = Val(ENGLISHTextBox.Text) + Val(MATHSTextBox.Text) + Val(KISWAHILITextBox.Text) + Val(BIOLOGYTextBox.Text) + Val(CHEMISTRYTextBox.Text) + Val(PHYSICSTextBox.Text) + Val(AGRICULTURETextBox.Text) + Val(CRETextBox.Text) + Val(HISTORYTextBox.Text) + Val(GEOGRAPHYTextBox.Text) + Val(BUSINESSSTUDIESTextBox.Text) + Val(COMPSTUDIESTextBox.Text) + Val(HOMESCIENCTextBox.Text)
    End Sub

    Private Sub SOCIALETHICSTextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SOCIALETHICSTextBox.TextChanged

    End Sub

    Private Sub POINTSTextBox_GotFocus2(ByVal sender As Object, ByVal e As System.EventArgs) Handles POINTSTextBox.GotFocus
        POINTSTextBox.Text = SOCIALETHICSTextBox.Text / 1200 * 100
    End Sub

    Private Sub POINTSTextBox_TextChanged_2(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles POINTSTextBox.TextChanged

    End Sub

    Private Sub TOTALGRADETextBox_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs) Handles TOTALGRADETextBox.GotFocus
        If POINTSTextBox.Text >= 85 Then
            TOTALGRADETextBox.Text = "A"
        ElseIf POINTSTextBox.Text >= 79 Then
            TOTALGRADETextBox.Text = "A-"
        ElseIf POINTSTextBox.Text >= 68 Then
            TOTALGRADETextBox.Text = "B+"
        ElseIf POINTSTextBox.Text >= 62 Then
            TOTALGRADETextBox.Text = "BPLAIN"
        ElseIf POINTSTextBox.Text >= 57 Then
            TOTALGRADETextBox.Text = "B-"

        ElseIf POINTSTextBox.Text >= 50 Then
            TOTALGRADETextBox.Text = "C+"
        ElseIf POINTSTextBox.Text >= 45 Then
            TOTALGRADETextBox.Text = "CPLAIN"
        ElseIf POINTSTextBox.Text >= 40 Then
            TOTALGRADETextBox.Text = "C-"
        ElseIf POINTSTextBox.Text >= 35 Then
            TOTALGRADETextBox.Text = "D+"

        ElseIf POINTSTextBox.Text >= 27 Then
            TOTALGRADETextBox.Text = "D PLAIN"
        ElseIf POINTSTextBox.Text >= 20 Then
            TOTALGRADETextBox.Text = "D-"

        ElseIf POINTSTextBox.Text < 20 Then
            TOTALGRADETextBox.Text = "E"
        End If
    End Sub

    Private Sub TOTALGRADETextBox_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TOTALGRADETextBox.TextChanged

    End Sub

    Private Sub TextBox4_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox4.GotFocus
        TextBox4.Text = KCPERESULTTextBox.Text / 500 * 100
    End Sub

    Private Sub TextBox4_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged

    End Sub

    Private Sub TextBox3_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox3.GotFocus
        If TextBox4.Text > POINTSTextBox.Text Then
            TextBox3.Text = "Decrease "
        ElseIf POINTSTextBox.Text > TextBox4.Text Then
            TextBox3.Text = "improved"
        ElseIf TextBox4.Text = POINTSTextBox.Text Then
            TextBox3.Text = "maintained"
        End If
    End Sub

    Private Sub TextBox3_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged

    End Sub

    Private Sub TextBox7_GotFocus1(ByVal sender As Object, ByVal e As System.EventArgs) Handles TextBox7.GotFocus
        TextBox7.Text = POINTSTextBox.Text - TextBox4.Text
    End Sub

    Private Sub TextBox7_TextChanged_1(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox7.TextChanged

    End Sub

    Private Sub Label8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)

    End Sub
End Class
